export default `tlf2a$ 3 3 8 0 15 0 64 0
===============================================================================
  Pagga.tlf, or “Pagga”, by Sam Hocevar and pagga.
                Sam Hocevar sam@hocevar.net
                font creation, all base characters

  This font is free software. It comes without any warranty, to the extent
permitted by applicable law. You can redistribute it and/or modify it under
the terms of the Do What The Fuck You Want To Public License, Version 2,
as published by Sam Hocevar. See http://sam.zoy.org/wtfpl/COPYING for more
details.

  This font is part of TOIlet’s official distribution. More information
on the TOIlet website at http://caca.zoy.org/wiki/toilet
===============================================================================

░░@
░░@
░░@@
░█@
░▀@
░▀@@
░▀░▀@
░░░░@
░░░░@@
░▄█▄█▄@
░▄█▄█▄@
░░▀░▀░@@
░▄█▀@
░▀██@
░▀▀░@@
░▀░█@
░▄▀░@
░▀░▀@@
░▄▀░@
░▄█▀@
░░▀▀@@
░▀@
░░@
░░@@
░▄▀░@
░█░░@
░░▀░@@
░▀▄░@
░░█░@
░▀░░@@
░▄░▄@
░▄█▄@
░▄▀▄@@
░░░░@
░▄█▄@
░░▀░@@
░░░░@
░░░░@
░▄▀░@@
░░░░@
░▄▄▄@
░░░░@@
░░░@
░░░@
░▀░@@
░░░█@
░▄▀░@
░▀░░@@
░▄▀▄@
░█/█@
░░▀░@@
░▀█░@
░░█░@
░▀▀▀@@
░▀▀▄@
░▄▀░@
░▀▀▀@@
░▀▀█@
░░▀▄@
░▀▀░@@
░█░█@
░░▀█@
░░░▀@@
░█▀▀@
░▀▀▄@
░▀▀░@@
░▄▀▀@
░█▀▄@
░░▀░@@
░▀▀█@
░▄▀░@
░▀░░@@
░▄▀▄@
░▄▀▄@
░░▀░@@
░▄▀▄@
░░▀█@
░▀▀░@@
░░░░@
░░▀░@
░░▀░@@
░░░░@
░░▀░@
░▄▀░@@
░░▄▀@
░▀▄░@
░░░▀@@
░░░░@
░▀▀▀@
░▀▀▀@@
░▀▄░@
░░▄▀@
░▀░░@@
░▀▀█@
░░▀░@
░░▀░@@
░▄▀▄@
░█▀▀@
░░▀░@@
░█▀█@
░█▀█@
░▀░▀@@
░█▀▄@
░█▀▄@
░▀▀░@@
░█▀▀@
░█░░@
░▀▀▀@@
░█▀▄@
░█░█@
░▀▀░@@
░█▀▀@
░█▀▀@
░▀▀▀@@
░█▀▀@
░█▀▀@
░▀░░@@
░█▀▀@
░█░█@
░▀▀▀@@
░█░█@
░█▀█@
░▀░▀@@
░▀█▀@
░░█░@
░▀▀▀@@
░▀▀█@
░░░█@
░▀▀░@@
░█░█@
░█▀▄@
░▀░▀@@
░█░░@
░█░░@
░▀▀▀@@
░█▄█@
░█░█@
░▀░▀@@
░█▀█@
░█░█@
░▀░▀@@
░█▀█@
░█░█@
░▀▀▀@@
░█▀█@
░█▀▀@
░▀░░@@
░▄▀▄@
░█\\█@
░░▀\\@@
░█▀▄@
░█▀▄@
░▀░▀@@
░█▀▀@
░▀▀█@
░▀▀▀@@
░▀█▀@
░░█░@
░░▀░@@
░█░█@
░█░█@
░▀▀▀@@
░█░█@
░▀▄▀@
░░▀░@@
░█░█@
░█▄█@
░▀░▀@@
░█░█@
░▄▀▄@
░▀░▀@@
░█░█@
░░█░@
░░▀░@@
░▀▀█@
░▄▀░@
░▀▀▀@@
░█▀░@
░█░░@
░▀▀░@@
░█░░@
░░▀▄@
░░░▀@@
░▀█░@
░░█░@
░▀▀░@@
░▄▀▄@
░░░░@
░░░░@@
░░░░@
░░░░@
░▀▀▀@@
░▀▄@
░░░@
░░░@@
░█▀█@
░█▀█@
░▀░▀@@
░█▀▄@
░█▀▄@
░▀▀░@@
░█▀▀@
░█░░@
░▀▀▀@@
░█▀▄@
░█░█@
░▀▀░@@
░█▀▀@
░█▀▀@
░▀▀▀@@
░█▀▀@
░█▀▀@
░▀░░@@
░█▀▀@
░█░█@
░▀▀▀@@
░█░█@
░█▀█@
░▀░▀@@
░▀█▀@
░░█░@
░▀▀▀@@
░▀▀█@
░░░█@
░▀▀░@@
░█░█@
░█▀▄@
░▀░▀@@
░█░░@
░█░░@
░▀▀▀@@
░█▄█@
░█░█@
░▀░▀@@
░█▀█@
░█░█@
░▀░▀@@
░█▀█@
░█░█@
░▀▀▀@@
░█▀█@
░█▀▀@
░▀░░@@
░▄▀▄@
░█\\█@
░░▀\\@@
░█▀▄@
░█▀▄@
░▀░▀@@
░█▀▀@
░▀▀█@
░▀▀▀@@
░▀█▀@
░░█░@
░░▀░@@
░█░█@
░█░█@
░▀▀▀@@
░█░█@
░▀▄▀@
░░▀░@@
░█░█@
░█▄█@
░▀░▀@@
░█░█@
░▄▀▄@
░▀░▀@@
░█░█@
░░█░@
░░▀░@@
░▀▀█@
░▄▀░@
░▀▀▀@@
░░█▀@
░▀▄░@
░░▀▀@@
░░█░@
░░█░@
░░▀░@@
░▀█░@
░░▄▀@
░▀▀░@@
░▄▀▄▀@
░░░░░@
░░░░░@@
░█▀█@
░█▀█@
░▀░▀@@
░█▀█@
░█░█@
░▀▀▀@@
░█░█@
░█░█@
░▀▀▀@@
░█▀█@
░█▀█@
░▀░▀@@
░█▀█@
░█░█@
░▀▀▀@@
░█░█@
░█░█@
░▀▀▀@@
░█▀▀░█▀▀@
░▀▀█░▀▀█@
░▀▀▀░▀▀▀@@
0x00C0 À LATIN CAPITAL LETTER A WITH GRAVE
░█▀█@
░█▀█@
░▀░▀@@
0x00C1 Á LATIN CAPITAL LETTER A WITH ACUTE
░█▀█@
░█▀█@
░▀░▀@@
0x00C2 Â LATIN CAPITAL LETTER A WITH CIRCUMFLEX
░█▀█@
░█▀█@
░▀░▀@@
0x00C3 Ã LATIN CAPITAL LETTER A WITH TILDE
░█▀█@
░█▀█@
░▀░▀@@
0x00C5 Å LATIN CAPITAL LETTER A WITH RING ABOVE
░█▀█@
░█▀█@
░▀░▀@@
0x00C6 Æ LATIN CAPITAL LETTER AE
░█▀█▀▀@
░█▀█▀▀@
░▀░▀▀▀@@
0x00C7 Ç LATIN CAPITAL LETTER C WITH CEDILLA
░█▀▀@
░█░░@
░▀▀▀@@
0x00C8 È LATIN CAPITAL LETTER E WITH GRAVE
░█▀▀@
░█▀▀@
░▀▀▀@@
0x00C9 É LATIN CAPITAL LETTER E WITH ACUTE
░█▀▀@
░█▀▀@
░▀▀▀@@
0x00CA Ê LATIN CAPITAL LETTER E WITH CIRCUMFLEX
░█▀▀@
░█▀▀@
░▀▀▀@@
0x00CB Ë LATIN CAPITAL LETTER E WITH DIAERESIS
░█▀▀@
░█▀▀@
░▀▀▀@@
0x00CC Ì LATIN CAPITAL LETTER I WITH GRAVE
░▀█▀@
░░█░@
░▀▀▀@@
0x00CD Í LATIN CAPITAL LETTER I WITH ACUTE
░▀█▀@
░░█░@
░▀▀▀@@
0x00CE Î LATIN CAPITAL LETTER I WITH CIRCUMFLEX
░▀█▀@
░░█░@
░▀▀▀@@
0x00CF Ï LATIN CAPITAL LETTER I WITH DIAERESIS
░▀█▀@
░░█░@
░▀▀▀@@
0x00D1 Ñ LATIN CAPITAL LETTER N WITH TILDE
░█▀█@
░█░█@
░▀░▀@@
0x00D2 Ò LATIN CAPITAL LETTER O WITH GRAVE
░█▀█@
░█░█@
░▀▀▀@@
0x00D3 Ó LATIN CAPITAL LETTER O WITH ACUTE
░█▀█@
░█░█@
░▀▀▀@@
0x00D4 Ô LATIN CAPITAL LETTER O WITH CIRCUMFLEX
░█▀█@
░█░█@
░▀▀▀@@
0x00D5 Õ LATIN CAPITAL LETTER O WITH TILDE
░█▀█@
░█░█@
░▀▀▀@@
0x00D8 Ø LATIN CAPITAL LETTER O WITH STROKE
░█▀█@
░█░█@
░▀▀▀@@
0x00D9 Ù LATIN CAPITAL LETTER U WITH GRAVE
░█░█@
░█░█@
░▀▀▀@@
0x00DA Ú LATIN CAPITAL LETTER U WITH ACUTE
░█░█@
░█░█@
░▀▀▀@@
0x00DB Û LATIN CAPITAL LETTER U WITH CIRCUMFLEX
░█░█@
░█░█@
░▀▀▀@@
0x00DD Ý LATIN CAPITAL LETTER Y WITH ACUTE
░█░█@
░░█░@
░░▀░@@
0x00E0 à LATIN SMALL LETTER A WITH GRAVE
░█▀█@
░█▀█@
░▀░▀@@
0x00E1 á LATIN SMALL LETTER A WITH ACUTE
░█▀█@
░█▀█@
░▀░▀@@
0x00E2 â LATIN SMALL LETTER A WITH CIRCUMFLEX
░█▀█@
░█▀█@
░▀░▀@@
0x00E3 ã LATIN SMALL LETTER A WITH TILDE
░█▀█@
░█▀█@
░▀░▀@@
0x00E5 å LATIN SMALL LETTER A WITH RING ABOVE
░█▀█@
░█▀█@
░▀░▀@@
0x00E6 æ LATIN SMALL LETTER AE
░█▀█▀▀@
░█▀█▀▀@
░▀░▀▀▀@@
0x00E7 ç LATIN SMALL LETTER C WITH CEDILLA
░█▀▀@
░█░░@
░▀▀▀@@
0x00E8 è LATIN SMALL LETTER E WITH GRAVE
░█▀▀@
░█▀▀@
░▀▀▀@@
0x00E9 é LATIN SMALL LETTER E WITH ACUTE
░█▀▀@
░█▀▀@
░▀▀▀@@
0x00EA ê LATIN SMALL LETTER E WITH CIRCUMFLEX
░█▀▀@
░█▀▀@
░▀▀▀@@
0x00EB ë LATIN SMALL LETTER E WITH DIAERESIS
░█▀▀@
░█▀▀@
░▀▀▀@@
0x00EC ì LATIN SMALL LETTER I WITH GRAVE
░▀█▀@
░░█░@
░▀▀▀@@
0x00ED í LATIN SMALL LETTER I WITH ACUTE
░▀█▀@
░░█░@
░▀▀▀@@
0x00EE î LATIN SMALL LETTER I WITH CIRCUMFLEX
░▀█▀@
░░█░@
░▀▀▀@@
0x00EF ï LATIN SMALL LETTER I WITH DIAERESIS
░▀█▀@
░░█░@
░▀▀▀@@
0x00F1 ñ LATIN SMALL LETTER N WITH TILDE
░█▀█@
░█░█@
░▀░▀@@
0x00F2 ò LATIN SMALL LETTER O WITH GRAVE
░█▀█@
░█░█@
░▀▀▀@@
0x00F3 ó LATIN SMALL LETTER O WITH ACUTE
░█▀█@
░█░█@
░▀▀▀@@
0x00F4 ô LATIN SMALL LETTER O WITH CIRCUMFLEX
░█▀█@
░█░█@
░▀▀▀@@
0x00F5 õ LATIN SMALL LETTER O WITH TILDE
░█▀█@
░█░█@
░▀▀▀@@
0x00F8 ø LATIN SMALL LETTER O WITH STROKE
░█▀█@
░█░█@
░▀▀▀@@
0x00F9 ù LATIN SMALL LETTER U WITH GRAVE
░█░█@
░█░█@
░▀▀▀@@
0x00FA ú LATIN SMALL LETTER U WITH ACUTE
░█░█@
░█░█@
░▀▀▀@@
0x00FB û LATIN SMALL LETTER U WITH CIRCUMFLEX
░█░█@
░█░█@
░▀▀▀@@
0x00FC ü LATIN SMALL LETTER U WITH DIAERESIS
░█░█@
░█░█@
░▀▀▀@@
0x00FD ý LATIN SMALL LETTER Y WITH ACUTE
░█░█@
░░█░@
░░▀░@@
0x00FF ÿ LATIN SMALL LETTER Y WITH DIAERESIS
░█░█@
░░█░@
░░▀░@@
0x0153 œ LATIN SMALL LIGATURE OE
░█▀█▀▀@
░█░█▀▀@
░▀▀▀▀▀@@
`