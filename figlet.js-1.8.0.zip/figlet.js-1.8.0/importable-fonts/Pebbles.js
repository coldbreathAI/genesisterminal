export default `flf2a$ 10 8 16 -1 7
Pebbles, figletized by Empath <hades@u.washington.edu> 7/94
completed by Ryan Youck (youck@cs.uregina.ca) 8/94
~From: flee@cse.psu.edu (Felix Lee)
Here's an ascii font I've been working on.  I started with the idea of
using bubbles (. o O) to build a font, using the motif .oOo. to
express a curve.  When I sketched out the lowercase letters, it ended
up looking more like pebbles than bubbles, so I renamed it.
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@@
oO$@
OO$@
oO$@
Oo$@
oO$@
  $@
Oo$@
oO$@
  $@
  $@@
O o$@
o O$@
   $@
   $@
   $@
   $@
   $@
   $@
   $@
   $@@
        $@
        $@
  o  o  $@
ooOooOoo$@
  O  O  $@
ooOooOoo$@
  O  O  $@
        $@
        $@
        $@@
   o    $@
.oOOOo. $@
o  O  o $@
O. o    $@
 \`OOoo. $@
   O  \`O$@
   o   o$@
O. O  .O$@
 \`oooO' $@
   O    $@@
.oOo.      O$@
o   O     O $@
\`OoO'   oO  $@
       O    $@
     oO     $@
    O       $@
  oO  .oOo. $@
 O    O   o $@
O     \`OoO' $@
            $@@
 .oOOOo.  $@
 O     o  $@
  O  o'   $@
   OO     $@
 o' o     $@
O    Oo o $@
\`o     O' $@
 \`OoooO Oo$@
          $@
          $@@
Oo$@
oO$@
 O$@
o'$@
  $@
  $@
  $@
  $@
  $@
  $@@
 .oO$@
.O  $@
O   $@
o   $@
O   $@
o   $@
O   $@
\`o  $@
 \`Oo$@
    $@@
Oo. $@
  o.$@
   o$@
   O$@
   o$@
   O$@
   o$@
  O'$@
oO' $@
    $@@
       $@
       $@
 o   O $@
  O O  $@
oooOooo$@
  O O  $@
 O  \`o $@
       $@
       $@
       $@@
         $@
         $@
    o    $@
    O    $@
ooooOoooo$@
    O    $@
    O    $@
         $@
         $@
         $@@
  $@
  $@
  $@
  $@
  $@
  $@
Oo$@
oO$@
 O$@
o'$@@
         $@
         $@
         $@
         $@
ooooooooo$@
         $@
         $@
         $@
         $@
         $@@
  $@
  $@
  $@
  $@
  $@
  $@
oO$@
Oo$@
  $@
  $@@
           O$@
          O $@
        oO  $@
       O $   @
     oO $    @
    O  $     @
  oO  $      @
 O   $       @
O   $        @
            $@@
      $@
.oOOo.$@
O    o$@
o    O$@
o    o$@
O    O$@
o    O$@
\`OooO'$@
      $@
      $@@
     $@
 oO  $@
  O  $@
  o  $@
  O  $@
  o  $@
  O  $@
OooOO$@
     $@
     $@@
      $@
.oOOo.$@
     O$@
     o$@
    O'$@
   O  $@
 .O   $@
oOoOoO$@
      $@
      $@@
      $@
.oOOo.$@
     O$@
     o$@
  .oO $@
     o$@
     O$@
\`OooO'$@
      $@
      $@@
      $@
o   O $@
O   o $@
o   o $@
OooOOo$@
    O $@
    o $@
    O $@
      $@
      $@@
      $@
OooOOo$@
o     $@
O     $@
ooOOo.$@
     O$@
     o$@
\`OooO'$@
      $@
      $@@
      $@
.oOOo.$@
O     $@
o     $@
OoOOo.$@
O    O$@
O    o$@
\`OooO'$@
      $@
      $@@
      $@
OooOoO$@
     o$@
     O$@
    O $@
   O  $@
  o   $@
 O    $@
      $@
      $@@
      $@
.oOOo.$@
O    o$@
o    O$@
\`oOOo'$@
O    o$@
o    O$@
\`OooO'$@
      $@
      $@@
      $@
.oOOo.$@
O    o$@
o    O$@
\`OooOo$@
     O$@
     o$@
\`OooO'$@
      $@
      $@@
  $@
  $@
oO$@
OO$@
  $@
  $@
Oo$@
oo$@
  $@
  $@@
  $@
  $@
Oo$@
oO$@
  $@
  $@
oO$@
Oo$@
 O$@
o'$@@
     oO$@
    O  $@
  oO   $@
 O     $@
O      $@
 O     $@
  Oo   $@
    O  $@
     Oo$@
       $@@
         $@
         $@
         $@
ooooooooo$@
         $@
ooooooooo$@
         $@
         $@
         $@
         $@@
Oo     $@
  O    $@
   Oo  $@
     O $@
      O$@
     O $@
   oO  $@
  O    $@
oO     $@
       $@@
ooOOo. $@
     \`O$@
      O$@
     .o$@
 ooOO' $@
 Oo $   @
 oO $   @
    $   @
 oO $   @
    $   @@
 .oOOOOOo. $@
.O       o.$@
O .oOoO'  o$@
o O   o   O$@
O o   O  O'$@
o \`OoO'oO' $@
O          $@
\`o     o'  $@
 \`OoooO'   $@
           $@@
   Oo   $@
  o  O  $@
 O    o $@
oOooOoOo$@
o      O$@
O      o$@
o      O$@
O.     O$@
        $@
        $@@
o.oOOOo. $@
 o     o $@
 O     O $@
 oOooOO. $@
 o     \`O$@
 O      o$@
 o     .O$@
 \`OooOO' $@
         $@
         $@@
 .oOOOo.$ @
.O     o$ @
o       $ @
o       $ @
o       $ @
O       $ @
\`o     .o$@
 \`OoooO' $@
         $@
         $@@
o.OOOo.  $@
 O    \`o $@
 o      O$@
 O      o$@
 o      O$@
 O      o$@
 o    .O'$@
 OooOO'  $@
         $@
         $@@
o.OOoOoo$@
 O      $@
 o      $@
 ooOO   $@
 O      $@
 o      $@
 O      $@
ooOooOoO$@
        $@
        $@@
OOooOoO$@
o      $@
O      $@
oOooO  $@
O      $@
o      $@
o      $@
O'     $@
       $@
       $@@
 .oOOOo. $@
.O     o $@
o        $@
O        $@
O   .oOOo$@
o.      O$@
 O.    oO$@
  \`OooO' $@
         $@
         $@@
o      O$@
O      o$@
o      O$@
OoOooOOo$@
o      O$@
O      o$@
o      o$@
o      O$@
        $@
        $@@
ooOoOOo$@
   O   $@
   o   $@
   O   $@
   o   $@
   O   $@
   O   $@
ooOOoOo$@
       $@
       $@@
  OooOoo$@
      O $@
      o $@
      O $@
      o $@
      O $@
O     o $@
\`OooOO' $@
        $@
        $@@
\`o    O $@
 o   O  $@
 O  O   $@
 oOo    $@
 o  o   $@
 O   O  $@
 o    o $@
 O     O$@
        $@
        $@@
 o     $@
O      $@
o      $@
o      $@
O      $@
O      $@
o     .$@
OOoOooO$@
       $@
       $@@
Oo      oO$@
O O    o o$@
o  o  O  O$@
O   Oo   O$@
O        o$@
o        O$@
o        O$@
O        o$@
          $@
          $@@
o.     O$@
Oo     o$@
O O    O$@
O  o   o$@
O   o  O$@
o    O O$@
o     Oo$@
O     \`o$@
        $@
        $@@
 .oOOOo. $@
.O     o.$@
O       o$@
o       O$@
O       o$@
o       O$@
\`o     O'$@
 \`OoooO' $@
         $@
         $@@
OooOOo. $@
O     \`O$@
o      O$@
O     .o$@
oOooOO' $@
o       $@
O       $@
o'      $@
        $@
        $@@
 .oOOOo.  $@
.O     o. $@
o       O $@
O       o $@
o       O $@
O    Oo o $@
\`o     O' $@
 \`OoooO Oo$@
          $@
          $@@
\`OooOOo. $@
 o     \`o$@
 O      O$@
 o     .O$@
 OOooOO' $@
 o    o  $@
 O     O $@
 O      o$@
         $@
         $@@
.oOOOo. $@
o     o $@
O.      $@
 \`OOoo. $@
      \`O$@
       o$@
O.    .O$@
 \`oooO' $@
        $@
        $@@
oOoOOoOOo$@
    o    $@
    o    $@
    O    $@
    o    $@
    O    $@
    O    $@
    o'   $@
         $@
         $@@
O       o$@
o       O$@
O       o$@
o       o$@
o       O$@
O       O$@
\`o     Oo$@
 \`OoooO'O$@
         $@
         $@@
o      'O$@
O       o$@
o       O$@
o       o$@
O      O'$@
\`o    o  $@
 \`o  O   $@
  \`o'    $@
         $@
         $@@
o          \`O$@
O           o$@
o           O$@
O           O$@
o     o     o$@
O     O     O$@
\`o   O o   O'$@
 \`OoO' \`OoO' $@
             $@
             $@@
o      O$@
 O    o $@
  o  O  $@
   oO   $@
   Oo   $@
  o  o  $@
 O    O $@
O      o$@
        $@
        $@@
o       O$@
O       o$@
\`o     O'$@
  O   o  $@
   \`O'   $@
    o    $@
    O    $@
    O    $@
         $@
         $@@
OoooOOoO$@
      o $@
     O  $@
    o   $@
   O    $@
  o     $@
 O      $@
OOooOooO$@
        $@
        $@@
oOOo$@
O   $@
o   $@
O   $@
o   $@
O   $@
o   $@
O   $@
OoOo$@
    $@@
O  $         @
 O $         @
  Oo $       @
    O $      @
     Oo $    @
       O $   @
        Oo $ @
          O $@
           O$@
            $@@
ooOo$@
   O$@
   o$@
   O$@
   o$@
   O$@
   o$@
   O$@
ooOO$@
    $@@
  Oo  $@
 o  O $@
O    o$@
      $@
      $@
      $@
      $@
      $@
      $@
      $@@
         $@
         $@
         $@
         $@
         $@
         $@
         $@
         $@
ooooooooo$@
         $@@
oO$@
Oo$@
O $@
\`o$@
  $@
  $@
  $@
  $@
  $@
  $@@
      $@
      $@
      $@
      $@
.oOoO'$@
O   o $@
o   O $@
\`OoO'o$@
      $@
      $@@
 o   $@
O    $@
O    $@
o    $@
OoOo.$@
O   o$@
o   O$@
\`OoO'$@
     $@
     $@@
     $@
     $@
     $@
     $@
.oOo $@
O    $@
o    $@
\`OoO'$@
     $@
     $@@
     o$@
    O $@
    o $@
    o $@
.oOoO $@
o   O $@
O   o $@
\`OoO'o$@
      $@
      $@@
     $@
     $@
     $@
     $@
.oOo.$@
OooO'$@
O    $@
\`OoO'$@
     $@
     $@@
.oOo$@
O   $@
o   $@
OoO $@
o   $@
O   $@
o   $@
O'  $@
    $@
    $@@
     $@
     $@
     $@
     $@
.oOoO$@
o   O$@
O   o$@
\`OoOo$@
    O$@
 OoO'$@@
 o   $@
O    $@
o    $@
O    $@
OoOo.$@
o   o$@
o   O$@
O   o$@
     $@
     $@@
 $$@
o$$@
 $$@
 $$@
O$$@
o$$@
O$$@
o'$@
  $@
  $@@
   $@
  O$@
   $@
   $@
 'o$@
  O$@
  o$@
  O$@
  o$@
oO'$@@
o    $@
O    $@
o    $@
o    $@
O  o $@
OoO  $@
o  O $@
O   o$@
     $@
     $@@
 o$@
O $@
o $@
O $@
o $@
O $@
o $@
Oo$@
  $@
  $@@
        $@
        $@
        $@
        $@
\`oOOoOO.$@
 O  o  o$@
 o  O  O$@
 O  o  o$@
        $@
        $@@
      $@
      $@
      $@
      $@
'OoOo.$@
 o   O$@
 O   o$@
 o   O$@
      $@
      $@@
     $@
     $@
     $@
     $@
.oOo.$@
O   o$@
o   O$@
\`OoO'$@
     $@
     $@@
     $@
     $@
     $@
     $@
.oOo.$@
O   o$@
o   O$@
oOoO'$@
O    $@
o'   $@@
      $@
      $@
      $@
      $@
.oOoO'$@
O   o $@
o   O $@
\`OoOo $@
    O $@
    \`o$@@
      $@
      $@
      $@
      $@
\`OoOo.$@
 o    $@
 O    $@
 o    $@
      $@
      $@@
     $@
     $@
     $@
     $@
.oOo $@
\`Ooo.$@
    O$@
\`OoO'$@
     $@
     $@@
     $@
     $@
  O  $@
 oOo $@
  o  $@
  O  $@
  o  $@
  \`oO$@
     $@
     $@@
      $@
      $@
      $@
      $@
O   o $@
o   O $@
O   o $@
\`OoO'o$@
      $@
      $@@
      $@
      $@
      $@
      $@
\`o   O$@
 O   o$@
 o  O $@
 \`o'  $@
      $@
      $@@
        $@
        $@
        $@
        $@
'o     O$@
 O  o  o$@
 o  O  O$@
 \`Oo'oO'$@
        $@
        $@@
     $@
     $@
     $@
     $@
o   O$@
 OoO $@
 o o $@
O   O$@
     $@
     $@@
     $@
     $@
     $@
     $@
O   o$@
o   O$@
O   o$@
\`OoOO$@
    o$@
 OoO'$@@
    $@
    $@
    $@
    $@
ooOO$@
  o $@
 O  $@
OooO$@
    $@
    $@@
  .oO$@
 .O  $@
 O   $@
 o   $@
OO   $@
 o   $@
 O   $@
 \`o  $@
  \`Oo$@
     $@@
o$@
O$@
o$@
O$@
o$@
O$@
O$@
O$@
 $@
 $@@
Oo.  $@
  o. $@
   o $@
   O $@
   oO$@
   O $@
   o $@
  O' $@
oO'  $@
     $@@
 o.  o$@
O  O' $@
      $@
      $@
      $@
      $@
      $@
      $@
      $@
      $@@
 O    O $@
   Oo   $@
  o  O  $@
 O    o $@
oOooOoOo$@
o      O$@
O      o$@
O.     O$@
        $@
        $@@
 O     O $@
 .oOOOo. $@
.O     o.$@
O       o$@
o       O$@
O       o$@
\`o     O'$@
 \`OoooO' $@
         $@
         $@@
 O     O $@
         $@
O       O$@
o       o$@
O       O$@
O       o$@
\`o     Oo$@
 \`OoooO'O$@
         $@
         $@@
      $@
      $@
o   o $@
      $@
.oOoO'$@
O   o $@
o   O $@
\`OoO'o$@
      $@
      $@@
     $@
     $@
o   o$@
     $@
.oOo.$@
O   o$@
o   O$@
\`OoO'$@
     $@
     $@@
      $@
      $@
o   o $@
      $@
O   o $@
o   O $@
O   o $@
\`OoO'o$@
      $@
      $@@
o.oOOOo. $@
 o     o $@
 O     O $@
 oOooOO. $@
 o     \`O$@
 O      o$@
 o     .O$@
 O.ooOO' $@
 o       $@
oO       $@@
`