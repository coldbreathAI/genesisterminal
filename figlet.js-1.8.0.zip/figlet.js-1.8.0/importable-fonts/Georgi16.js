export default `flf2a$ 16 2 25 15 20 0 0
Georgia 16 by Richard Sabey 8.2003
Includes new parameter supported by FIGlet and FIGWin.
To avoid too great a space in "nn", the bottom serifs must touch. Thus, this
font is designed to be figletised so that glyphs may not smush but may abut.
However, heavy characters representing thick strokes need space. Thus this
font extensively uses $ to force a space after a heavy character.
Rows: 1-2 cap-height letters' diacritics
        3 underscores for cap-height serifs
        4 cap-height line
        6 underscores for x-height serifs
        7 x-height line
       13 baseline
    14-16 descenders
31.8.2003 All ASCII and ISO Latin 1's printables.






$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@@
    @
    @
 8$ @
(M)$@
(M)$@
(M)$@
 M$ @
 M$ @
 M$ @
 8$ @
    @
68b$@
Y89$@
    @
    @
    @@
        @
        @
68b 68b$@
Y89 Y89$@
\`M' \`M' @
 V   V  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @@
           @
           @
           @
           @
     dP dP$@
    ,M',M'$@
    dP dP  @
   ,M',M'  @
 MMMMMMMM$ @
  ,M',M'   @
 MMMMMMMM$ @
 ,M',M'    @
 dP dP     @
,M',M'     @
dP dP      @
           @@
          @
          @
  __M__   @
 6MMMMMb$ @
6M' M  Yb$@
MM  M     @
YM. M     @
 YMMMMMb$ @
    M \`Mb$@
    M  MM$@
    M  MM$@
Yb  M ,M9$@
 YMMMMM9$ @
    M     @
          @
          @@
              @
              @
              @
 ,88.       M$@
,M  M.    ,P$ @
8(  )8   d'   @
\`M  M'  M     @
 \`88' ,P      @
     d' ,88.  @
    M  ,M  M.$@
  ,P   8(  )8$@
 d'    \`M  M'$@
M       \`88' $@
              @
              @
              @@
           @
           @
  __       @
 6MMb      @
6M' \`b     @
8M  ,9     @
YM.,9  ___ @
 \`Mb   \`M'$@
,M'MM   P$ @
MM  YM. 7$ @
MM   \`Mb$  @
YM.   7MM$ @
 YMMM9  YM_@
           @
           @
           @@
    @
    @
68b$@
Y89$@
 9$ @
/   @
 $  @
 $  @
 $  @
 $  @
 $  @
 $  @
 $  @
 $  @
 $  @
 $  @@
    @
    @
  ,'@
 6P$@
,M'$@
MM$ @
MM$ @
MM$ @
MM$ @
MM$ @
MM$ @
MM$ @
MM$ @
\`M.$@
 Yb$@
  \`.@@
     @
     @
\`.   @
 Yb$ @
 \`M.$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
 ,M'$@
 d9$ @
,'   @@
        @
        @
        @
 8   8$ @
  \\ /   @
(8o*o8)$@
  / \\   @
 8   8$ @
        @
        @
        @
        @
        @
        @
        @
        @@
        @
        @
        @
        @
        @
        @
   M    @
   M    @
   M    @
MMMMMMM$@
   M    @
   M    @
   M    @
        @
        @
        @@
    @
    @
    @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
68b$@
Y89$@
 9$ @
/   @
    @@
        @
        @
        @
        @
        @
        @
        @
        @
        @
MMMMMMM$@
        @
        @
        @
        @
        @
        @@
    @
    @
    @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
68b$@
Y89$@
    @
    @
    @@
         @
         @
      ,M'@
      dP$@
     ,M'$@
     dP  @
    ,M'  @
    dP   @
   ,M'   @
   dP    @
  ,M'    @
  dP     @
 ,M'     @
 dP      @
,M'      @
dP       @@
         @
         @
         @
         @
         @
  ____   @
 6MMMMb$ @
6M'  \`Mb$@
MM    MM$@
MM    MM$@
MM    MM$@
YM.  ,M9$@
 YMMMM9$ @
         @
         @
         @@
    @
    @
    @
    @
    @
__/$@
\`MM$@
 MM$@
 MM$@
 MM$@
 MM$@
 MM$@
_MM_@
    @
    @
    @@
         @
         @
         @
         @
         @
  ____   @
 6MMMMb$ @
MM'  \`Mb$@
     ,MM$@
    ,MM'$@
  ,M'    @
,M'      @
MMMMMMMM$@
         @
         @
         @@
         @
         @
         @
         @
         @
  ____   @
 6MMMMb$ @
MM'  \`Mb$@
      MM$@
     .M9$@
  MMMM  $@
     \`Mb$@
      MM$@
      MM$@
MM.  ,M9$@
 YMMMM9$ @@
         @
         @
         @
         @
         @
         @
     ,M$ @
    ,dM$ @
   ,dMM$ @
  ,d MM$ @
 ,d  MM$ @
,d   MM$ @
MMMMMMMM$@
     MM$ @
     MM$ @
     MM$ @@
         @
         @
         @
         @
         @
 _______ @
,MMMMMMM$@
dM       @
MP       @
M'       @
MMMMMMb$ @
     \`Mb$@
      MM$@
      MM$@
MM.  ,M9$@
 YMMMM9$ @@
          @
          @
    ,6P   @
  6MM'    @
 6M'      @
6M ____   @
MMMMMMMb$ @
MM'   \`Mb$@
MM     MM$@
MM     MM$@
MM     MM$@
YM.   ,M9$@
 YMMMMM9$ @
          @
          @
          @@
         @
         @
         @
         @
         @
________ @
MMMMMMMM$@
/     d'$@
     ,P  @
     M   @
    d'   @
   ,P    @
   M     @
  d'     @
 ,P      @
 M       @@
         @
         @
  ____   @
 6MMMMb$ @
6M'  \`Mb$@
MM    M9$@
YM.  ,9$ @
 YMMMMb$ @
 6'  \`Mb$@
6M    MM$@
MM    MM$@
YM.  ,M9$@
 YMMMM9$ @
         @
         @
         @@
         @
         @
         @
         @
         @
  ____   @
 6MMMMb$ @
6M'  \`Mb$@
MM    MM$@
MM    MM$@
YM.  ,MM$@
 YMMMMMM$@
      M9$@
    ,M9$ @
  ,MM9   @
 d9'     @@
    @
    @
    @
    @
    @
    @
68b$@
Y89$@
    @
    @
    @
68b$@
Y89$@
    @
    @
    @@
    @
    @
    @
    @
    @
    @
68b$@
Y89$@
    @
    @
    @
68b$@
Y89$@
 9$ @
/   @
    @@
      @
      @
      @
      @
      @
   /M/@
  /M/ @
 /M/  @
/M/   @
\\M\\   @
 \\M\\  @
  \\M\\ @
   \\M\\@
      @
      @
      @@
        @
        @
        @
        @
        @
        @
        @
        @
MMMMMMM$@
        @
MMMMMMM$@
        @
        @
        @
        @
        @@
       @
       @
       @
       @
       @
\\M\\    @
 \\M\\   @
  \\M\\  @
   \\M\\$@
   /M/$@
  /M/  @
 /M/   @
/M/    @
       @
       @
       @@
        @
        @
        @
 6MMMb$ @
6M' \`Mb$@
\`'   MM$@
     MM$@
    ,M9$@
   MM9$ @
   M    @
        @
  68b   @
  Y89   @
        @
        @
        @@
               @
               @
               @
               @
  ,88888888b   @
 68        \`b$ @
,P   o68b69 Yb$@
6'  M'  ,M'  8$@
M  dP   dP   8$@
M ,M'  ,M'   8$@
M dP   dP   ,8$@
M Yb  ,M'  d8'$@
Y  YMM9Yoo6'   @
\`b             @
 \`Y888888'     @
               @@
              @
              @
       _      @
      dM.$    @
     ,MMb$    @
     d'YM.$   @
    ,P \`Mb$   @
    d'  YM.$  @
   ,P   \`Mb$  @
   d'    YM.$ @
  ,MMMMMMMMb$ @
  d'      YM.$@
_dM_     _dMM_@
              @
              @
              @@
           @
           @
________   @
\`MMMMMMMb. @
 MM    \`Mb$@
 MM     MM$@
 MM    .M9$@
 MMMMMMM( $@
 MM    \`Mb$@
 MM     MM$@
 MM     MM$@
 MM    .M9$@
_MMMMMMM9' @
           @
           @
           @@
          @
          @
   ____   @
  6MMMMb/$@
 8P    YM$@
6M      Y$@
MM        @
MM        @
MM        @
MM        @
YM      6$@
 8b    d9$@
  YMMMM9$ @
          @
          @
          @@
           @
           @
________   @
\`MMMMMMMb. @
 MM    \`Mb$@
 MM     MM$@
 MM     MM$@
 MM     MM$@
 MM     MM$@
 MM     MM$@
 MM     MM$@
 MM    .M9$@
_MMMMMMM9' @
           @
           @
           @@
           @
           @
__________ @
\`MMMMMMMMM$@
 MM      \\$@
 MM        @
 MM    ,   @
 MMMMMMM$  @
 MM    \`   @
 MM        @
 MM        @
 MM      /$@
_MMMMMMMMM$@
           @
           @
           @@
         @
         @
________ @
\`MMMMMMM$@
 MM    \\ @
 MM      @
 MM   ,  @
 MMMMMM$ @
 MM   \`  @
 MM      @
 MM      @
 MM      @
_MM_     @
         @
         @
         @@
          @
          @
   ____   @
  6MMMMb/$@
 8P    YM$@
6M      Y$@
MM        @
MM        @
MM     ___@
MM     \`M'@
YM      M$@
 8b    d9$@
  YMMMM9$ @
          @
          @
          @@
            @
            @
____    ____@
\`MM'    \`MM'@
 MM      MM$@
 MM      MM$@
 MM      MM$@
 MMMMMMMMMM$@
 MM      MM$@
 MM      MM$@
 MM      MM$@
 MM      MM$@
_MM_    _MM_@
            @
            @
            @@
    @
    @
____@
\`MM'@
 MM$@
 MM$@
 MM$@
 MM$@
 MM$@
 MM$@
 MM$@
 MM$@
_MM_@
    @
    @
    @@
         @
         @
     ____@
     \`MM'@
      MM$@
      MM$@
      MM$@
      MM$@
      MM$@
      MM$@
(8)   MM$@
((   ,M9 @
 YMMMM9$ @
         @
         @
         @@
           @
           @
___    __  @
\`MM    d'$ @ 
 MM   d'$  @
 MM  d'$   @
 MM d'$    @
 MMd'$     @
 MMYM.$    @
 MM YM.$   @
 MM  YM.$  @
 MM   YM.$ @
_MM_   YM._@
           @
           @
           @@
         @
         @
____     @
\`MM'$    @
 MM$     @
 MM$     @
 MM$     @
 MM$     @
 MM$     @
 MM$     @
 MM$     @
 MM    /$@
_MMMMMMM$@
         @
         @
         @@
             @
             @
___       ___@
\`MMb     dMM'@
 MMM.   ,PMM$@
 M\`Mb   d'MM$@
 M YM. ,P MM$@
 M \`Mb d' MM$@
 M  YM.P  MM$@
 M  \`Mb'  MM$@
 M   YP   MM$@
 M   \`'   MM$@
_M_      _MM_@
             @
             @
             @@
            @
            @
___      ___@
\`MM\\     \`M'@
 MMM\\     M$@
 M\\MM\\    M$@
 M \\MM\\   M$@
 M  \\MM\\  M$@
 M   \\MM\\ M$@
 M    \\MM\\M$@
 M     \\MMM$@
 M      \\MM$@
_M_      \\M$@
            @
            @
            @@
           @
           @
   ____    @
  6MMMMb$  @
 8P    Y8$ @
6M      Mb$@
MM      MM$@
MM      MM$@
MM      MM$@
MM      MM$@
YM      M9$@
 8b    d8$ @
  YMMMM9$  @
           @
           @
           @@
           @
           @
________   @
\`MMMMMMMb. @
 MM    \`Mb$@
 MM     MM$@
 MM     MM$@
 MM    .M9$@
 MMMMMMM9' @
 MM        @
 MM        @
 MM        @
_MM_       @
           @
           @
           @@
           @
           @
   ____    @
  6MMMMb   @
 8P    Y8$ @
6M      Mb$@
MM      MM$@
MM      MM$@
MM      MM$@
MM      MM$@
YM      M9$@
 8b    d8$ @
  YMMMM9   @
    MM     @
    YM.    @
     \`Mo   @@
            @
            @
________    @
\`MMMMMMMb.  @
 MM    \`Mb$ @
 MM     MM$ @
 MM     MM$ @
 MM    .M9$ @
 MMMMMMM9'  @
 MM  \\M\\    @
 MM   \\M\\   @
 MM    \\M\\  @
_MM_    \\M\\_@
            @
            @
            @@
         @
         @
  ____   @
 6MMMMb\\ @
6M'    \` @
MM       @
YM.      @
 YMMMMb$ @
     \`Mb$@
      MM$@
      MM$@
L    ,M9$@
MYMMMM9$ @
         @
         @
         @@
           @
           @
__________$@
MMMMMMMMMM$@
/   MM   \\$@
   $MM$    @
   $MM$    @
   $MM$    @
   $MM$    @
   $MM$    @
   $MM$    @
   $MM$    @
   _MM_    @
           @
           @
           @@
            @
            @
____     ___@
\`MM'     \`M'@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 YM       M$@
  8b     d8 @
   YMMMMM9$ @
            @
            @
            @@
             @
             @
____     ___ @
\`Mb(     )d'$@
 YM.     ,P$ @
 \`Mb     d'$ @
  YM.   ,P$  @
  \`Mb   d'$  @
   YM. ,P$   @
   \`Mb d'$   @
    YM,P$    @
    \`MM'$    @
     YP      @
             @
             @
             @@
                      @
                      @
____              ___ @
\`Mb(      db      )d'$@
 YM.     ,PM.     ,P$ @
 \`Mb     d'Mb     d'$ @
  YM.   ,P YM.   ,P$  @
  \`Mb   d' \`Mb   d'$  @
   YM. ,P   YM. ,P$   @
   \`Mb d'   \`Mb d'$   @
    YM,P     YM,P$    @
    \`MM'     \`MM'$    @
     YP       YP      @
                      @
                      @
                      @@
              @
              @
____      ___ @
\`MM(      )M'$@
 \`MM.     d'$ @
  \`MM.   d'$  @
   \`MM. d'$   @
    \`MMd$     @
     dMM.$    @
    d'\`MM.$   @
   d'  \`MM.$  @
  d'    \`MM.$ @
_M(_    _)MM_ @
              @
              @
              @@
             @
             @
____     ___ @
\`MM(     )M'$@
 \`MM.    d'$ @
  \`MM.  d'$  @
   \`MM d'$   @
    \`MM'$    @
    $MM$     @
    $MM$     @
    $MM$     @
    $MM$     @
    _MM_     @
             @
             @
             @@
             @
             @
____________ @
MMMMMMMMMMMP @
/       dMP  @
       dMP   @
      dMP    @
     dMP     @
    dMP      @
   dMP       @
  dMP        @
 dMP       / @
dMMMMMMMMMMM$@
             @
             @
             @@
     @
     @
MMMM$@
MM$  @
MM$  @
MM$  @
MM$  @
MM$  @
MM$  @
MM$  @
MM$  @
MM$  @
MM$  @
MM$  @
MM$  @
MMMM$@@
          @
          @
\`M.       @
 Yb       @
 \`M.      @
  Yb      @
  \`M.     @
   Yb     @
   \`M.    @
    Yb    @
    \`M.   @
     Yb   @
     \`M.  @ 
      Yb  @
      \`M.$@
       Yb$@@
     @
     @
MMMM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
  MM$@
MMMM$@@
         @
         @
         @
   /M\\   @
  // \\\\  @
 //   \\\\ @
//     \\\\@
         @
         @
         @
         @
         @
         @
         @
         @
         @@
         @
         @
         @
         @
         @
         @
         @
         @
         @
         @
         @
         @
         @
         @
MMMMMMMM$@
         @@
    @
    @
  / @
 6$ @
68b$@
Y89$@
    @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
    @@
          @
          @
          @
          @
          @
   ___    @
 6MMMMb   @
8M'  \`Mb$ @
    ,oMM$ @
,6MM9'MM$ @
MM'   MM$ @
MM.  ,MM$ @
\`YMMM9'Yb.@
          @
          @
          @@
          @
          @
___       @
 MM       @
 MM       @
 MM____   @
 MMMMMMb$ @
 MM'  \`Mb$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM.  ,M9$@
_MYMMMM9$ @
          @
          @
          @@
         @
         @
         @
         @
         @
  ____   @
 6MMMMb. @
6M'   Mb$@
MM    \`'$@
MM       @
MM      $@
YM.   d9$@
 YMMMM9$ @
         @
         @
         @@
         @
         @
     ___ @
     \`MM$@
      MM$@
  ____MM$@
 6MMMMMM$@
6M'  \`MM$@
MM    MM$@
MM    MM$@
MM    MM$@
YM.  ,MM$@
 YMMMMMM_@
         @
         @
         @@
         @
         @
         @
         @
         @
  ____   @
 6MMMMb$ @
6M'  \`Mb$@
MM    MM$@
MMMMMMMM$@
MM      $@
YM    d9$@
 YMMMM9$ @
         @
         @
         @@
      @
      @
   __ @
  69MM@
 6M' \`@
_MM__ @
MMMMM @
 MM   @
 MM   @
 MM   @
 MM   @
 MM   @
_MM_  @
      @
      @
      @@
         @
         @
         @
         @
         @
  __     @
 6MMbMMM$@
6M'\`Mb   @
MM  MM   @
YM.,M9   @
 YMM9    @
(M       @
 YMMMMb. @
6M    Yb$@
YM.   d9$@
 YMMMM9$ @@
          @
          @
___       @
\`MM       @
 MM       @
 MM  __   @
 MM 6MMb$ @
 MMM9 \`Mb$@
 MM'   MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
_MM_  _MM_@
          @
          @
          @@
    @
    @
    @
68b$@
Y89$@
___$@
\`MM$@
 MM$@
 MM$@
 MM$@
 MM$@
 MM$@
_MM_@
    @
    @
    @@
        @
        @
        @
    68b$@
    Y89$@
    ___ @
    \`MM$@
     MM$@
     MM$@
     MM$@
     MM$@
     MM$@
     MM$@
     MM$@
 (8) M9$@
  YMM9$ @@
          @
          @
___       @
\`MM       @
 MM       @
 MM   __  @
 MM   d'$ @
 MM  d'$  @
 MM d'$   @
 MMdM.$   @
 MMPYM.$  @
 MM  YM.$ @
_MM_  YM._@
          @
          @
          @@
    @
    @
___ @
\`MM$@
 MM$@
 MM$@
 MM$@
 MM$@
 MM$@
 MM$@
 MM$@
 MM$@
_MM_@
    @
    @
    @@
                @
                @
                @
                @
                @
___  __    __   @
\`MM 6MMb  6MMb$ @
 MM69 \`MM69 \`Mb$@
 MM'   MM'   MM$@
 MM    MM    MM$@
 MM    MM    MM$@
 MM    MM    MM$@
_MM_  _MM_  _MM_@
                @
                @
                @@
          @
          @
          @
          @
          @
___  __   @
\`MM 6MMb$ @
 MMM9 \`Mb$@
 MM'   MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
_MM_  _MM_@
          @
          @
          @@
          @
          @
          @
          @
          @
  _____   @
 6MMMMMb$ @
6M'   \`Mb$@
MM     MM$@
MM     MM$@
MM     MM$@
YM.   ,M9$@
 YMMMMM9$ @
          @
          @
          @@
          @
          @
          @
          @
          @
__ ____   @
\`M6MMMMb$ @
 MM'  \`Mb$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM.  ,M9$@
 MMYMMM9$ @
 MM       @
 MM       @
_MM_      @@
         @
         @
         @
         @
         @
  ____   @
 6MMMMb/$@
6M'  \`MM$@
MM    MM$@
MM    MM$@
MM    MM$@
YM.  ,MM$@
 YMMMM9M$@
      MM$@
      MM$@
     _MM_@@
        @
        @
        @
        @
        @
___  __ @
\`MM 6MM$@
 MM69 "$@
 MM'    @
 MM     @
 MM     @
 MM     @
_MM_    @
        @
        @
        @@
         @
         @
         @
         @
         @
  ____   @
 6MMMMb\\ @
MM'    \` @
YM.      @
 YMMMMb$ @
     \`Mb$@
L    ,MM$@
MYMMMM9$ @
         @
         @
         @@
        @
        @
        @
        @
  /     @
 /M     @
/MMMMM$ @
 MM     @
 MM     @
 MM     @
 MM     @
 YM.  , @
  YMMM9$@
        @
        @
        @@
          @
          @
          @
          @
          @
___   ___ @
\`MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 YM.   MM$@
  YMMM9MM_@
          @
          @
          @@
            @
            @
            @
            @
            @
____    ___ @
\`MM(    )M'$@
 \`Mb    d'$ @
  YM.  ,P$  @
   MM  M$   @
   \`Mbd'$   @
    YMP$    @
     M$     @
            @
            @
            @@
                 @
                 @
                 @
                 @
                 @
____    _    ___ @
\`MM(   ,M.   )M'$@
 \`Mb   dMb   d'$ @
  YM. ,PYM. ,P$  @
  \`Mb d'\`Mb d'$  @
   YM,P  YM,P$   @
   \`MM'  \`MM'$   @
    YP    YP$    @
                 @
                 @
                 @@
           @
           @
           @
           @
           @
____   ___ @
\`MM(   )P'$@
 \`MM\` ,P$  @
  \`MM,P$   @
   \`MM.$   @
   d\`MM.$  @
  d' \`MM.$ @
_d_  _)MM_ @
           @
           @
           @@
            @
            @
            @
            @
            @
____    ___ @
\`MM(    )M'$@
 \`Mb    d'$ @
  YM.  ,P$  @
   MM  M$   @
   \`Mbd'$   @
    YMP$    @
     M$     @
    d'$     @
(8),P$      @
 YMM        @@
          @
          @
          @
          @
          @
_________ @
MMMMMMMMP @
/    dMP  @
    dMP   @
   dMP    @
  dMP     @
 dMP    / @
dMMMMMMMM$@
          @
          @
          @@
      @
      @
   ,6'@
  6M$ @
  MM$ @
  MM$ @
  MM$ @
  M9$ @
,6'   @
\`b.   @
  Mb$ @
  MM$ @
  MM$ @
  MM$ @
  YM$ @
   \`b.@@
   @
   @
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@@
      @
      @
\`b.   @
  Mb$ @
  MM$ @
  MM$ @
  MM$ @
  YM$ @
   \`b.@
   ,6'@
  6M$ @
  MM$ @
  MM$ @
  MM$ @
  M9$ @
,6'   @@
         @
         @
         @
         @
         @
         @
         @
         @
,68b.   ,@
'   \`Y89'@
         @
         @
         @
         @
         @
         @@
   68b  68b   @
   Y89  Y89   @
       _      @
      dM.$    @
     ,MMb$    @
     d'YM.$   @
    ,P \`Mb$   @
    d'  YM.$  @
   ,P   \`Mb$  @
   d'    YM.$ @
  ,MMMMMMMMb$ @
  d'      YM.$@
_dM_     _dMM_@
              @
              @
              @@
 68b  68b  @
 Y89  Y89  @
   ____    @
  6MMMMb   @
 8P    Y8$ @
6M      Mb$@
MM      MM$@
MM      MM$@
MM      MM$@
MM      MM$@
YM      M9$@
 8b    d8$ @
  YMMMM9   @
           @
           @
           @@
  68b  68b  @
  Y89  Y89  @
____    ____@
\`MM'    \`MM'@
 MM      MM$@
 MM      MM$@
 MM      MM$@
 MM      MM$@
 MM      MM$@
 MM      MM$@
 YM      M9$@
  8b    d8$ @
   YMMMM9   @
            @
            @
            @@
          @
          @
          @
 68b 68b$ @
 Y89 Y89$ @
  ____    @
 6MMMMb   @
MM'   Yb$ @
      MM$ @
,6MMMMMM$ @
MM    MM$ @
MM   ,MM$ @
\`YMMM9'Yb.@
          @
          @
          @@
          @
          @
          @
 68b 68b$ @
 Y89 Y89$ @
  _____   @
 6MMMMMb$ @
6M'   \`Mb$@
MM     MM$@
MM     MM$@
MM     MM$@
YM.   ,M9$@
 YMMMMM9$ @
          @
          @
          @@
          @
          @
          @
 68b 68b$ @
 Y89 Y89$ @
___   ___ @
\`MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 YM.   MM$@
  YMMM9MM_@
          @
          @
          @@
          @
          @
  6MMMMb  @
 6M'  \`Mb$@
 MM    MM$@
 MM   ,M9$@
 MM MMM<  @
 MM   \`Mb$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM   ,M9$@
_MM MMM9$ @
          @
          @
          @@
128  EURO
           @
           @
    ____   @
   6MMMMb/$@
  8P    YM$@
 6M      Y$@
MMMMMMM/   @
 MM        @
 MM        @
MMMMM/     @
 YM      6$@
  8b    d9$@
   YMMMM9$ @
           @
           @
           @@
130  LOW-9 QUOTE
    @
    @
    @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
68b$@
Y89$@
 9$ @
/   @
    @@
131  SMALL F WITH HOOK
                @
                @
           __   @
          69MM$ @
         6M (8)$@
       __MM__$  @
       MMMMMM$  @
        MM      @
       6M9      @
       MM       @
      6M9       @
      MM        @
     6M9        @
 (8) MM         @
   YM9          @
                @@
132  LOW-9 DOUBLE QUOTE
        @
        @
        @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
68b 68b$@
Y89 Y89$@
 9   9$ @
/   /   @
        @@
133  ELLIPSIS
            @
            @
            @
            @
            @
            @
            @
            @
            @
            @
            @
            @
68b 68b 68b$@
Y89 Y89 Y89$@
            @
            @@
134  DAGGER
        @
        @
        @
   8    @
   I    @
(8o+o8)$@
   I    @
   I    @
   I    @
   I    @
   I    @
   8    @
        @
        @
        @
        @@
135  DOUBLE DAGGER
        @
        @
        @
   8    @
   I    @
(8o+o8)$@
   I    @
   I    @
   I    @
(8o+o8)$@
   I    @
   8    @
        @
        @
        @
        @@
136  CIRCUMFLEX
         @
         @
         @
   /M\\   @
  // \\\\  @
 //   \\\\ @
//     \\\\@
         @
         @
         @
         @
         @
         @
         @
         @
         @@
137  PER THOUSAND
                  @
                  @
                  @
/MMM\\    //$      @
M' \`M   //        @
M. ,M  //         @
\\MMM/ //          @
     //           @
    //            @
   // /MMM\\ /MMM\\$@
  //  M' \`M M' \`M$@
 //   M. ,M M. ,M$@
//    \\MMM/ \\MMM/$@
                  @
                  @
                  @@
138  UPPERCASE S WITH CARON
 .    ,  @
  \`\\/'   @
  ____   @
 6MMMMb\\ @
6M'    \` @
MM       @
YM.      @
 YMMMMb$ @
     \`Mb$@
      MM$@
      MM$@
L    ,M9$@
MYMMMM9$ @
         @
         @
         @@
139  OPEN SINGLE GUILLEMET
     @
     @
     @
     @
     @
     @
   /$@
 ,/  @
//   @
\\\\   @
 \`\\  @
   \\$@
     @
     @
     @
     @@
140  UPPERCASE OE LIGATURE
                 @
                 @
   _____________ @
  6MMMMMMMMMMMMM$@
 8P    MM      \\$@
6M     MM        @
MM     MM    ,   @
MM     MMMMMMM$  @
MM     MM    \`   @
MM     MM        @
YM     MM        @
 8b    MM      /$@
  YMMMMMMMMMMMMM$@
                 @
                 @
                 @@
142  UPPERCASE Z WITH CARON
   .    ,    @
    \`\\/'     @
____________ @
MMMMMMMMMMM/ @
'       /M/  @
       /M/   @
      /M/    @
     /M/     @
    /M/      @
   /M/       @
  /M/        @
 /M/       , @
/MMMMMMMMMMM$@
             @
             @
             @@
145  OPEN SINGLE QUOTE
    @
    @
  / @
 6$ @
68b$@
Y89$@
    @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
    @@
146  CLOSE SINGLE QUOTE
    @
    @
68b$@
Y89$@
 9$ @
/   @
    @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
    @@
147  OPEN DOUBLE QUOTE
        @
        @
  /   / @
 6   6$ @
68b 68b$@
Y89 Y89$@
        @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
        @@
148  CLOSE DOUBLE QUOTE
        @
        @
68b 68b$@
Y89 Y89$@
 9   9$ @
/   /   @
        @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
        @@
149  BULLET
      @
      @
      @
      @
      @
      @
      @
      @
 68b  @
(888)$@
 Y89  @
      @
      @
      @
      @
      @@
150  EN DASH
          @
          @
          @
          @
          @
          @
          @
          @
          @
MMMMMMMMM$@
          @
          @
          @
          @
          @
          @@
151  EM DASH
             @
             @
             @
             @
             @
             @
             @
             @
             @
MMMMMMMMMMMM$@
             @
             @
             @
             @
             @
             @@
152  TILDE
         @
         @
         @
         @
         @
         @
         @
         @
,68b.   ,@
'   \`Y89'@
         @
         @
         @
         @
         @
         @@
153  TRADEMARK SYMBOL
             @
             @
_   _ _    _ @
/-M-\\ I    M$@
  M   I\\  /M$@
  M   I \\/ M$@
  M   I    M$@
  M   I    M$@
             @
             @
             @
             @
             @
             @
             @
             @@
154  LOWERCASE S WITH CARON
         @
         @
         @
 .    ,  @
  \`\\/'   @
  ____   @
 6MMMMb\\ @
MM'    \` @
YM.      @
 YMMMMb$ @
     \`Mb$@
L    ,MM$@
MYMMMM9$ @
         @
         @
         @@
155  CLOSE SINGLE GUILLEMET
     @
     @
     @
     @
     @
     @
\\    @
 \\\`  @
  \\\\$@
  //$@
 /'  @
/    @
     @
     @
     @
     @@
156  LOWERCASE OE LIGATURE
                @
                @
                @
                @
                @
  _____  ____   @
 6MMMMMb6MMMMb$ @
6M'   \`MM'  \`Mb$@
MM     MM    MM$@
MM     MMMMMMMM$@
MM     MM      $@
YM.   ,MM    d9$@
 YMMMMM9YMMMM9$ @
                @
                @
                @@
158  LOWERCASE Z WITH CARON
          @
          @
          @
  .    ,  @
   \`\\/'   @
_________ @
MMMMMMMM/ @
'    /M/  @
    /M/   @
   /M/    @
  /M/     @
 /M/    , @
/MMMMMMMM$@
          @
          @
          @@
159  UPPERCASE Y WITH DIAERESIS
    68b 68b$  @
    Y89 Y89$  @
_____     ___ @
\`YMM(     )M'$@
  YMM\`    d'$ @
   YMM\`  d'$  @
    YMM\`d'$   @
     YMM'$    @
     $MM$     @
     $MM$     @
     $MM$     @
     $MM$     @
     _MM_     @
              @
              @
              @@
160  NO-BREAK SPACE
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@@
161  INVERTED EXCLAMATION MARK
    @
    @
68b$@
Y89$@
    @
 8$ @
 M$ @
 M$ @
 M$ @
(M)$@
(M)$@
(M)$@
 8$ @
    @
    @
    @@
162  CENT SIGN
          @
          @
          @
          @
    M     @
  __M__   @
 6MMMMMb. @
6M' M  Mb$@
MM  M  \`'$@
MM  M     @
MM  M    $@
YM. M  d9$@
 YMMMMM9$ @
    M     @
    M     @
          @@
163  POUND SIGN
           @
           @
   _____   @
  6MMMMMb$ @
 6M'    Yb$@
 MM        @
 YM        @
 MM        @
MMMMMMMMM$ @
 MM        @
 M9        @
69         @
MMMMMMMMMM$@
           @
           @
           @@
164  CURRENCY SIGN
        @
        @
        @
        @
        @
        @
\\\\    //@
 \\\\88// @
 ,8  8. @
 8    8 @
 \`8  8' @
 //88\\\\ @
//    \\\\@
        @
        @
        @@
165  YEN SIGN
              @
              @
_____     ___ @
\`YMM\`     \`M'$@
  YMM\`    d'$ @
   YMM\`  d'$  @
    YMM\`d'$   @
     YMM'$    @
     $MM$     @
    MMMMMM$   @
     $MM$     @
     $MM$     @
     _MM_     @
              @
              @
              @@
166  BROKEN BAR
   @
   @
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@
   @
   @
MM$@
MM$@
MM$@
MM$@
MM$@
MM$@@
167  SECTION SIGN
        @
        @
        @
 6MMM.  @
6M' (8)$@
MM      @
YM.     @
 \`YMb.  @
69' \`Yb$@
MM   MM$@
YM. ,69$@
 \`YMb.  @
    \`Yb$@
     MM$@
(8) ,69$@
 \`MMM'  @@
168  DIAERESIS
         @
         @
         @
68b  68b$@
Y89  Y89$@
         @
         @
         @
         @
         @
         @
         @
         @
         @
         @
         @@
169  COPYRIGHT SIGN
               @
               @
               @
    ,8888.     @
  ,8'    \`8.   @
 ,8'      \`8.  @
 8' ,6MMbM \`8  @
,9 ,9    \`  Y.$@
8' M        \`8$@
8  M         8$@
8. M        ,8$@
\`b \`b    6  6'$@
 8. \`YMM9  ,8  @
 \`8.      ,8'  @
  \`8.    ,8'   @
    \`8888'     @@
170  FEMININE ORDINAL INDICATOR
          @
          @
          @
 6MMMMb   @
MM'   Yb$ @
    ,6MM$ @
,6MM9'MM$ @
MM    MM$ @
\`YMMM9'Yb.@
          @
          @
          @
          @
          @
          @
          @@
171  OPEN DOUBLE GUILLEMET
        @
        @
        @
        @
        @
        @
   /  /$@
 ,/ ,/  @
// //   @
\\\\ \\\\   @
 \`\\ \`\\  @
   \\  \\$@
        @
        @
        @
        @@
172  NOT SIGN
         @
         @
         @
         @
         @
         @
         @
         @
MMMMMMMM$@
       M$@
         @
         @
         @
         @
         @
         @@
173  SOFT HYPHEN
        @
        @
        @
        @
        @
        @
        @
        @
        @
MMMMMMM$@
        @
        @
        @
        @
        @
        @@
174  REGISTERED SIGN
               @
               @
               @
    ,8888.     @
  ,8'    \`8.   @
 ,8'      \`8.  @
 8'\`MMMMb. \`8  @
,9  M   \`b  Y.$@
8'  M   ,9  \`8$@
8   MMMM9    8$@
8.  M \`b    ,8$@
\`b  M  \`b   6'$@
 8.,M.  \`b.,8  @
 \`8.      ,8'  @
  \`8.    ,8'   @
    \`8888'     @@
175  MACRON
           @
MMMMMMMMMM$@
           @
           @
           @
           @
           @
           @
           @
           @
           @
           @
           @
           @
           @
           @@
176  DEGREE SIGN
      @
      @
 ,8.  @
,9 Y.$@
8   8$@
\`b 6'$@
 \`8'  @
      @
      @
      @
      @
      @
      @
      @
      @
      @@
177  PLUS-MINUS SIGN
        @
        @
        @
        @
        @
        @
   M    @
   M    @
   M    @
MMMMMMM$@
   M    @
   M    @
MMMMMMM$@
        @
        @
        @@
178  SUPERSCRIPT TWO
        @
        @
        @
 ,88b.  @
8'  \`Yb$@
     )8$@
    ,d9$@
  ,8'   @
,8'     @
8888888$@
        @
        @
        @
        @
        @
        @@
179  SUPERSCRIPT THREE
        @
        @
        @
 ,88b.  @
8'  \`Yb$@
     )8$@
  888( $@
     )8$@
8.  ,d9$@
 \`889'  @
        @
        @
        @
        @
        @
        @@
180  ACUTE ACCENT
       @
       @
   _.o$@
,-''   @
       @
       @
       @
       @
       @
       @
       @
       @
       @
       @
       @
       @@
181  LOWERCASE MU
          @
          @
          @
          @
          @
          @
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 YM.   MM$@
 IYMMM9'Y.@
 I        @
 I        @
 8        @@
182  PILCROW SIGN
       @
       @
   ____@
  6MMM$@
 6MM M$@
(MMM M$@
 YMM M$@
  YM M$@
   M M$@
   M M$@
   M M$@
   M M$@
   M M$@
       @
       @
       @@
183  MIDDLE DOT
     @
     @
     @
     @
     @
     @
     @
     @
 __  @
(88)$@
 \`'  @
     @
     @
     @
     @
     @@
184  CEDILLA
    @
    @
    @
    @
    @
    @
    @
    @
    @
    @
    @
    @
    @
bo. @
  8$@
o6' @@
185  SUPERSCRIPT ONE
   @
   @
   @
_M$@
 M$@
 M$@
 M$@
 M$@
 M$@
_M_@
   @
   @
   @
   @
   @
   @@
186  MASCULINE ORDINAL INDICATOR
        @
        @
        @
  ,8.   @
 8' \`8  @
6'   \`b$@
M     M$@
Y.   ,9$@
 Y. ,9  @
  \`8'   @
        @
        @
        @
        @
        @
        @@
187  CLOSE DOUBLE GUILLEMET
        @
        @
        @
        @
        @
        @
\\  \\    @
 \\\` \\\`  @
  \\\\ \\\\$@
  // //$@
 /' /'  @
/  /    @
        @
        @
        @
        @@
188  VULGAR FRACTION ONE QUARTER
            @
            @
            @
_M          @
 M    //    @
 M    M     @
 M   //  6$ @
 M   M  6M$ @
 M  // 6'M$ @
_M_ M 6M M$ @
   //6MMMMM$@
   M     M$ @
  //     M$ @
            @
            @
            @@
189  VULGAR FRACTION ONE HALF
               @
               @
               @
_M             @
 M    //       @
 M    M        @
 M   // ,88b.  @
 M   M 8'  \`Yb$@
 M  //      )8$@
_M_ M      ,d9$@
   //    ,8'   @
   M   ,8'     @
  //   8888888$@
               @
               @
               @@
190  VULGAR FRACTION THREE QUARTERS
               @
               @
               @
 ,88b.         @
8'  \`Yb  //    @
     )8  M     @
  888(  //  6$ @
     )8 M  6M$ @
8.  ,d9// 6'M$ @
 \`889' M 6M M$ @
      //6MMMMM$@
      M     M$ @
     //     M$ @
               @
               @
               @@
191  INVERTED QUESTION MARK
        @
        @
        @
  68b   @
  Y89   @
        @
   M    @
 6MM    @
6M'     @
MM      @
MM   ,. @
YM. ,M9$@
 YMMM9  @
        @
        @
        @@
192  UPPERCASE A WITH GRAVE
    o._       @
      \`\`-.    @
       _      @
      dM.$    @
     ,MMb$    @
     d'YM.$   @
    ,P \`Mb$   @
    d'  YM.$  @
   ,P   \`Mb$  @
   d'    YM.$ @
  ,MMMMMMMMb$ @
  d'      YM.$@
_dM_     _dMM_@
              @
              @
              @@
193  UPPERCASE A WITH ACUTE
       _.o    @
    ,-''      @
       _      @
      dM.$    @
     ,MMb$    @
     d'YM.$   @
    ,P \`Mb$   @
    d'  YM.$  @
   ,P   \`Mb$  @
   d'    YM.$ @
  ,MMMMMMMMb$ @
  d'      YM.$@
_dM_     _dMM_@
              @
              @
              @@
194  UPPERCASE A WITH CIRCUMFLEX
      __      @
    ,''\`\`.    @
       _      @
      dM.$    @
     ,MMb$    @
     d'YM.$   @
    ,P \`Mb$   @
    d'  YM.$  @
   ,P   \`Mb$  @
   d'    YM.$ @
  ,MMMMMMMMb$ @
  d'      YM.$@
_dM_     _dMM_@
              @
              @
              @@
195  UPPERCASE A WITH TILDE
   ,68b.   ,  @
   '   \`Y89'  @
       _      @
      dM.$    @
     ,MMb$    @
     d'YM.$   @
    ,P \`Mb$   @
    d'  YM.$  @
   ,P   \`Mb$  @
   d'    YM.$ @
  ,MMMMMMMMb$ @
  d'      YM.$@
_dM_     _dMM_@
              @
              @
              @@
196  UPPERCASE A WITH DIAERESIS
   68b  68b   @
   Y89  Y89   @
       _      @
      dM.$    @
     ,MMb$    @
     d'YM.$   @
    ,P \`Mb$   @
    d'  YM.$  @
   ,P   \`Mb$  @
   d'    YM.$ @
  ,MMMMMMMMb$ @
  d'      YM.$@
_dM_     _dMM_@
              @
              @
              @@
197  UPPERCASE A WITH RING ABOVE
     688b     @
    8(  )8$   @
     Y889     @
      dM.$    @
     ,MMb$    @
     d'YM.$   @
    ,P \`Mb$   @
    d'  YM.$  @
   ,P   \`Mb$  @
   d'    YM.$ @
  ,MMMMMMMMb$ @
  d'      YM.$@
_dM_     _dMM_@
              @
              @
              @@
198  UPPERCASE AE
                     @
                     @
          __________ @
          dMMMMMMMMM$@
         d'MM      \\$@
        d' MM        @
       d'  MM    ,   @
      d'   MMMMMMM$  @
     dMMMMMMM    \`   @
    d'     MM        @
   d'      MM        @
  d'       MM      /$@
_dM_       MMMMMMMMM$@
                     @
                     @
                     @@
199  UPPERCASE C WITH CEDILLA
          @
          @
   ____   @
  6MMMMb/$@
 8P    YM$@
6M      Y$@
MM        @
MM        @
MM        @
MM        @
YM      6$@
 8b    d9$@
  YMMMM9$ @
    bo.   @
      8   @
    o6'   @@
200  UPPERCASE E WITH GRAVE
   o._     @
     \`\`-.  @
__________ @
\`MMMMMMMMM$@
 MM      \\$@
 MM        @
 MM    ,   @
 MMMMMMM$  @
 MM    \`   @
 MM        @
 MM        @
 MM      /$@
_MMMMMMMMM$@
           @
           @
           @@
201  UPPERCASE E WITH ACUTE
      _.o  @
   ,-''    @
__________ @
\`MMMMMMMMM$@
 MM      \\$@
 MM        @
 MM    ,   @
 MMMMMMM$  @
 MM    \`   @
 MM        @
 MM        @
 MM      /$@
_MMMMMMMMM$@
           @
           @
           @@
202  UPPERCASE E WITH CIRCUMFLEX
    __     @
  ,''\`\`.   @
__________ @
\`MMMMMMMMM$@
 MM      \\$@
 MM        @
 MM    ,   @
 MMMMMMM$  @
 MM    \`   @
 MM        @
 MM        @
 MM      /$@
_MMMMMMMMM$@
           @
           @
           @@
203  UPPERCASE E WITH DIAERESIS
 68b  68b  @
 Y89  Y89  @
__________ @
\`MMMMMMMMM$@
 MM      \\$@
 MM        @
 MM    ,   @
 MMMMMMM$  @
 MM    \`   @
 MM        @
 MM        @
 MM      /$@
_MMMMMMMMM$@
           @
           @
           @@
204  UPPERCASE I WITH GRAVE
 o._    @
   \`\`-. @
  ____  @
  \`MM'  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
  _MM_  @
        @
        @
        @@
205  UPPERCASE I WITH ACUTE
    _.o @
 ,-''   @
  ____  @
  \`MM'  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
  _MM_  @
        @
        @
        @@
206  UPPERCASE I WITH CIRCUMFLEX
   __   @
 ,''\`\`. @
  ____  @
  \`MM'  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
  _MM_  @
        @
        @
        @@
207  UPPERCASE I WITH DIAERESIS
68b  68b@
Y89  Y89@
  ____  @
  \`MM'  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
  _MM_  @
        @
        @
        @@
208  UPPERCASE ETH
           @
           @
________   @
\`MMMMMMMb. @
 MM    \`Mb$@
 MM     MM$@
 MM     MM$@
MMMMM   MM$@
 MM     MM$@
 MM     MM$@
 MM     MM$@
 MM    .M9$@
_MMMMMMM9' @
           @
           @
           @@
209  UPPERCASE N WITH TILDE
  ,68b.   , @
  '   \`Y89' @
___      ___@
\`MM\\     \`M'@
 MMM\\     M$@
 M\\MM\\    M$@
 M \\MM\\   M$@
 M  \\MM\\  M$@
 M   \\MM\\ M$@
 M    \\MM\\M$@
 M     \\MMM$@
 M      \\MM$@
_M_      \\M$@
            @
            @
            @@
210  UPPERCASE O WITH GRAVE
   o._     @
     \`\`-.  @
   ____    @
  6MMMMb$  @
 8P    Y8$ @
6M      Mb$@
MM      MM$@
MM      MM$@
MM      MM$@
MM      MM$@
YM      M9$@
 8b    d8$ @
  YMMMM9$  @
           @
           @
           @@
211  UPPERCASE O WITH ACUTE
     _.o   @
  ,-''     @
   ____    @
  6MMMMb$  @
 8P    Y8$ @
6M      Mb$@
MM      MM$@
MM      MM$@
MM      MM$@
MM      MM$@
YM      M9$@
 8b    d8$ @
  YMMMM9$  @
           @
           @
           @@
212  UPPERCASE O WITH CIRCUMFLEX
    __     @
  ,''\`\`.   @
   ____    @
  6MMMMb$  @
 8P    Y8$ @
6M      Mb$@
MM      MM$@
MM      MM$@
MM      MM$@
MM      MM$@
YM      M9$@
 8b    d8$ @
  YMMMM9$  @
           @
           @
           @@
213  UPPERCASE O WITH TILDE
 ,68b.   , @
 '   \`Y89' @
   ____    @
  6MMMMb$  @
 8P    Y8$ @
6M      Mb$@
MM      MM$@
MM      MM$@
MM      MM$@
MM      MM$@
YM      M9$@
 8b    d8$ @
  YMMMM9$  @
           @
           @
           @@
214  UPPERCASE O WITH DIAERESIS
 68b  68b  @
 Y89  Y89  @
   ____    @
  6MMMMb$  @
 8P    Y8$ @
6M      Mb$@
MM      MM$@
MM      MM$@
MM      MM$@
MM      MM$@
YM      M9$@
 8b    d8$ @
  YMMMM9$  @
           @
           @
           @@
215  MULTIPLICATION SIGN
        @
        @
        @
        @
        @
        @
\\\\    //@
 \\\\  // @
  \\\\//  @
   ><   @
  //\\\\  @
 //  \\\\ @
//    \\\\@
        @
        @
        @@
216  UPPERCASE O WITH STROKE
            @
            @
   _____    @
  6MMMMMb// @
 8P     /8$ @
6M     //Mb$@
MM    // MM$@
MM   //  MM$@
MM  //   MM$@
MM //    MM$@
YM//     M9$@
 8/     d8$ @
//YMMMMM9$  @
            @
            @
            @@
217  UPPERCASE U WITH GRAVE
    o._     @
      \`\`-.  @
____     ___@
\`MM'     \`M'@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 YM       M$@
  8b     d8 @
   YMMMMM9$ @
            @
            @
            @@
218  UPPERCASE U WITH ACUTE
      _.o   @
   ,-''     @
____     ___@
\`MM'     \`M'@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 YM       M$@
  8b     d8 @
   YMMMMM9$ @
            @
            @
            @@
219  UPPERCASE U WITH CIRCUMFLEX
      __    @
    ,''\`\`.  @
____     ___@
\`MM'     \`M'@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 YM       M$@
  8b     d8 @
   YMMMMM9$ @
            @
            @
            @@
220  UPPERCASE U WITH DIAERESIS
  68b  68b  @
  Y89  Y89  @
____     ___@
\`MM'     \`M'@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 MM       M$@
 YM       M$@
  8b     d8 @
   YMMMMM9$ @
            @
            @
            @@
221  UPPERCASE Y WITH ACUTE
       _.o    @
    ,-''      @
_____     ___ @
\`YMM(     )M'$@
  YMM\`    d'$ @
   YMM\`  d'$  @
    YMM\`d'$   @
     YMM'$    @
     $MM$     @
     $MM$     @
     $MM$     @
     $MM$     @
     _MM_     @
              @
              @
              @@
222  UPPERCASE THORN
           @
           @
____       @
\`MM'       @
 MM        @
 MMMMMMMb. @
 MM    \`Mb$@
 MM     MM$@
 MM     MM$@
 MM    .M9$@
 MMMMMMM9' @
 MM        @
_MM_       @
           @
           @
           @@
223  LOWERCASE SHARP S
          @
          @
  6MMMMb  @
 6M'  \`Mb$@
 MM    MM$@
 MM   ,M9$@
 MM MMM<  @
 MM   \`Mb$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM   ,M9$@
_MM MMM9$ @
          @
          @
          @@
224  LOWERCASE A WITH GRAVE
          @
          @
          @
  o._     @
    \`\`-.  @
   ___    @
 6MMMMb   @
8M'  \`Mb$ @
    ,oMM$ @
,6MM9'MM$ @
MM'   MM$ @
MM.  ,MM$ @
\`YMMM9'Yb.@
          @
          @
          @@
225  LOWERCASE A WITH ACUTE
          @
          @
          @
     _.o  @
  ,-''    @
   ___    @
 6MMMMb   @
8M'  \`Mb$ @
    ,oMM$ @
,6MM9'MM$ @
MM'   MM$ @
MM.  ,MM$ @
\`YMMM9'Yb.@
          @
          @
          @@
226  LOWERCASE A WITH CIRCUMFLEX
          @
          @
          @
   __     @
 ,''\`\`.   @
   ___    @
 6MMMMb   @
8M'  \`Mb$ @
    ,oMM$ @
,6MM9'MM$ @
MM'   MM$ @
MM.  ,MM$ @
\`YMMM9'Yb.@
          @
          @
          @@
227  LOWERCASE A WITH TILDE
          @
          @
          @
,68b.   , @
'   \`Y89' @
   ___    @
 6MMMMb   @
8M'  \`Mb$ @
    ,oMM$ @
,6MM9'MM$ @
MM'   MM$ @
MM.  ,MM$ @
\`YMMM9'Yb.@
          @
          @
          @@
228  LOWERCASE A WITH DIAERESIS
          @
          @
          @
 68b 68b$ @
 Y89 Y89$ @
   ___    @
 6MMMMb   @
8M'  \`Mb$ @
    ,oMM$ @
,6MM9'MM$ @
MM'   MM$ @
MM.  ,MM$ @
\`YMMM9'Yb.@
          @
          @
          @@
229  LOWERCASE A WITH RING ABOVE
          @
          @
  688b    @
 8(  )8$  @
  Y889    @
   ___    @
 6MMMMb   @
8M'  \`Mb$ @
    ,oMM$ @
,6MM9'MM$ @
MM'   MM$ @
MM.  ,MM$ @
\`YMMM9'Yb.@
          @
          @
          @@
230  LOWERCASE AE
               @
               @
               @
               @
               @
   ___  ____   @
 68MMMb6MMMMb$ @
8M'  \`MM'   Yb$@
    ,oMM    MM$@
,6MM9'MMMMMMMM$@
MM'   MM      $@
MM.  ,MM.   d9$@
\`YMMM9'\`MMMM9$ @
               @
               @
               @@
231  LOWERCASE C WITH CEDILLA
         @
         @
         @
         @
         @
  ____   @
 6MMMMb. @
6M'   Mb$@
MM    \`'$@
MM       @
MM      $@
YM.   d9$@
 YMMMM9$ @
   bo.   @
     8   @
   o6'   @@
232  LOWERCASE E WITH GRAVE
         @
         @
         @
 o._     @
   \`\`-.  @
  ____   @
 6MMMMb$ @
6M'  \`Mb$@
MM    MM$@
MMMMMMMM$@
MM      $@
YM.   d9$@
 YMMMM9$ @
         @
         @
         @@
233  LOWERCASE E WITH ACUTE
         @
         @
         @
    _.o  @
 ,-''    @
  ____   @
 6MMMMb$ @
6M'  \`Mb$@
MM    MM$@
MMMMMMMM$@
MM      $@
YM.   d9$@
 YMMMM9$ @
         @
         @
         @@
234  LOWERCASE E WITH CIRCUMFLEX
         @
         @
         @
   __    @
 ,''\`\`.  @
  ____   @
 6MMMMb$ @
6M'  \`Mb$@
MM    MM$@
MMMMMMMM$@
MM      $@
YM.   d9$@
 YMMMM9$ @
         @
         @
         @@
235  LOWERCASE E WITH DIAERESIS
         @
         @
         @
 68b 68b$@
 Y89 Y89$@
  ____   @
 6MMMMb$ @
6M'  \`Mb$@
MM    MM$@
MMMMMMMM$@
MM      $@
YM.   d9$@
 YMMMM9$ @
         @
         @
         @@
236  LOWERCASE I WITH GRAVE
      @
      @
      @
o._   @
  \`\`-.@
 ___  @
 \`MM$ @
  MM$ @
  MM$ @
  MM$ @
  MM$ @
  MM$ @
 _MM_ @
      @
      @
      @@
237  LOWERCASE I WITH ACUTE
      @
      @
      @
   _.o@
,-''  @
 ___  @
 \`MM$ @
  MM$ @
  MM$ @
  MM$ @
  MM$ @
  MM$ @
 _MM_ @
      @
      @
      @@
238  LOWERCASE I WITH CIRCUMFLEX
      @
      @
      @
  __  @
,''\`\`.@
 ___  @
 \`MM$ @
  MM$ @
  MM$ @
  MM$ @
  MM$ @
  MM$ @
 _MM_ @
      @
      @
      @@
239  LOWERCASE I WITH DIAERESIS
        @
        @
        @
68b 68b$@
Y89 Y89$@
  ___   @
  \`MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
   MM$  @
  _MM_  @
        @
        @
        @@
240  LOWERCASE ETH
          @
          @
  Yb.//   @
   \`MMb   @
   //\`Mb$ @
  ____ Mb$@
 6MMMMMMM$@
6M'   \`Mb$@
MM     MM$@
MM     MM$@
MM     MM$@
YM.   ,M9$@
 YMMMMM9$ @
          @
          @
          @@
241  LOWERCASE N WITH TILDE
          @
          @
          @
,68b.   , @
'   \`Y89' @
___  __   @
\`MM 6MMb$ @
 MMM9 \`Mb$@
 MM'   MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
_MM_  _MM_@
          @
          @
          @@
242  LOWERCASE O WITH GRAVE
          @
          @
          @
  o._     @
    \`\`-.  @
  _____   @
 6MMMMMb$ @
6M'   \`Mb$@
MM     MM$@
MM     MM$@
MM     MM$@
YM.   ,M9$@
 YMMMMM9$ @
          @
          @
          @@
243  LOWERCASE O WITH ACUTE
          @
          @
          @
     _.o  @
  ,-''    @
  _____   @
 6MMMMMb$ @
6M'   \`Mb$@
MM     MM$@
MM     MM$@
MM     MM$@
YM.   ,M9$@
 YMMMMM9$ @
          @
          @
          @@
244  LOWERCASE O WITH CIRCUMFLEX
          @
          @
          @
    __    @
  ,''\`\`.  @
  _____   @
 6MMMMMb$ @
6M'   \`Mb$@
MM     MM$@
MM     MM$@
MM     MM$@
YM.   ,M9$@
 YMMMMM9$ @
          @
          @
          @@
245  LOWERCASE O WITH TILDE
          @
          @
          @
,68b.   , @
'   \`Y89' @
  _____   @
 6MMMMMb$ @
6M'   \`Mb$@
MM     MM$@
MM     MM$@
MM     MM$@
YM.   ,M9$@
 YMMMMM9$ @
          @
          @
          @@
246  LOWERCASE O WITH DIAERESIS
          @
          @
          @
 68b 68b$ @
 Y89 Y89$ @
  _____   @
 6MMMMMb$ @
6M'   \`Mb$@
MM     MM$@
MM     MM$@
MM     MM$@
YM.   ,M9$@
 YMMMMM9$ @
          @
          @
          @@
247  DIVISION SIGN
        @
        @
        @
        @
        @
        @
  68b   @
  Y89   @
        @
MMMMMMM$@
        @
  68b   @
  Y89   @
        @
        @
        @@
248  LOWERCASE O WITH STROKE
          @
          @
          @
          @
          @
  _____// @
 6MMMMM/  @
6M'  //Mb$@
MM  // MM$@
MM //  MM$@
MM//   MM$@
YM/   ,M9$@
//MMMMM9$ @
          @
          @
          @@
249  LOWERCASE U WITH GRAVE
          @
          @
          @
  o._     @
    \`\`-.  @
___   ___ @
\`MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 YM.   MM$@
  YMMM9MM_@
          @
          @
          @@
250  LOWERCASE U WITH ACUTE
          @
          @
          @
     _.o  @
  ,-''    @
___   ___ @
\`MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 YM.   MM$@
  YMMM9MM_@
          @
          @
          @@
251  LOWERCASE U WITH CIRCUMFLEX
          @
          @
          @
    __    @
  ,''\`\`.  @
___   ___ @
\`MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 YM.   MM$@
  YMMM9MM_@
          @
          @
          @@
252  LOWERCASE U WITH DIAERESIS
          @
          @
          @
 68b 68b$ @
 Y89 Y89$ @
___   ___ @
\`MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 YM.   MM$@
  YMMM9MM_@
          @
          @
          @@
253  LOWERCASE Y WITH ACUTE
            @
            @
            @
      _.o   @
   ,-''     @
____    ___ @
\`MM(    )M'$@
 \`Mb    d'$ @
  YM.  ,P$  @
   MM  M$   @
   \`Mbd'$   @
    YMP$    @
     M$     @
    d'$     @
(8),P$      @
 YMM        @@
254  LOWERCASE THORN
          @
          @
___       @
 MM       @
 MM       @
 MM____   @
 MMMMMMb$ @
 MM'  \`Mb$@
 MM    MM$@
 MM    MM$@
 MM    MM$@
 MM.  ,M9$@
 MMMMMM9$ @
 MM       @
 MM       @
_MM       @@
255  LOWERCASE Y WITH DIAERESIS
            @
            @
            @
  68b 68b$  @
  Y89 Y89$  @
____    ___ @
\`MM(    )M'$@
 \`Mb    d'$ @
  YM.  ,P$  @
   MM  M$   @
   \`Mbd'$   @
    YMP$    @
     M$     @
    d'$     @
(8),P$      @
 YMM        @@
`