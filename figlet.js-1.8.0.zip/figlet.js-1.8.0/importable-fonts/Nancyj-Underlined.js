export default `flf2a$ 8 6 15 -1 9

				   nancyj-underlined.flf

	  named after the login of a woman who  asked me to make her a
	  sig. this is the font that came out of it.  this is my first
		  attempt at a figlet font, so leave me alone.

			           vampyr@acs.bu.edu

$$ @
$$ @
$$ @
$$ @
$$ @
$$ @
ooo@
$$ @@
dP @
88 @
88 @
dP @
   @
oo @
ooo@
   @@
dP dP @
dP dP @
      @
      @
      @
      @
oooooo@
      @@
        @
 dP dP  @
8888888 @
 88 88  @
8888888 @
 dP dP  @
oooooooo@
        @@
  #  #   @
.d8888P' @
Y8#oo#o. @
  #  #88 @
\`88888P' @
  #  #   @
ooooooooo@
         @@
d8P   dP   @
8 8  d8'   @
Y8P d8'    @
   d8' d8P @
  d8'  8 8 @
 88    Y8P @
ooooooooooo@
           @@
   d88b    @
   8\`'8    @
   d8b     @
 d8P\`8b    @
 d8' \`8bP  @
 \`888P'\`YP @
ooooooooooo@
           @@
d8 @
88 @
.P @
   @
   @
   @
ooo@
   @@
 a88P @
d8'   @
88    @
88    @
Y8.   @
 Y88b @
oooooo@
      @@
Y88o  @
  \`8b @
   88 @
   88 @
  .8P @
d88Y  @
oooooo@
      @@
    dP     @
8b. 88 .d8 @
 \`8b88d8'  @
 .8P88Y8.  @
8P' 88 \`Y8 @
    dP     @
ooooooooooo@
           @@
         @
   dP    @
   88    @
88888888 @
   88    @
   dP    @
ooooooooo@
         @@
    @
    @
    @
    @
 dP @
 88 @
~.P~@
    @@
         @
         @
         @
88888888 @
         @
         @
ooooooooo@
         @@
   @
   @
   @
   @
dP @
88 @
ooo@
   @@
     d8' @
    d8'  @
   d8'   @
  d8'    @
 d8'     @
88       @
ooooooooo@
         @@
 a8888a  @
d8' ..8b @
88 .P 88 @
88 d' 88 @
Y8'' .8P @
 Y8888P  @
ooooooooo@
         @@
d88  @
 88  @
 88  @
 88  @
 88  @
d88P @
ooooo@
     @@
d8888b. @
    \`88 @
.aaadP' @
88'     @
88.     @
Y88888P @
oooooooo@
        @@
d8888b. @
    \`88 @
 aaad8' @
    \`88 @
    .88 @
d88888P @
oooooooo@
        @@
dP   dP @
88   88 @
88aaa88 @
     88 @
     88 @
     dP @
oooooooo@
        @@
888888P @
88'     @
88baaa. @
    \`88 @
     88 @
d88888P @
oooooooo@
        @@
.d8888P @
88'     @
88baaa. @
88\` \`88 @
8b. .d8 @
\`Y888P' @
oooooooo@
        @@
d88888P @
    d8' @
   d8'  @
  d8'   @
 d8'    @
d8'     @
oooooooo@
        @@
.d888b. @
Y8' \`8P @
d8bad8b @
88\` \`88 @
8b. .88 @
Y88888P @
oooooooo@
        @@
.d888b. @
Y8' \`88 @
\`8bad88 @
    \`88 @
d.  .88 @
\`8888P  @
oooooooo@
        @@
dP @
88 @
   @
   @
dP @
88 @
ooo@
   @@
 dP @
 88 @
    @
    @
 dP @
 88 @
~.P~@
    @@
   d8 @
  d8' @
 d8'  @
 Y8.  @
  Y8. @
   Y8 @
oooooo@
      @@
         @
         @
aaaaaaaa @
         @
88888888 @
         @
ooooooooo@
         @@
8b   @
\`8b  @
 \`8b @
 .8P @
.8P  @
8P   @
ooooo@
     @@
.d8888ba  @
\`8'   \`8b @
     .d8' @
   d8P'   @
   ""     @
   oo     @
oooooooooo@
          @@
 a88888b. @
d8'   \`88 @
88 d8P 88 @
88 Yo8b88 @
Y8.       @
 Y88888P' @
oooooooooo@
          @@
 .d888888  @
d8'    88  @
88aaaaa88a @
88     88  @
88     88  @
88     88  @
ooooooooooo@
           @@
 888888ba  @
 88    \`8b @
a88aaaa8P' @
 88   \`8b. @
 88    .88 @
 88888888P @
ooooooooooo@
           @@
 a88888b. @
d8'   \`88 @
88        @
88        @
Y8.   .88 @
 Y88888P' @
oooooooooo@
          @@
888888ba  @
88    \`8b @
88     88 @
88     88 @
88    .8P @
8888888P  @
oooooooooo@
          @@
 88888888b @
 88        @
a88aaaa    @
 88        @
 88        @
 88888888P @
ooooooooooo@
           @@
 88888888b @
 88        @
a88aaaa    @
 88        @
 88        @
 dP        @
ooooooooooo@
           @@
 .88888.  @
d8'   \`88 @
88        @
88   YP88 @
Y8.   .88 @
 \`88888'  @
oooooooooo@
          @@
dP     dP  @
88     88  @
88aaaaa88a @
88     88  @
88     88  @
dP     dP  @
ooooooooooo@
           @@
dP @
88 @
88 @
88 @
88 @
dP @
ooo@
   @@
       dP @
       88 @
       88 @
       88 @
88.  .d8P @
 \`Y8888'  @
oooooooooo@
          @@
dP     dP @
88   .d8' @
88aaa8P'  @
88   \`8b. @
88     88 @
dP     dP @
oooooooooo@
          @@
dP        @
88        @
88        @
88        @
88        @
88888888P @
oooooooooo@
          @@
8888ba.88ba  @
88  \`8b  \`8b @
88   88   88 @
88   88   88 @
88   88   88 @
dP   dP   dP @
ooooooooooooo@
             @@
888888ba  @
88    \`8b @
88     88 @
88     88 @
88     88 @
dP     dP @
oooooooooo@
          @@
 .88888.  @
d8'   \`8b @
88     88 @
88     88 @
Y8.   .8P @
 \`8888P'  @
oooooooooo@
          @@
 888888ba  @
 88    \`8b @
a88aaaa8P' @
 88        @
 88        @
 dP        @
ooooooooooo@
           @@
 .88888.   @
d8'   \`8b  @
88     88  @
88  db 88  @
Y8.  Y88P  @
 \`8888PY8b @
ooooooooooo@
           @@
 888888ba  @
 88    \`8b @
a88aaaa8P' @
 88   \`8b. @
 88     88 @
 dP     dP @
ooooooooooo@
           @@
.d88888b  @
88.    "' @
\`Y88888b. @
      \`8b @
d8'   .8P @
 Y88888P  @
oooooooooo@
          @@
d888888P @
   88    @
   88    @
   88    @
   88    @
   dP    @
ooooooooo@
         @@
dP     dP @
88     88 @
88     88 @
88     88 @
Y8.   .8P @
\`Y88888P' @
oooooooooo@
          @@
dP     dP @
88     88 @
88    .8P @
88    d8' @
88  .d8P  @
888888'   @
oooooooooo@
          @@
dP   dP   dP @
88   88   88 @
88  .8P  .8P @
88  d8'  d8' @
88.d8P8.d8P  @
8888' Y88'   @
ooooooooooooo@
             @@
dP    dP @
Y8.  .8P @
 Y8aa8P  @
d8'  \`8b @
88    88 @
dP    dP @
ooooooooo@
         @@
dP    dP @
Y8.  .8P @
 Y8aa8P  @
   88    @
   88    @
   dP    @
ooooooooo@
         @@
d8888888P @
     .d8' @
   .d8'   @
 .d8'     @
d8'       @
Y8888888P @
oooooooooo@
          @@
8888P @
88    @
88    @
88    @
88    @
88888 @
oooooo@
      @@
Yb      @
\`Yb     @
 \`Yb    @
  \`Yb   @
   \`Yb  @
     88 @
oooooooo@
        @@
d8888 @
   88 @
   88 @
   88 @
   88 @
88888 @
oooooo@
      @@
   db    @
 d8'\`8b  @
\`"    "' @
         @
         @
         @
ooooooooo@
         @@
             @
             @
             @
             @
             @
             @
 vvvvvvvvvvv @
 """"""""""" @@
dP @
88 @
Y. @
   @
   @
   @
ooo@
   @@
         @
         @
.d8888b. @
88'  \`88 @
88.  .88 @
\`88888P8 @
ooooooooo@
         @@
dP       @
88       @
88d888b. @
88'  \`88 @
88.  .88 @
88Y8888' @
ooooooooo@
         @@
         @
         @
.d8888b. @
88'  \`"" @
88.  ... @
\`88888P' @
ooooooooo@
         @@
      dP @
      88 @
.d888b88 @
88'  \`88 @
88.  .88 @
\`88888P8 @
ooooooooo@
         @@
         @
         @
.d8888b. @
88ooood8 @
88.  ... @
\`88888P' @
ooooooooo@
         @@
.8888b @
88   " @
88aaa  @
88     @
88     @
dP     @
ooooooo@
       @@
         @
         @
.d8888b. @
88'  \`88 @
88.  .88 @
\`8888P88 @
o~~~~.88~@
 d8888P  @@
dP       @
88       @
88d888b. @
88'  \`88 @
88    88 @
dP    dP @
ooooooooo@
         @@
oo @
   @
dP @
88 @
88 @
dP @
ooo@
   @@
oo @
   @
dP @
88 @
88 @
88 @
88~@
dP @@
dP       @
88       @
88  .dP  @
88888"   @
88  \`8b. @
dP   \`YP @
ooooooooo@
         @@
dP @
88 @
88 @
88 @
88 @
dP @
ooo@
   @@
           @
           @
88d8b.d8b. @
88'\`88'\`88 @
88  88  88 @
dP  dP  dP @
ooooooooooo@
           @@
         @
         @
88d888b. @
88'  \`88 @
88    88 @
dP    dP @
ooooooooo@
         @@
         @
         @
.d8888b. @
88'  \`88 @
88.  .88 @
\`88888P' @
ooooooooo@
         @@
          @
          @
 88d888b. @
 88'  \`88 @
 88.  .88 @
 88Y888P' @
~88~oooooo@
 dP       @@
         @
         @
.d8888b. @
88'  \`88 @
88.  .88 @
\`8888P88 @
ooooo~88~@
      dP @@
         @
         @
88d888b. @
88'  \`88 @
88       @
dP       @
ooooooooo@
         @@
         @
         @
.d8888b. @
Y8ooooo. @
      88 @
\`88888P' @
ooooooooo@
         @@
  dP   @
  88   @
d8888P @
  88   @
  88   @
  dP   @
ooooooo@
       @@
         @
         @
dP    dP @
88    88 @
88.  .88 @
\`88888P' @
ooooooooo@
         @@
         @
         @
dP   .dP @
88   d8' @
88 .88'  @
8888P'   @
ooooooooo@
         @@
           @
           @
dP  dP  dP @
88  88  88 @
88.88b.88' @
8888P Y8P  @
ooooooooooo@
           @@
         @
         @
dP.  .dP @
 \`8bd8'  @
 .d88b.  @
dP'  \`dP @
ooooooooo@
         @@
         @
         @
dP    dP @
88    88 @
88.  .88 @
\`8888P88 @
o~~~~.88~@
 d8888P  @@
         @
         @
d888888b @
   .d8P' @
 .Y8P    @
d888888P @
ooooooooo@
         @@
  .d88P @
  8:    @
.oY8.   @
  d8    @
  8:    @
  \`Y88b @
oooooooo@
        @@
dP @
88 @
"' @
dP @
88 @
"' @
ooo@
   @@
d88b.   @
   :8   @
  .8Yo. @
   8b   @
   :8   @
Y88P'   @
oooooooo@
        @@
 .oo.  .d @
dP" "d8P  @
          @
          @
          @
          @
oooooooooo@
          @@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
`