export default `flf2a$ 5 4 13 0 10 0 3904 96
SmScript by Glenn Chappell 4/93 -- based on Script
Includes ISO Latin-1
figlet release 2.1 -- 12 Aug 1994
Permission is hereby given to modify this font, as long as the
modifier's name is placed on a comment line.

Modified by Paul Burton <solution@earthlink.net> 12/96 to include new parameter
supported by FIGlet and FIGWin.  May also be slightly modified for better use
of new full-width/kern/smush alternatives, but default output is NOT changed.

$ $@
$ $@
$ $@
$ $@
$ $@@
  @
 |@
 |@
 o@
  @@
 oo@
 ||@
  $@
  $@
   @@
      @
 _|_|_@
 _|_|_@
  | | @
      @@
      @
  |_|_@
 (|_| @
 _|_|)@
  | | @@
      @
 () / @
   /  @
  / ()@
      @@
    @
 () @
 /\\/@
 \\/\\@
    @@
 o@
 /@
 $@
 $@
  @@
   @
  /@
 | @
 | @
  \\@@
   @
 \\ @
  |@
  |@
 / @@
      @
  \\|/ @
 --*--@
  /|\\ @
      @@
      @
   |  @
 --+--@
   |  @
      @@
  @
  @
  @
 o@
 /@@
     @
     @
 ----@
   $ @
     @@
  @
  @
  @
 o@
  @@
    @
   /@
  / @
 /  @
    @@
   _  @
  / \\ @
 |   |@
  \\_/ @
      @@
  ,@
 /|@
  |@
  |@
   @@
  _ @
 / )@
  / @
 /__@
    @@
 ____@
  __/@
  $ \\@
 \\__/@
     @@
      @
 |  | @
 |__|_@
    | @
      @@
  ___@
 |__ @
  $ \\@
 \\__/@
     @@
   _ @
  /_ @
 |/ \\@
  \\_/@
     @@
 ____@
   $/@
   / @
  /  @
     @@
  __ @
 (__)@
 /  \\@
 \\__/@
     @@
  __ @
 /  |@
 \\_/|@
    |@
     @@
  @
 o@
 $@
 o@
  @@
  @
 o@
 $@
 o@
 /@@
   @
  /@
 < @
  \\@
   @@
     @
 ____@
 ____@
   $ @
     @@
   @
 \\ @
  >@
 / @
   @@
 __ @
   )@
  | @
  o @
    @@
   ____  @
  / __,\\ @
 | /  | |@
 | \\_/|/ @
  \\____/ @@
   __,  @
  /  |  @
 |   |  @
  \\_/\\_/@
        @@
  , _ @
 /|/_)@
  |  \\@
  |(_/@
      @@
   __$ @
  / () @
 |  $  @
  \\___/@
       @@
 $___  @
 (|  \\ @
  |   |@
 (\\__/ @
       @@
  __$ @
 / () @
 >-$  @
 \\___/@
      @@
 $_____@
 () |_$@
   /| |@
  (/   @
       @@
      @
  () |@
  /\\/|@
 /(_/ @
      @@
  ,    @
 /|  | @
  |--| @
  |  |)@
       @@
      @
   |\\ @
 _ |/ @
 \\_/\\/@
      @@
     @
  /| @
 | | @
  \\|/@
  (| @@
  ,  , @
 /|_/  @
  |\\   @
  | \\_/@
       @@
   $   @
 \\_|)  @
   |   @
  (\\__/@
       @@
  ,_ _   @
 /| | |  @
  | | |  @
  | | |_/@
         @@
  ,     @
 /|/\\   @
  |  |  @
  |  |_/@
        @@
   __  @
  /\\_\\/@
 |    |@
  \\__/ @
       @@
  , _ @
 /|/ \\@
  |__/@
  |  $@
      @@
   __    @
  /__\\   @
 |/  \\|  @
  \\__/\\_/@
         @@
  , _  @
 /|/ \\ @
  |__/ @
  | \\_/@
       @@
     @
  () @
  /\\ @
 /(_)@
     @@
 $_____@
 () |  @
   $|  @
  (/   @
       @@
         @
 (|   |  @
  |   |  @
   \\_/\\_/@
         @@
        @
 (|  |_/@
  |  |  @
   \\/   @
        @@
           @
 (|  |  |_/@
  |  |  |  @
   \\/ \\/   @
           @@
        @
 (\\  /  @
   ><   @
 _/  \\_/@
        @@
       @
 (|  | @
  |  | @
   \\/|/@
    (| @@
  _  @
 / ) @
  /  @
 /__/@
  (| @@
  _@
 | @
 | @
 | @
 |_@@
    @
 \\  @
  \\ @
   \\@
    @@
 _ @
  |@
  |@
  |@
 _|@@
 /\\@
  $@
  $@
  $@
   @@
     @
     @
     @
   $ @
 ____@@
 o@
 \\@
 $@
 $@
  @@
      @
  _,  @
 / |  @
 \\/|_/@
      @@
     @
 |)  @
 |/\\_@
  \\/ @
     @@
     @
  _  @
 /   @
 \\__/@
     @@
      @
  _|  @
 / |  @
 \\/|_/@
      @@
    @
  _ @
 |/ @
 |_/@
    @@
    @
 |\\ @
 |/ @
 |_/@
 |) @@
     @
  _, @
 / | @
 \\/|/@
  (| @@
      @
 |)   @
 |/\\  @
 |  |/@
      @@
   @
 o @
 | @
 |/@
   @@
    @
  o @
  | @
  |/@
 (| @@
     @
 |)  @
 |/) @
 | \\/@
     @@
    @
 |\\ @
 |/ @
 |_/@
    @@
         @
         @
 /|/|/|  @
 $| | |_/@
         @@
       @
       @
 /|/|  @
 $| |_/@
       @@
     @
  _  @
 / \\_@
 \\_/ @
     @@
      @
      @
  |/\\_@
  |_/ @
 (|   @@
      @
  _,  @
 / |  @
 \\/|_/@
   |) @@
      @
  ,_  @
 /  | @
 $  |/@
      @@
     @
  ,  @
 / \\_@
 $\\/ @
     @@
     @
 _|_ @
  |  @
  |_/@
     @@
       @
       @
 |  |  @
 $\\/|_/@
       @@
      @
      @
 |  |_@
 $\\/  @
      @@
         @
         @
 |  |  |_@
 $\\/ \\/  @
         @@
     @
     @
 /\\/ @
 $/\\/@
     @@
      @
      @
 |  | @
 $\\/|/@
   (| @@
      @
  __  @
 / / _@
 $/_/ @
   (| @@
    @
   /@
 _| @
  | @
   \\@@
 |@
 |@
 |@
 |@
 |@@
    @
 \\  @
  |_@
  | @
 /  @@
 /\\/@
  $ @
  $ @
  $ @
    @@
 o  o  @
  __,  @
 /  |  @
 \\_/\\_/@
       @@
 o  o @
  __  @
 /\\_\\/@
 \\__/ @
      @@
   /\\/   @
         @
 (|   |  @
   \\_/\\_/@
         @@
 o o  @
  _,  @
 / |  @
 \\/|_/@
      @@
 o o @
  _  @
 / \\_@
 \\_/ @
     @@
 o  o  @
       @
 |  |  @
 $\\/|_/@
       @@
  _ @
 | \\@
 | <@
 |_/@
 |  @@
160  NO-BREAK SPACE
 $@
 $@
 $@
 $@
 $@@
161  INVERTED EXCLAMATION MARK
  @
 o@
 |@
 |@
  @@
162  CENT SIGN
      @
  _|_ @
 / |  @
 \\_|_/@
   |  @@
163  POUND SIGN
   _  @
 _|_\` @
  |   @
 (\\__/@
      @@
164  CURRENCY SIGN
 \\ _ /@
  / \\ @
  \\_/ @
 /   \\@
      @@
165  YEN SIGN
 \\   /@
 _\\_/_@
 __|__@
   |  @
      @@
166  BROKEN BAR
 |@
 |@
  @
 |@
 |@@
167  SECTION SIGN
  _@
 ( @
 ()@
 _)@
   @@
168  DIAERESIS
 o o@
 $ $@
 $ $@
 $ $@
    @@
169  COPYRIGHT SIGN
   ____  @
  / __ \\ @
 | / () |@
 | \\__/ |@
  \\____/ @@
170  FEMININE ORDINAL INDICATOR
  _, @
 (_|_@
 --- @
  $  @
     @@
171  LEFT-POINTING DOUBLE ANGLE QUOTATION MARK
    @
  //@
 << @
  \\\\@
    @@
172  NOT SIGN
    @
 __ @
   |@
  $ @
    @@
173  SOFT HYPHEN
    @
    @
 ---@
  $ @
    @@
174  REGISTERED SIGN
   ____  @
  / ,_ \\ @
 | /|_) |@
 |  |\\/ |@
  \\____/ @@
175  MACRON
 ____@
   $ @
   $ @
   $ @
     @@
176  DEGREE SIGN
 ()@
  $@
  $@
  $@
   @@
177  PLUS-MINUS SIGN
      @
   |  @
 --+--@
 __|__@
      @@
178  SUPERSCRIPT TWO
 _ @
  )@
 /_@
  $@
   @@
179  SUPERSCRIPT THREE
 ___@
  _/@
 __)@
  $ @
    @@
180  ACUTE ACCENT
 /@
 $@
 $@
 $@
  @@
181  MICRO SIGN
       @
       @
 |  |  @
 |\\/|_/@
 |     @@
182  PILCROW SIGN
  ___ @
 / | |@
 \\_| |@
   | |@
      @@
183  MIDDLE DOT
    @
    @
 $O$@
  $ @
    @@
184  CEDILLA
   @
   @
   @
 $ @
 _)@@
185  SUPERSCRIPT ONE
  ,@
 /|@
  |@
  $@
   @@
186  MASCULINE ORDINAL INDICATOR
  __@
 (_)@
 ---@
  $ @
    @@
187  RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK
    @
 \\\\ @
  >>@
 // @
    @@
188  VULGAR FRACTION ONE QUARTER
  ,     @
 /| /   @
  |/|_|_@
  /   | @
        @@
189  VULGAR FRACTION ONE HALF
  ,    @
 /| /_ @
  |/  )@
  /  /_@
       @@
190  VULGAR FRACTION THREE QUARTERS
 ___     @
  _/ /   @
 __)/|_|_@
   /   | @
         @@
191  INVERTED QUESTION MARK
    @
  o @
  | @
 (__@
    @@
192  LATIN CAPITAL LETTER A WITH GRAVE
  \\    @
  __,  @
 /  |  @
 \\_/\\_/@
       @@
193  LATIN CAPITAL LETTER A WITH ACUTE
   /   @
  __,  @
 /  |  @
 \\_/\\_/@
       @@
194  LATIN CAPITAL LETTER A WITH CIRCUMFLEX
  /\\   @
  __,  @
 /  |  @
 \\_/\\_/@
       @@
195  LATIN CAPITAL LETTER A WITH TILDE
  /\\/  @
  __,  @
 /  |  @
 \\_/\\_/@
       @@
196  LATIN CAPITAL LETTER A WITH DIAERESIS
 o  o  @
  __,  @
 /  |  @
 \\_/\\_/@
       @@
197  LATIN CAPITAL LETTER A WITH RING ABOVE
   _   @
  (_)  @
 /  |  @
 \\_/\\_/@
       @@
198  LATIN CAPITAL LETTER AE
   __,__$ @
  /  | () @
 |   |-$  @
  \\_/\\___/@
          @@
199  LATIN CAPITAL LETTER C WITH CEDILLA
   __$ @
  / () @
 |  $  @
  \\___/@
   _)  @@
200  LATIN CAPITAL LETTER E WITH GRAVE
  \\   @
  __$ @
 <_() @
 <___/@
      @@
201  LATIN CAPITAL LETTER E WITH ACUTE
   /  @
  __$ @
 <_() @
 <___/@
      @@
202  LATIN CAPITAL LETTER E WITH CIRCUMFLEX
  /\\  @
  __$ @
 <_() @
 <___/@
      @@
203  LATIN CAPITAL LETTER E WITH DIAERESIS
 o  o @
  __$ @
 <_() @
 <___/@
      @@
204  LATIN CAPITAL LETTER I WITH GRAVE
   \\  @
   |\\ @
 _ |/ @
 \\_/\\/@
      @@
205  LATIN CAPITAL LETTER I WITH ACUTE
    / @
   |\\ @
 _ |/ @
 \\_/\\/@
      @@
206  LATIN CAPITAL LETTER I WITH CIRCUMFLEX
   /\\ @
   |\\ @
 _ |/ @
 \\_/\\/@
      @@
207  LATIN CAPITAL LETTER I WITH DIAERESIS
  o o @
   |\\ @
 _ |/ @
 \\_/\\/@
      @@
208  LATIN CAPITAL LETTER ETH
  ___  @
 (|  \\ @
 -|-  |@
 (\\__/ @
       @@
209  LATIN CAPITAL LETTER N WITH TILDE
  ,/\\/  @
 /|/\\   @
  |  |  @
  |  |_/@
        @@
210  LATIN CAPITAL LETTER O WITH GRAVE
  \\   @
  __  @
 /\\_\\/@
 \\__/ @
      @@
211  LATIN CAPITAL LETTER O WITH ACUTE
   /  @
  __  @
 /\\_\\/@
 \\__/ @
      @@
212  LATIN CAPITAL LETTER O WITH CIRCUMFLEX
  /\\  @
  __  @
 /\\_\\/@
 \\__/ @
      @@
213  LATIN CAPITAL LETTER O WITH TILDE
  /\\/ @
  __  @
 /\\_\\/@
 \\__/ @
      @@
214  LATIN CAPITAL LETTER O WITH DIAERESIS
 o  o @
  __  @
 /\\_\\/@
 \\__/ @
      @@
215  MULTIPLICATION SIGN
     @
 $\\/$@
 $/\\$@
 $  $@
     @@
216  LATIN CAPITAL LETTER O WITH STROKE
   __/ @
  /\\/\\/@
 | /  |@
  /__/ @
 /     @@
217  LATIN CAPITAL LETTER U WITH GRAVE
    \\    @
         @
 (|   |  @
   \\_/\\_/@
         @@
218  LATIN CAPITAL LETTER U WITH ACUTE
    /    @
         @
 (|   |  @
   \\_/\\_/@
         @@
219  LATIN CAPITAL LETTER U WITH CIRCUMFLEX
    /\\   @
         @
 (|   |  @
   \\_/\\_/@
         @@
220  LATIN CAPITAL LETTER U WITH DIAERESIS
   /\\/   @
         @
 (|   |  @
   \\_/\\_/@
         @@
221  LATIN CAPITAL LETTER Y WITH ACUTE
    /  @
       @
 (|  | @
   \\/|/@
    (| @@
222  LATIN CAPITAL LETTER THORN
  ,   @
 /|__ @
  |__)@
  |  $@
      @@
223  LATIN SMALL LETTER SHARP S
  _ @
 | \\@
 | <@
 |_/@
 |  @@
224  LATIN SMALL LETTER A WITH GRAVE
  \\   @
  _,  @
 / |  @
 \\/|_/@
      @@
225  LATIN SMALL LETTER A WITH ACUTE
  /   @
  _,  @
 / |  @
 \\/|_/@
      @@
226  LATIN SMALL LETTER A WITH CIRCUMFLEX
  /\\  @
  _,  @
 / |  @
 \\/|_/@
      @@
227  LATIN SMALL LETTER A WITH TILDE
 /\\/  @
  _,  @
 / |  @
 \\/|_/@
      @@
228  LATIN SMALL LETTER A WITH DIAERESIS
 o o  @
  _,  @
 / |  @
 \\/|_/@
      @@
229  LATIN SMALL LETTER A WITH RING ABOVE
  ()  @
  _,  @
 / |  @
 \\/|_/@
      @@
230  LATIN SMALL LETTER AE
      @
  _,_ @
 / |/ @
 \\/|_/@
      @@
231  LATIN SMALL LETTER C WITH CEDILLA
     @
  _  @
 /   @
 \\__/@
  _) @@
232  LATIN SMALL LETTER E WITH GRAVE
  \\ @
  _ @
 |/ @
 |_/@
    @@
233  LATIN SMALL LETTER E WITH ACUTE
  / @
  _ @
 |/ @
 |_/@
    @@
234  LATIN SMALL LETTER E WITH CIRCUMFLEX
 /\\ @
  _ @
 |/ @
 |_/@
    @@
235  LATIN SMALL LETTER E WITH DIAERESIS
 o o @
  _  @
 |/  @
 |__/@
     @@
236  LATIN SMALL LETTER I WITH GRAVE
 \\ @
   @
 | @
 |/@
   @@
237  LATIN SMALL LETTER I WITH ACUTE
 / @
   @
 | @
 |/@
   @@
238  LATIN SMALL LETTER I WITH CIRCUMFLEX
 /\\@
   @
 | @
 |/@
   @@
239  LATIN SMALL LETTER I WITH DIAERESIS
 o o @
     @
 |   @
 |__/@
     @@
240  LATIN SMALL LETTER ETH
 \\, @
 '\\ @
 / |@
 \\/ @
    @@
241  LATIN SMALL LETTER N WITH TILDE
  /\\/  @
       @
 /|/|  @
 $| |_/@
       @@
242  LATIN SMALL LETTER O WITH GRAVE
  \\  @
  _  @
 / \\_@
 \\_/ @
     @@
243  LATIN SMALL LETTER O WITH ACUTE
  /  @
  _  @
 / \\_@
 \\_/ @
     @@
244  LATIN SMALL LETTER O WITH CIRCUMFLEX
  /\\ @
  _  @
 / \\_@
 \\_/ @
     @@
245  LATIN SMALL LETTER O WITH TILDE
 /\\/ @
  _  @
 / \\_@
 \\_/ @
     @@
246  LATIN SMALL LETTER O WITH DIAERESIS
 o o @
  _  @
 / \\_@
 \\_/ @
     @@
247  DIVISION SIGN
    @
  O @
 ---@
  O @
    @@
248  LATIN SMALL LETTER O WITH STROKE
      @
  __/ @
 / /\\_@
 \\/_/ @
 /    @@
249  LATIN SMALL LETTER U WITH GRAVE
  \\    @
       @
 |  |  @
 $\\/|_/@
       @@
250  LATIN SMALL LETTER U WITH ACUTE
   /   @
       @
 |  |  @
 $\\/|_/@
       @@
251  LATIN SMALL LETTER U WITH CIRCUMFLEX
  /\\   @
       @
 |  |  @
 $\\/|_/@
       @@
252  LATIN SMALL LETTER U WITH DIAERESIS
 o  o  @
       @
 |  |  @
 $\\/|_/@
       @@
253  LATIN SMALL LETTER Y WITH ACUTE
   /  @
      @
 |  | @
 $\\/|/@
   (| @@
254  LATIN SMALL LETTER THORN
      @
  |)  @
  |/\\_@
  |_/ @
 (|   @@
255  LATIN SMALL LETTER Y WITH DIAERESIS
 o  o @
      @
 |  | @
 $\\/|/@
   (| @@
`