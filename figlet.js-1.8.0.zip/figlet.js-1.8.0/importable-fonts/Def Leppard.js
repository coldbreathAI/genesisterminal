export default `flf2a$ 16 14 28 0 11 0 64 229
Def Leppard by Hanspeter Niederstrasser 2003-06-29 -- based on Standard
Includes all of ASCII and most of ISO Latin-1
figlet release 2.2 -- 19 Feb 1997

Changes:
  Markus Gebhard 1/2004: Fixed character 215 being one line too long

---

Font modified June 17, 2007 by patorjk 
This was to widen the space character.
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@
$    $@@
      @
      @
      @
  ;f. @
  i##:@
  i##:@
  i##:@
  i##:@
 $i##:@
  i##:@
  i##:@
  i#W.@
  ,i. @
  :G#:@
  iKt @
      @@
        @
        @
        @
  ,  :  @
  EW;EW;@
   i; i;@
     $  @
     $  @
 $   $  @
     $  @
     $  @
     $  @
     $  @
        @
        @
        @@
                  @
                  @
                  @
                  @
     D,   tj      @
     ##G  f#W,    @
  :tt##WttD##Ltt. @
  ;WW###WW####WWWj@
 $   ##K  f##i    @
  ,LL##WLLE##DLL, @
  ;EE###EEW##KEEEj@
     WWE  jWW;    @
                $ @
                  @
                  @
                  @@
       @
       @
       @
       @
       @
    _  @
   | | @
  / __)@
 $\\__ \\@
  (   /@
   |_| @
       @
       @
       @
       @
       @@
             @
  $          @
             @
   ;        ;@
  iij      fW@
   .     ,KG.@
        fWi  @
      :KD.   @
     jWi     @
   :ED.      @
 $tWj     .it@
  L:      .j,@
             @
            $@
             @
             @@
          @
          @
          @
          @
          @
          @
          @
          @
          @
    ___   @
   ( _ )  @
   / _ \\/\\@
 $| (_>  <@
   \\___/\\/@
          @
          @@
     @
     @
  .  @
 $EK,@
  .j;@
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
     @
     @@
        @
        @
  $     @
        @
     :f:@
   ;D#E.@
  i##;  @
  i##:  @
 $i##:  @
  i##:  @
  i##:  @
  i##:  @
  :G#Kt @
    .jW:@
  $     @
        @@
        @
        @
       $@
  .     @
  iWj.  @
   tE#G.@
    i##:@
    i##:@
 $  i##:@
    i##:@
    i##:@
    j##:@
  ,K#L: @
  ,t    @
       $@
        @@
        @
        @
        @
        @
        @
        @
        @
  __/\\__@
 $\\    /@
  /_  _\\@
    \\/  @
        @
        @
        @
        @
        @@
               @
               @
   $         $ @
               @
      Gf.      @
      G##      @
      G##      @
 $;WWW###WWWWf.@
  :tttE##tttttt@
      G##      @
      :;;      @
   $         $ @
               @
               @
               @
               @@
     @
     @
     @
     @
     @
     @
     @
     @
     @
     @
     @
   ; @
 $t#i@
  .W.@
   : @
     @@
           @
      $    @
      $    @
      $    @
      $    @
      $    @
      $    @
  .......  @
 $GEEEEEEf.@
      $    @
      $    @
      $    @
      $    @
      $    @
           @
           @@
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
 $.j @
  ;f.@
     @@
             @
             @
             @
             @
  $        :E@
          tWj@
        .DE: @
       iWf   @
     .GK,    @
    ;Wf      @
   LK,       @
 $DL.      $ @
  :          @
             @
             @
             @@
             @
             @
             @
             @
             @
  $    :     @
      G#j    @
    .E#G#G   @
   ,W#; ;#E. @
 $i#K:   :WW:@
  :WW:   f#D.@
   .E#; G#L  @
     G#K#j   @
      j#;  $ @
             @
             @@
     @
     @
     @
   $ @
     @
   jt@
  G#t@
  E#t@
  E#t@
 $E#t@
  E#t@
  E#t@
  E#t@
  tf,@
     @
     @@
             @
             @
             @
  t          @
  EE.        @
  :KW;    $  @
    G#j      @
     j#D.    @
 $itttG#K,   @
  E##DDDDG:  @
  E#E        @
  E#E        @
  E##EEEEEEt @
  tffffffffft@
             @
             @@
           @
           @
           @
   L     $ @
   #K:     @
   :K#t    @
     L#G.  @
      t#W, @
   .jffD##f@
 $.fLLLD##L@
      ;W#i @
     j#E.  @
   .D#f    @
   KW,     @
   G.    $ @
           @@
               @
               @
           .   @
          ,W   @
         i##   @
        f###   @
       G####   @
     .K#Ki##   @
    ,W#D.,##   @
   i##E,,i##,  @
 $;DDDDDDE##DGi@
         ,##   @
  $      ,##   @
         .E#   @
           t   @
               @@
             @
             @
             @
  $       $  @
             @
  :,,,,,,,,,,@
  E########D,@
  E#K......  @
  E#E        @
  E#Wfffff:  @
 $jLLLE##t   @
     ;#K,    @
    j#D.  $  @
   G#f       @
  D#;        @
  G:         @@
          @
          @
          @
        j,@
  $    L#,@
      D#D @
    .K#f  @
   :W#i   @
  ;##Dfff.@
 $;##Lt##,@
   :W#;##,@
    .E###,@
      G##,@
  $    f#,@
        t:@
          @@
                 @
                 @
   $           $ @
                 @
 $:;;;;;;;;;;;;;.@
   jWWWWWWWW###L @
           ,W#f  @
          ,##f   @
   $     i##j    @
        i##t   $ @
       t##t    $ @
      t##i     $ @
     j##;      $ @
    :##,       $ @
    ,W,          @
    ::           @@
           @
           @
  $      $ @
           @
     t,    @
     tW:   @
  $  t#W.  @
     tEDE  @
  ...jK:KD @
 $E#fDWfff:@
   GEjE    @
    G#E    @
     GE    @
  $   t  $ @
           @
           @@
         @
         @
         @
  G:     @
  EW,    @
  E##;   @
  E###t  @
  E#jD#f @
 $E#EL##G@
  ,;;t##t@
    ,W#; @
   i#W,  @
  f#K.   @
  ED.    @
  j      @
         @@
     @
     @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
     @
   : @
 $tK.@
     @
  iK.@
     @@
     @
     @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
     @
 $,W,@
     @
  .D.@
  t#i@
   G @@
            @
            @
            @
          $ @
  $         @
          .i@
       ;jji.@
   :tjj:    @
 $tDt.      @
    .tjj;   @
        ,jft@
           .@
  $         @
          $ @
            @
            @@
            @
            @
            @
            @
   $      $ @
            @
  ......... @
  GEEEEEEED;@
  ,;;;;;;;, @
 $jLLLLLLLL;@
    $    $  @
    $    $  @
    $    $  @
    $    $  @
      $     @
            @@
             @
             @
             @
  $          @
           $ @
 $;,         @
   ;jjt.     @
      .tjj;  @
         ;GL.@
     :tjt:   @
  ;jj;       @
  .          @
           $ @
  $          @
             @
             @@
                  @
    tttttttttttttt@
 $.E############W,@
  ...........t#E. @
            f#f   @
          .E#i    @
         ;WK:     @
        f#D.      @
       ,##        @
       ,##        @
       .K#        @
         :        @
       :Gi        @
        .j        @
                  @
                  @@
           @
           @
           @
           @
           @
     ____  @
    / __ \\ @
   / / _\` |@
 $| | (_| |@
   \\ \\__,_|@
    \\____/ @
           @
           @
           @
           @
           @@
               @
               @
               @
               @
             ..@
            ;W,@
           j##,@
          G###,@
   $    :E####,@
       ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
             @
             @
             @
  .          @
  Ef.        @
  E#Wi       @
  E#K#D:   $ @
  E#t,E#f.   @
  E#WEE##Wt  @
 $E##Ei;;;;. @
  E#DWWt     @
  E#t f#K;   @
  E#Dfff##E, @
  jLLLLLLLLL;@
             @
             @@
          @
          @
        .,@
       ,Wt@
  $   i#D.@
     f#f  @
   .D#i   @
  :KW,    @
 $t#f    $@
   ;#G    @
    :KE.  @
  $  .DW: @
       L#,@
        jt@
          @
          @@
  ;           @
  ED.         @
  E#Wi        @
  E###G.      @
  E#fD#W;   $ @
  E#t t##L    @
  E#t  .E#K,  @
 $E#t    j##f @
  E#t    :E#K:@
  E#t   t##L  @
  E#t .D#W;   @
  E#tiW#G.  $ @
  E#K##i      @
  E##D.       @
  E#t         @
  L:          @@
            @
            @
          ,;@
        f#i @
  $   .E#t  @
     i#W,   @
    L#D.    @
  :K#Wfff;  @
 $i##WLLLLt @
   .E#L     @
     f#E:   @
  $   ,WW;  @
       .D#; @
         tt @
            @
            @@
     ,       @
     Et      @
     E#t     @
     E##t    @
     E#W#t   @
  $  E#tfL.  @
     E#t     @
 $,ffW#Dffj. @
   ;LW#ELLLf.@
     E#t     @
  $  E#t   $ @
     E#t     @
     E#t     @
     E#t     @
     ;#t     @
      :;     @@
             @
             @
             @
          .Gt@
         j#W:@
   $   ;K#f  @
     .G#D.   @
    j#K;     @
 $,K#f   ,GD;@
   j#Wi   E#t@
    .G#D: E#t@
      ,K#fK#t@
  $     j###t@
         .G#t@
           ;;@
             @@
             @
             @
  $          @
  .    .     @
  Di   Dt  $ @
  E#i  E#i   @
  E#t  E#t   @
  E#t  E#t   @
 $E########f.@
  E#j..K#j...@
  E#t  E#t   @
  E#t  E#t   @
  f#t  f#t   @
   ii   ii   @
             @
             @@
     @
     @
     @
  t  @
  Ej @
  E#,@
  E#t@
  E#t@
 $E#t@
  E#t@
  E#t@
  E#t@
  E#t@
  E#t@
  ,;.@
     @@
           @
  $      $ @
           @
  itttttttt@
 $fDDK##DDi@
     t#E   @
     t#E   @
     t#E   @
     t#E   @
     t#E   @
   jfL#E   @
   :K##E   @
     G#E   @
      tE   @
       .   @
           @@
          @
          @
  G:    $ @
  E#,    :@
  E#t  .GE@
  E#t j#K;@
  E#GK#f  @
  E##D.   @
 $E##Wi   @
  E#jL#D: @
  E#t ,K#j@
  E#t   jD@
  j#t     @
   ,;   $ @
          @
          @@
                 @
                 @
                 @
             i   @
            LE   @
       $   L#E   @
          G#W.   @
         D#K.    @
        E#K.     @
  $   .E#E.      @
     .K#E      $ @
    .K#D         @
   .W#G          @
 $:W##########Wt @
  :,,,,,,,,,,,,,.@
                 @@
                      @
                      @
                      @
                    $ @
            ..       :@
           ,W,     .Et@
          t##,    ,W#t@
  $      L###,   j###t@
       .E#j##,  G#fE#t@
      ;WW; ##,:K#i E#t@
     j#E.  ##f#W,  E#t@
   .D#L    ###K:   E#t@
 $:K#t     ##D.    E#t@
  ...      #G      .. @
           j          @
                      @@
                @
                @
  L.            @
  EW:        ,ft@
  E##;       t#E@
  E###t      t#E@
  E#fE#f     t#E@
 $E#t D#G    t#E@
  E#t  f#E.  t#E@
  E#t   t#K: t#E@
  E#t    ;#W,t#E@
  E#t     :K#D#E@
  E#t      .E##E@
  ..         G#E@
  $           fE@
               ,@@
             @
       :     @
  $   t#,  $ @
     ;##W.   @
    :#L:WE   @
   .KG  ,#D  @
   EE    ;#f @
 $f#.     t#i@
  :#G     GK @
   ;#L   LW. @
    t#f f#:  @
     f#D#;   @
      G#t    @
       t     @
             @
             @@
            @
            @
            @
  t         @
  ED.       @
  E#K:   $  @
  E##W;     @
  E#E##t    @
 $E#ti##f   @
  E#t ;##D. @
  E#ELLE##K:@
  E#L;;;;;;,@
  E#t       @
  E#t       @
            @
            @@
             @
       :     @
      t#,    @
  $  ;##W. $ @
    :#L:WE   @
   .KG  ,#D  @
   EE    ;#f @
 $f#.     t#i@
  :#G   G.GK @
   ;#L  DWW. @
  $ t#f j#L  @
     f#D#j#. @
      G#t .  @
       t     @
             @
             @@
             @
             @
             @
  j.         @
  EW,        @
  E##j       @
  E###D.   $ @
  E#jG#W;    @
 $E#t t##f   @
  E#t  :K#E: @
  E#KDDDD###i@
  E#f,t#Wi,,,@
  E#t  ;#W:  @
  DWi   ,KK: @
             @
             @@
            @
            @
           .@
          ;W@
         f#E@
  $    .E#f @
      iWW;  @
     L##Lffi@
    tLLG##L @
      ,W#i  @
     j#E.   @
   .D#j     @
  ,WK,    $ @
 $EG.       @
  ,         @
            @@
           @
           @
  $       $@
           @
 $GEEEEEEEL@
  ,;;L#K;;.@
     t#E   @
     t#E   @
     t#E   @
  $  t#E   @
     t#E   @
     t#E   @
     t#E   @
      fE   @
       :   @
           @@
         @
         @
  :      @
  Ef     @
  E#t   $@
  E#t    @
  E#t    @
 $E#t fi @
  E#t L#j@
  E#t L#L@
  E#tf#E:@
  E###f  @
  E#K,   @
  EL     @
  :      @
         @@
             @
             @
             @
  $        $ @
             @
  t      .DD.@
  EK:   ,WK. @
  E#t  i#D   @
 $E#t j#f    @
  E#tL#i   $ @
  E#WW,      @
  E#K:       @
  ED.        @
  t          @
             @
             @@
                     @
                     @
                     @
                     @
  $         ;      $ @
          .DL        @
  f.     :K#L     LWL@
  EW:   ;W##L   .E#f @
  E#t  t#KE#L  ,W#;  @
 $E#t f#D.L#L t#K:   @
  E#jG#f  L#LL#G   $ @
  E###;   L###j      @
  E#K:    L#W;       @
  EG      LE.        @
  ;       ;@         @
                     @@
             @
             @
             @
   $       $ @
             @
  :KW,      L@
   ,#W:   ,KG@
    ;#W. jWi @
 $$  i#KED.  @
      L#W.   @
    .GKj#K.  @
   iWf  i#K. @
  LK:    t#E @
  i       tDj@
             @
             @@
             @
             @
  $        $ @
             @
  f.     ;WE.@
  E#,   i#G  @
  E#t  f#f   @
  E#t G#i    @
 $E#jEW,     @
  E##E.    $ @
  E#G        @
  E#t        @
  E#t        @
  EE.        @
  t          @
             @@
                         @
                         @
                         @
       $               $ @
                         @
       ,##############Wf.@
        ........jW##Wt   @
              tW##Kt     @
     $      tW##E;     $ @
          tW##E;         @
       .fW##D,        $  @
     .f###D,             @
   .f####Gfffffffffff;   @
 $.fLLLLLLLLLLLLLLLLLi   @
                         @
                         @@
       @
       @
  DKKKD@
  K#f;,@
  K#i  @
  K#i  @
  K#i  @
  K#i  @
 $K#i  @
  K#i  @
  K#i  @
  K#i  @
  K#Lti@
  fGGGf@
       @
       @@
             @
             @
             @
             @
             @
           $ @
 $..         @
   .Ki       @
    .GG.     @
      iK;    @
  $    .DG   @
         tK; @
          :Ef@
            i@
             @
             @@
        @
  :;;;; @
  tKK##:@
     ##:@
     ##:@
     ##:@
     ##:@
     ##:@
 $   ##:@
     ##:@
     ##:@
     ##:@
  tKK##:@
  :;;;; @
        @
        @@
     @
     @
     @
     @
     @
     @
   $ @
   $ @
   $ @
     @
 $;jt@
  . .@
   $ @
   $ @
   $ @
     @@
              @
              @
              @
              @
              @
              @
              @
              @
              @
              @
  $         $ @
              @
  ,;;;;;;;;;. @
 $jLLLLLLLLLL,@
              @
              @@
    @
    @
    @
    @
  , @
 $:t@
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
    @
    @@
               @
               @
               @
               @
             ..@
            ;W,@
           j##,@
          G###,@
   $    :E####,@
       ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
             @
             @
             @
  .          @
  Ef.        @
  E#Wi       @
  E#K#D:   $ @
  E#t,E#f.   @
  E#WEE##Wt  @
 $E##Ei;;;;. @
  E#DWWt     @
  E#t f#K;   @
  E#Dfff##E, @
  jLLLLLLLLL;@
             @
             @@
          @
          @
        .,@
       ,Wt@
  $   i#D.@
     f#f  @
   .D#i   @
  :KW,    @
 $t#f    $@
   ;#G    @
    :KE.  @
  $  .DW: @
       L#,@
        jt@
          @
          @@
  ;           @
  ED.         @
  E#Wi        @
  E###G.      @
  E#fD#W;   $ @
  E#t t##L    @
  E#t  .E#K,  @
 $E#t    j##f @
  E#t    :E#K:@
  E#t   t##L  @
  E#t .D#W;   @
  E#tiW#G.  $ @
  E#K##i      @
  E##D.       @
  E#t         @
  L:          @@
            @
            @
          ,;@
        f#i @
  $   .E#t  @
     i#W,   @
    L#D.    @
  :K#Wfff;  @
 $i##WLLLLt @
   .E#L     @
     f#E:   @
  $   ,WW;  @
       .D#; @
         tt @
            @
            @@
     ,       @
     Et      @
     E#t     @
     E##t    @
     E#W#t   @
  $  E#tfL.  @
     E#t     @
 $,ffW#Dffj. @
   ;LW#ELLLf.@
     E#t     @
  $  E#t   $ @
     E#t     @
     E#t     @
     E#t     @
     ;#t     @
      :;     @@
             @
             @
             @
          .Gt@
         j#W:@
   $   ;K#f  @
     .G#D.   @
    j#K;     @
 $,K#f   ,GD;@
   j#Wi   E#t@
    .G#D: E#t@
      ,K#fK#t@
  $     j###t@
         .G#t@
           ;;@
             @@
             @
             @
  $          @
  .    .     @
  Di   Dt  $ @
  E#i  E#i   @
  E#t  E#t   @
  E#t  E#t   @
 $E########f.@
  E#j..K#j...@
  E#t  E#t   @
  E#t  E#t   @
  f#t  f#t   @
   ii   ii   @
             @
             @@
     @
     @
     @
  t  @
  Ej @
  E#,@
  E#t@
  E#t@
 $E#t@
  E#t@
  E#t@
  E#t@
  E#t@
  E#t@
  ,;.@
     @@
           @
  $      $ @
           @
  itttttttt@
 $fDDK##DDi@
     t#E   @
     t#E   @
     t#E   @
     t#E   @
     t#E   @
   jfL#E   @
   :K##E   @
     G#E   @
      tE   @
       .   @
           @@
          @
          @
  G:    $ @
  E#,    :@
  E#t  .GE@
  E#t j#K;@
  E#GK#f  @
 $E##D.   @
  E##Wi   @
  E#jL#D: @
  E#t ,K#j@
  E#t   jD@
  j#t     @
   ,;   $ @
          @
          @@
                 @
                 @
                 @
             i   @
            LE   @
       $   L#E   @
          G#W.   @
         D#K.    @
        E#K.     @
  $   .E#E.      @
     .K#E      $ @
    .K#D         @
   .W#G          @
 $:W##########Wt @
  :,,,,,,,,,,,,,.@
                 @@
                      @
                      @
                      @
                    $ @
            ..       :@
           ,W,     .Et@
          t##,    ,W#t@
  $      L###,   j###t@
       .E#j##,  G#fE#t@
      ;WW; ##,:K#i E#t@
     j#E.  ##f#W,  E#t@
   .D#L    ###K:   E#t@
 $:K#t     ##D.    E#t@
  ...      #G      .. @
           j          @
                      @@
                @
                @
  L.            @
  EW:        ,ft@
  E##;       t#E@
  E###t      t#E@
  E#fE#f     t#E@
 $E#t D#G    t#E@
  E#t  f#E.  t#E@
  E#t   t#K: t#E@
  E#t    ;#W,t#E@
  E#t     :K#D#E@
  E#t      .E##E@
  ..         G#E@
  $           fE@
               ,@@
             @
       :     @
  $   t#,  $ @
     ;##W.   @
    :#L:WE   @
   .KG  ,#D  @
   EE    ;#f @
 $f#.     t#i@
  :#G     GK @
   ;#L   LW. @
    t#f f#:  @
     f#D#;   @
      G#t    @
       t     @
             @
             @@
            @
            @
            @
  t         @
  ED.       @
  E#K:   $  @
  E##W;     @
  E#E##t    @
 $E#ti##f   @
  E#t ;##D. @
  E#ELLE##K:@
  E#L;;;;;;,@
  E#t       @
  E#t       @
            @
            @@
             @
       :     @
      t#,    @
  $  ;##W. $ @
    :#L:WE   @
   .KG  ,#D  @
   EE    ;#f @
 $f#.     t#i@
  :#G   G.GK @
   ;#L  DWW. @
  $ t#f j#L  @
     f#D#j#. @
      G#t .  @
       t     @
             @
             @@
             @
             @
             @
  j.         @
  EW,        @
  E##j       @
  E###D.   $ @
  E#jG#W;    @
 $E#t t##f   @
  E#t  :K#E: @
  E#KDDDD###i@
  E#f,t#Wi,,,@
  E#t  ;#W:  @
  DWi   ,KK: @
             @
             @@
            @
            @
           .@
          ;W@
         f#E@
  $    .E#f @
      iWW;  @
     L##Lffi@
    tLLG##L @
      ,W#i  @
     j#E.   @
   .D#j     @
  ,WK,    $ @
 $EG.       @
  ,         @
            @@
           @
           @
  $       $@
           @
 $GEEEEEEEL@
  ,;;L#K;;.@
     t#E   @
     t#E   @
     t#E   @
  $  t#E   @
     t#E   @
     t#E   @
     t#E   @
      fE   @
       :   @
           @@
         @
         @
  :      @
  Ef     @
  E#t   $@
  E#t    @
  E#t    @
  E#t fi @
 $E#t L#j@
  E#t L#L@
  E#tf#E:@
  E###f  @
  E#K,   @
  EL     @
  :      @
         @@
             @
             @
             @
  $        $ @
             @
  t      .DD.@
  EK:   ,WK. @
  E#t  i#D   @
 $E#t j#f    @
  E#tL#i   $ @
  E#WW,      @
  E#K:       @
  ED.        @
  t          @
             @
             @@
                     @
                     @
                     @
                     @
  $         ;      $ @
          .DL        @
  f.     :K#L     LWL@
  EW:   ;W##L   .E#f @
  E#t  t#KE#L  ,W#;  @
 $E#t f#D.L#L t#K:   @
  E#jG#f  L#LL#G   $ @
  E###;   L###j      @
  E#K:    L#W;       @
  EG      LE.        @
  ;       ;@         @
                     @@
             @
             @
             @
   $       $ @
             @
  :KW,      L@
   ,#W:   ,KG@
    ;#W. jWi @
 $$  i#KED.  @
      L#W.   @
    .GKj#K.  @
   iWf  i#K. @
  LK:    t#E @
  i       tDj@
             @
             @@
             @
             @
  $        $ @
             @
  f.     ;WE.@
  E#,   i#G  @
  E#t  f#f   @
 $E#t G#i    @
  E#jEW,     @
  E##E.    $ @
  E#G        @
  E#t        @
  E#t        @
  EE.        @
  t          @
             @@
                         @
                         @
                         @
       $               $ @
                         @
       ,##############Wf.@
        ........jW##Wt   @
              tW##Kt     @
     $      tW##E;     $ @
          tW##E;         @
       .fW##D,        $  @
     .f###D,             @
   .f####Gfffffffffff;   @
 $.fLLLLLLLLLLLLLLLLLi   @
                         @
                         @@
       @
       @
       @
       @
       @
       @
       @
     __@
    / /@
   | | @
 $< <  @
   | | @
    \\_\\@
       @
       @
       @@
      @
      @
  ;f. @
  i##:@
  i##:@
  i##:@
  i##:@
 $.fW:@
  ;f: @
  i##:@
  i##:@
  i##:@
  i##:@
  iKt @
      @
      @@
      @
      @
      @
      @
      @
      @
      @
 __   @
 \\ \\  @
  | | @
$  > >@
  | | @
 /_/  @
      @
      @
      @@
       @
       @
       @
       @
       @
       @
  :j,.;@
 $,.;t.@
    $  @
    $  @
    $  @
    $  @
    $  @
    $  @
       @
       @@
              @
              @
   $          @
              @
    i,  f.   ;@
   .GL ,Gt  j#@
           G##@
         :K###@
   $    ;W####@
       j##LK##@
      G###E###@
    :K#W;::K##@
   ;##E.   K##@
 $j##L     K##@
  :::      :::@
              @@
              @
              @
              @
              @
     t:  f    @
    :Gf ;Gi   @
       :      @
     .L#E,    @
    iWWtG#L   @
  :D#G.  ;KWi @
$.K#f     ;##;@
   L#G.  L#E: @
    ,EWfWWt   @
 $    t#G.   $@
              @
              @@
  ,:     .    @
  i#i   tW. GD@
  i##:  ::. ::@
  i##:        @
  i##:        @
  i##: ,:     @
  i##: i#i    @
 $i##: i##:   @
  i##: t##:   @
  i##,f##t    @
  i##W#E:  $  @
  i###j       @
  i#E:        @
  if          @
              @
              @@
              @
              @
   $          @
              @
    i,  f.   ;@
   .GL ,Gt  j#@
           G##@
         :K###@
   $    ;W####@
       j##LK##@
      G###E###@
    :K#W;::K##@
   ;##E.   K##@
 $j##L     K##@
  :::      :::@
              @@
               @
               @
               @
               @
      t:  f    @
     :Gf ;Gi   @
        :      @
      .L#E,    @
     iWWtG#L   @
   :D#G.  ;KWi @
 $.K#f     ;##;@
    L#G.  L#E: @
     ,EWfWWt   @
  $    t#G.   $@
               @
               @@
  ,:     .    @
  i#i   tW. GD@
  i##:  ::. ::@
  i##:        @
  i##:        @
  i##: ,:     @
 $i##: i#i    @
  i##: i##:   @
  i##: t##:   @
  i##,f##t    @
  i##W#E:  $  @
  i###j       @
  i#E:        @
  if          @
              @
              @@
                      @
                      @
            :        :@
          .GL       LL@
         ,K#i     :K#;@
    $   t#K:     t#E: @
      .G#L     .G#f   @
     ,K#Ettt. ,W#Gttt:@
    ,EEE###t ;EEEW##t @
       f#E:     j#E:  @
     .E#f     .D#f    @
    i#W;     ,WW;   $ @
   L#D.     j#G.      @
 $L#j      f#t        @
  j,       t:         @
                      @@
160  NO-BREAK SPACE
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@
 $$@@
161  INVERTED EXCLAMATION MARK
      @
      @
  ;f. @
  ,##:@
  .:t.@
  i#G.@
  i##:@
 $i##:@
  i##:@
  i##:@
  i##:@
  i##:@
  i##:@
  iKt @
      @
      @@
162  CENT SIGN
          @
          @
  $    G f@
       GW#@
     :K#K,@
    f##L  @
 $iW#G i  @
  G##i i  @
   ;K# j  @
     j##G.@
      GW#W@
  $    G;K@
       f .@
          @
          @
          @@
163  POUND SIGN
         @
         @
         @
         @
         @
         @
         @
         @
         @
    ___  @
   / ,_\\ @
$_| |_   @
  | |___ @
 (_,____|@
         @
         @@
164  CURRENCY SIGN
        @
        @
        @
        @
        @
        @
        @
        @
        @
 /\\___/\\@
 \\  _  /@
$| (_) |@
 / ___ \\@
 \\/   \\/@
        @
        @@
165  YEN SIGN
        @
        @
        @
        @
        @
        @
        @
        @
        @
  __ __ @
  \\ V / @
$|__ __|@
 |__ __|@
   |_|  @
        @
        @@
166  BROKEN BAR
      @
      @
  ;f. @
  i##:@
  i##:@
  i##:@
  i##:@
 $.fW:@
  ;f: @
  i##:@
  i##:@
  i##:@
  i##:@
  iKt @
      @
      @@
167  SECTION SIGN
       @
       @
       @
       @
       @
       @
       @
       @
       @
    __ @
  _/ _)@
$/ \\ \\ @
 \\ \\\\ \\@
  \\ \\_/@
 (__/  @
       @@
168  DIAERESIS
         @
         @
   i,  f.@
 $.GL ,Gt@
   $   $ @
   $   $ @
   $   $ @
   $   $ @
   $   $ @
   $   $ @
   $   $ @
   $   $ @
   $   $ @
   $   $ @
   $   $ @
         @@
169  COPYRIGHT SIGN
            .Li           @
           iW##D:         @
         :D#Wif##j        @
        j##L.  ,K#K,      @
  $   ,K#K,  i   f##L.  $ @
    .L##f   Gj    :E#Wi   @
   iW#E:  .E;       j##D: @
 $D##L   .K,         .W##t@
  :E##t   tD.       .G##f @
    t##E:  ;E:     t##E:  @
  $  .G##j  :L   :D##t  $ @
       ;K#K,    j##G.     @
         f##f :E#K;       @
          :E#W##f         @
            t#E:          @
                          @@
170  FEMININE ORDINAL INDICATOR
           @
           @
         :G@
   $    ;WK@
       j##K@
      G#L#K@
    .E#ff#K@
   ,WW:  #K@
   jj.   ft@
 $;EEEEEELi@
       $   @
       $   @
       $   @
       $   @
       $   @
           @@
171  LEFT-POINTING DOUBLE ANGLE QUOTATION MARK
                      @
                      @
                      @
   $          :i    :i@
          .iLGf,.iLGf,@
       ,fGLi.,fGLi.   @
   .tGGj:.tGGj:       @
 $fWE,  fWE,        $ @
    ,fDLi.,fDLi.      @
       .iLGf,.iLGf,   @
    $      :jGGi :jGGi@
               :     :@
           $          @
           $          @
           $          @
                      @@
172  NOT SIGN
            @
            @
            @
            @
            @
   $      $ @
            @
   ;ttttttti@
 $,iiiiiiiEK@
          Gj@
          . @
      $     @
      $     @
      $     @
      $     @
            @@
173  SOFT HYPHEN
           @
           @
           @
           @
           @
           @
  $      $ @
  .......  @
 $GEEEEEEf.@
      $    @
      $    @
      $    @
      $    @
      $    @
           @
           @@
174  REGISTERED SIGN
            .Li           @
           iW##D:         @
         :D#Wif##j        @
        j##L.  ,K#K,      @
  $   ,K#K,:     f##L.  $ @
    .L##f  LL     :E#Wi   @
   iW#E:   L#K,     j##D: @
 $D##L     LLiWt     .W##t@
  :E##t    LEtf#D.  .G##f @
    t##E:  LG,KG,. t##E:  @
  $  .G##j jj .Di:D##t  $ @
       ;K#K,    j##G.     @
         f##f :E#K;       @
          :E#W##f         @
            t#E:          @
                          @@
175  MACRON
             @
  .........  @
 $GEEEEEEEEf.@
       $     @
   $       $ @
    $     $  @
      $ $    @
       $     @
       $     @
       $     @
       $     @
       $     @
       $     @
       $     @
             @
             @@
176  DEGREE SIGN
        @
        @
    :.  @
  .LLDi @
 $Kt  Ef@
  .LLDi @
    :.  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
        @@
177  PLUS-MINUS SIGN
               @
   $           @
               @
      Gf.    $ @
      G##      @
      G##      @
 $;WWW###WWWWf.@
  :tttE##tttttt@
      G##      @
      :;;    $ @
               @
  ;WWWWWWWWWWf.@
  :tttttttttttt@
               @
    $        $ @
               @@
178  SUPERSCRIPT TWO
          @
  i       @
  Ef    $ @
   LE.    @
    tW,   @
 $##EEE;  @
  #E      @
  #Wffff, @
  ttttttt.@
   $  $   @
   $  $   @
      $   @
      $   @
      $   @
      $   @
          @@
179  SUPERSCRIPT THREE
        @
  ,    $@
  GG.   @
   fW,  @
    iWf @
 $tDDK#f@
    ;Wf @
   fW,  @
  GG.   @
  ,     @
    $   @
    $   @
    $   @
    $   @
    $   @
        @@
180  ACUTE ACCENT
     @
   ,:@
 $.; @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
   $ @
     @@
181  MICRO SIGN
        @
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _   _ @
 | | | |@
$| |_| |@
 | ._,_|@
 |_|    @
        @@
182  PILCROW SIGN
         @
         @
         @
         @
         @
         @
         @
         @
         @
   _____ @
  /     |@
$| (| | |@
  \\__ | |@
    |_|_|@
         @
         @@
183  MIDDLE DOT
      @
      @
      @
      @
      @
      @
   jG:@
 $,K#f@
    . @
   $  @
   $  @
   $  @
   $  @
   $  @
   $  @
      @@
184  CEDILLA
    @
    @
    @
    @
    @
    @
    @
    @
    @
    @
    @
    @
    @
  _ @
$)_)@
    @@
185  SUPERSCRIPT ONE
    @
   i@
  fE@
 $LE@
  LE@
  LE@
  LE@
  .:@
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
  $ @
    @@
186  MASCULINE ORDINAL INDICATOR
        @
   ,Df. @
 $LL.,Di@
  tD,tD:@
   .Lt  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
     $  @
        @@
187  RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK
                       @
    $                  @
                       @
  :i.   :i.            @
  .iLDf;.iLDf;       $ @
      :jGDj::jDGt:     @
          ;fDLi.;LDLi  @
 $$         .j#Wt .j#E;@
         ,fDDj:,jDLt.  @
     .tGEL;.iLDj,    $ @
  :fEGt..fDLi.         @
  .:    .:             @
    $       $          @
            $          @
            $          @
                       @@
188  VULGAR FRACTION ONE QUARTER
                    @
   .             .  @
  ;D           :Et  @
  LE          t#K:  @
 $LE        .D#L.   @
  LE       i#W;     @
  LE     .G#G.  ;i  @
  ij    ;W#i   j#t  @
       L#D.   f##t  @
     ,K#t    D#j#t  @
    f#E:   .EW,,#t  @
  :K#j     LDDDE#Kf.@
 $LK:          ,#t  @
  ,            .#t  @
                .:  @
                    @@
189  VULGAR FRACTION ONE HALF
                      @
   .             .    @
  ;#           :Et    @
  L#          t#K:    @
 $L#        .D#L.     @
  L#       i#W;       @
  L#     .G#G.:       @
  iL    ;W#i  Wi      @
       L#D.   .Kf     @
     ,K#t       DD.   @
    f#E:      EEK#K:  @
  :K#j        #L      @
 $LK:         #D;;;;  @
  ,           LLLLLLj.@
                      @
                      @@
190  VULGAR FRACTION THREE QUARTERS
                    @
  .              .  @
  iD.          .GL  @
   tW;        ;WW;  @
    ,WL      L#G.   @
 $.fLG#K.  ,K#i     @
  ...LW;  f#D.  :j  @
   .DE. ,K#t   ;#L  @
  :Wj  f#E:   t##L  @
  ;, :E#j    f#j#L  @
    j#K:    G#i #L  @
  .E#f     jDDDD#WL,@
 $tK,           #L  @
  :.            KL  @
                 :  @
                    @@
191  INVERTED QUESTION MARK
                  @
          :.      @
          :GL     @
                  @
          tKt     @
          t#E     @
          t#E     @
   $     :E#j     @
        ;WW,      @
       j#D.     $ @
      G#j         @
    :KW,          @
   ;###WWWWWWWWWWL@
 $:LLLLLLLLLLLLLj @
                  @
                  @@
192  LATIN CAPITAL LETTER A WITH GRAVE
               @
               @
               @
               @
        ,j.  ..@
         :: ;W,@
           j##,@
          G###,@
   $    :E####,@
       ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
193  LATIN CAPITAL LETTER A WITH ACUTE
               @
               @
               @
               @
        .f,  ..@
        :.  ;W,@
           j##,@
          G###,@
        :E####,@
   $   ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
194  LATIN CAPITAL LETTER A WITH CIRCUMFLEX
               @
               @
               @
               @
       :fLi  ..@
       ,. ; ;W,@
           j##,@
          G###,@
        :E####,@
   $   ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
195  LATIN CAPITAL LETTER A WITH TILDE
               @
               @
               @
               @
      jLj;f  ..@
     .: :i. ;W,@
           j##,@
          G###,@
        :E####,@
   $   ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
196  LATIN CAPITAL LETTER A WITH DIAERESIS
               @
               @
               @
               @
    ,;  t.   ..@
    LG .Df  ;W,@
           j##,@
          G###,@
        :E####,@
   $   ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
197  LATIN CAPITAL LETTER A WITH RING ABOVE
               @
               @
               @
               @
       .ji   ;:@
       ;jj. j#,@
           L##,@
         .E###,@
        ,W####,@
   $   t##DG##,@
      L###DW##,@
    .E##t,,G##,@
   ,W#W,   L##,@
 $i##E.    L##,@
  ,,,      .,, @
               @@
198  LATIN CAPITAL LETTER AE
                      @
                      @
               .;jLE#t@
             ;W##KDfi.@
            j#f,.     @
           G##,       @
         .K###,       @
    $   ;WWE##Lffffj  @
       j#W:L##KEEEEEL @
      L##EDW##,       @
    .E#W;,,G##,       @
   ,W#K.   L##,       @
 $i##D     L##ELj;:   @
  ,,,      :ijLDK###K;@
                  :;t,@
                      @@
199  LATIN CAPITAL LETTER C WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
   ____ @
  / ___|@
$| |    @
 | |___ @
  \\____|@
    )_) @
        @@
200  LATIN CAPITAL LETTER E WITH GRAVE
            @
          .,@
     Li  i#t@
      . L#E.@
  $   ,K#L  @
     j##i   @
   .D#K:    @
  ;W##fffj. @
 $D###EEEEEt@
   t##f     @
    :K#E.   @
      L#W;  @
  $    ;W#j @
        .D#t@
          jt@
            @@
201  LATIN CAPITAL LETTER E WITH ACUTE
            @
          .,@
     Li  i#t@
     .  L#E.@
  $   ,K#L  @
     j##i   @
   .D#K:    @
  ;W##fffj. @
 $D###EEEEEt@
   t##f     @
    :K#E.   @
      L#W;  @
  $    ;W#j @
        .D#t@
          jt@
            @@
202  LATIN CAPITAL LETTER E WITH CIRCUMFLEX
            @
          :;@
  .LLL,  t#t@
       .G#E.@
      ,K#f  @
     j##i   @
   .E#E:    @
  iW##fffj. @
 $D###EEEEEt@
   t##f     @
    ,K#D.   @
      L#W,  @
  $    i##t @
        :E#i@
          ft@
            @@
203  LATIN CAPITAL LETTER E WITH DIAERESIS
              @
   .       .i @
  tK. GG  ,WL @
  :,. ,,.f#K, @
       :E#G.  @
      i##j    @
     L#W,     @
   ,K##Lfff,  @
  $f###EEEEEf.@
    ;W#G.     @
     .D#K:    @
       j##i   @
   $    ,K#L  @
         .G#f @
           tf @
              @@
204  LATIN CAPITAL LETTER I WITH GRAVE
      @
      @
   :. @
   .L,@
      @
  .:  @
  ,#j @
  ,##t@
 $,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
   ,,.@
      @@
205  LATIN CAPITAL LETTER I WITH ACUTE
      @
      @
      @
   ,L,@
      @
  .:  @
  ,#j @
  ,##t@
 $,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
   ,,.@
      @@
206  LATIN CAPITAL LETTER I WITH CIRCUMFLEX
      @
      @
      @
  jLLj@
  .  .@
  .:  @
  ,#j @
  ,##t@
 $,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
   ,,.@
      @@
207  LATIN CAPITAL LETTER I WITH DIAERESIS
        @
        @
      . @
  LD  Kj@
  ,, .,,@
   :.   @
   tWi  @
   t##, @
  $t##, @
   t##, @
   t##, @
   t##, @
   t##, @
   t##, @
   .,,  @
        @@
208  LATIN CAPITAL LETTER ETH
          @
          @
          @
          @
          @
          @
          @
          @
          @
    ____  @
   |  _ \\ @
  _| |_| |@
$|__ __| |@
   |____/ @
          @
          @@
209  LATIN CAPITAL LETTER N WITH TILDE
                @
                @
  j:   .t;.i    @
  LW,  ,.,j: .tt@
  L##i       ,##@
  L###j      ,##@
  L#GD#L     ,##@
  L#L G#D    ,##@
 $L#L  j#K.  ,##@
  L#L   i#W: ,##@
  L#L    ,W#;,##@
  L#L     .K#L##@
  L#L       D###@
  L#L        f##@
  .,.         j#@
               ;@@
210  LATIN CAPITAL LETTER O WITH GRAVE
             @
             @
             @
             @
             @
      .:     @
  $    i,    @
       .     @
     .L#D.   @
    iWG:f#j  @
  :DWi   ,EK,@
  .G#t   ;WE:@
    ;KE;G#t  @
      f#G.   @
             @
             @@
211  LATIN CAPITAL LETTER O WITH ACUTE
             @
             @
             @
             @
             @
       ,:    @
  $   .;     @
       ,     @
     .D#E,   @
    j#L.j#f. @
  :KK,   .DW;@
   f#j   t#G.@
    :EKiEW;  @
      tWf    @
             @
             @@
212  LATIN CAPITAL LETTER O WITH CIRCUMFLEX
             @
             @
             @
             @
             @
      :t:    @
  $   i.i    @
       ,     @
     .D#E,   @
    j#L.j#f. @
 $:KK,   .DW;@
   f#j   t#G.@
    :EKiEW;  @
      tWf    @
             @
             @@
213  LATIN CAPITAL LETTER O WITH TILDE
             @
             @
             @
             @
             @
     .ji,i   @
  $  :..;    @
       i     @
     ,E#W;   @
   .f#j iWG. @
 $,WK:   .D#i@
   j#L.  j#f.@
    .GWjKE,  @
      iKj    @
             @
             @@
214  LATIN CAPITAL LETTER O WITH DIAERESIS
             @
             @
             @
             @
             @
     :.  ;   @
  $  Lf tG.  @
       i     @
     ,E#W;   @
   .f#j iWG. @
  ,WK:   .D#i@
   j#L.  j#f.@
    .GWjKE,  @
      iKj    @
             @
             @@
215  MULTIPLICATION SIGN
                     @
  $                  @
                     @
                tW   @
  tEEEEG,     tW##   @
   .L####D, tW###W   @
     .L####W###Wt    @
       :W#####L      @
      tW#######D,    @
    ,W####f:L####D,  @
    t###f.   .L####D,@
    t#f.             @
    :.             $ @
                     @
   $                 @
                     @@
216  LATIN CAPITAL LETTER O WITH STROKE
             @
             @
             @
             @
             @
           $ @
  $          @
       i .#  @
     ,E#W#.  @
   .f#j #WG. @
 $,WK: # .D#i@
   j#L#  j#f.@
    .#WjKE,  @
    #.iKj    @
             @
             @@
217  LATIN CAPITAL LETTER U WITH GRAVE
           @
           @
           @
  f;     i @
  L#t    ,:@
  L#L      @
  L#L      @
  L#L ,:   @
  L#L t#i  @
  L#L t#E  @
  L#L.D#f  @
  L#EW#i   @
  L##D.    @
  L#j      @
  t:       @
           @@
218  LATIN CAPITAL LETTER U WITH ACUTE
           @
           @
           @
  ft     ;;@
  L#j    , @
  L#L      @
  L#L      @
  L#L ;,   @
  L#L t#t  @
  L#L t#E  @
  L#L:E#j  @
  L#K#W,   @
  L##G.    @
  L#i      @
  i.       @
           @@
219  LATIN CAPITAL LETTER U WITH CIRCUMFLEX
            @
            @
  ft    :ji @
  L#j   , :.@
  L#L       @
  L#L       @
  L#L ;,    @
  L#L t#t   @
 $L#L t#E   @
  L#L:E#j   @
  L#K#W,    @
  L##G.     @
  L#i       @
  i.        @
  .         @
            @@
220  LATIN CAPITAL LETTER U WITH DIAERESIS
             @
             @
             @
  Lj   ;j .L @
  L#f  it ,t.@
  L#L        @
  L#L        @
  L#L i;     @
 $L#L t#j    @
  L#L t#E    @
  L#L,K#t    @
  L#W#K:     @
  L##f       @
  LW,        @
  ;.         @
             @@
221  LATIN CAPITAL LETTER Y WITH ACUTE
             @
             @
  $        $ @
        .    @
  ;   .f: jL:@
  LE:    G#i @
  L#L  .EW,  @
  L#L :WK.   @
 $L#L;#D     @
  L#K#f      @
  L##t     $ @
  L#L        @
  L#L        @
  L#j        @
  ft         @
             @@
222  LATIN CAPITAL LETTER THORN
        @
        @
        @
        @
        @
  _     @
 | |___ @
$|  __ \\@
 |  ___/@
 |_|    @
        @
        @
        @
        @
        @
        @@
223  LATIN SMALL LETTER SHARP S
                      @
                      @
            :        :@
          .GL       LL@
         ,K#i     :K#;@
    $   t#K:     t#E: @
      .G#L     .G#f   @
     ,K#Ettt. ,W#Gttt:@
    ,EEE###t ;EEEW##t @
       f#E:     j#E:  @
     .E#f     .D#f    @
    i#W;     ,WW;   $ @
   L#D.     j#G.      @
 $L#j      f#t        @
  j,       t:         @
                      @@
224  LATIN SMALL LETTER A WITH GRAVE
               @
               @
               @
               @
        ,j.  ..@
         :: ;W,@
           j##,@
          G###,@
   $    :E####,@
       ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
225  LATIN SMALL LETTER A WITH ACUTE
               @
               @
               @
               @
        .f,  ..@
        :.  ;W,@
           j##,@
          G###,@
        :E####,@
   $   ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
226  LATIN SMALL LETTER A WITH CIRCUMFLEX
               @
               @
               @
               @
       :fLi  ..@
       ,. ; ;W,@
           j##,@
          G###,@
        :E####,@
   $   ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
  ;##D.    L##,@
  ,,,      .,, @
               @@
227  LATIN SMALL LETTER A WITH TILDE
               @
               @
               @
               @
      jLj;f  ..@
     .: :i. ;W,@
           j##,@
          G###,@
        :E####,@
   $   ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
  ;##D.    L##,@
  ,,,      .,, @
               @@
228  LATIN SMALL LETTER A WITH DIAERESIS
               @
               @
               @
               @
    ,;  t.   ..@
    LG .Df  ;W,@
           j##,@
          G###,@
        :E####,@
   $   ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
229  LATIN SMALL LETTER A WITH RING ABOVE
               @
               @
               @
               @
       .ji   ;:@
       ;jj. j#,@
           L##,@
         .E###,@
        ,W####,@
   $   t##DG##,@
      L###DW##,@
    .E##t,,G##,@
   ,W#W,   L##,@
 $i##E.    L##,@
  ,,,      .,, @
               @@
230  LATIN SMALL LETTER AE
                      @
                      @
               .;jLE#t@
             ;W##KDfi.@
            j#f,.     @
           G##,       @
         .K###,       @
    $   ;WWE##Lffffj  @
       j#W:L##KEEEEEL @
      L##EDW##,       @
    .E#W;,,G##,       @
   ,W#K.   L##,       @
 $i##D     L##ELj;:   @
  ,,,      :ijLDK###K;@
                  :;t,@
                      @@
231  LATIN SMALL LETTER C WITH CEDILLA
       @
       @
       @
       @
       @
       @
       @
       @
       @
       @
   ___ @
  / __|@
$| (__ @
  \\___|@
   )_) @
       @@
232  LATIN SMALL LETTER E WITH GRAVE
            @
          .,@
     Li  i#t@
      . L#E.@
  $   ,K#L  @
     j##i   @
   .D#K:    @
  ;W##fffj. @
 $D###EEEEEt@
   t##f     @
    :K#E.   @
      L#W;  @
  $    ;W#j @
        .D#t@
          jt@
            @@
233  LATIN SMALL LETTER E WITH ACUTE
            @
          .,@
     Li  i#t@
     .  L#E.@
  $   ,K#L  @
     j##i   @
   .D#K:    @
  ;W##fffj. @
 $D###EEEEEt@
   t##f     @
    :K#E.   @
      L#W;  @
  $    ;W#j @
        .D#t@
          jt@
            @@
234  LATIN SMALL LETTER E WITH CIRCUMFLEX
            @
          :;@
  .LLL,  t#t@
       .G#E.@
      ,K#f  @
     j##i   @
   .E#E:    @
  iW##fffj. @
 $D###EEEEEt@
   t##f     @
    ,K#D.   @
      L#W,  @
  $    i##t @
        :E#i@
          ft@
            @@
235  LATIN SMALL LETTER E WITH DIAERESIS
              @
   .       .i @
  tK. GG  ,WL @
  :,. ,,.f#K, @
       :E#G.  @
      i##j    @
     L#W,     @
   ,K##Lfff,  @
  $f###EEEEEf.@
    ;W#G.     @
     .D#K:    @
       j##i   @
   $    ,K#L  @
         .G#f @
           tf @
              @@
236  LATIN SMALL LETTER I WITH GRAVE
      @
      @
   :. @
   .L,@
      @
  .:  @
  ,#j @
  ,##t@
 $,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
   ,,.@
      @@
237  LATIN SMALL LETTER I WITH ACUTE
      @
      @
      @
   ,L,@
      @
  .:  @
  ,#j @
  ,##t@
 $,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
   ,,.@
      @@
238  LATIN SMALL LETTER I WITH CIRCUMFLEX
      @
      @
      @
  jLLj@
  .  .@
  .:  @
  ,#j @
  ,##t@
 $,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
  ,##t@
   ,,.@
      @@
239  LATIN SMALL LETTER I WITH DIAERESIS
        @
        @
      . @
  LD  Kj@
  ,, .,,@
   :.   @
   tWi  @
   t##, @
 $t##, @
   t##, @
   t##, @
   t##, @
   t##, @
   t##, @
   .,,  @
        @@
240  LATIN SMALL LETTER ETH
        @
        @
        @
        @
        @
        @
        @
        @
        @
   /\\/\\ @
   >  < @
  _\\/\\ |@
$/ __\` |@
 \\____/ @
        @
        @@
241  LATIN SMALL LETTER N WITH TILDE
                @
                @
  j:   .t;.i    @
  LW,  ,.,j: .tt@
  L##i       ,##@
  L###j      ,##@
  L#GD#L     ,##@
  L#L G#D    ,##@
 $L#L  j#K.  ,##@
  L#L   i#W: ,##@
  L#L    ,W#;,##@
  L#L     .K#L##@
  L#L       D###@
  L#L        f##@
  .,.         j#@
               ;@@
242  LATIN SMALL LETTER O WITH GRAVE
             @
             @
             @
             @
             @
      .:     @
  $    i,    @
       .     @
     .L#D.   @
    iWG:f#j  @
 $:DWi   ,EK,@
  .G#t   ;WE:@
    ;KE;G#t  @
      f#G.   @
             @
             @@
243  LATIN SMALL LETTER O WITH ACUTE
             @
             @
             @
             @
             @
       ,:    @
  $   .;     @
       ,     @
     .D#E,   @
    j#L.j#f. @
 $:KK,   .DW;@
   f#j   t#G.@
    :EKiEW;  @
      tWf    @
             @
             @@
244  LATIN SMALL LETTER O WITH CIRCUMFLEX
             @
             @
             @
             @
             @
      :t:    @
  $   i.i    @
       ,     @
     .D#E,   @
    j#L.j#f. @
 $:KK,   .DW;@
   f#j   t#G.@
    :EKiEW;  @
      tWf    @
             @
             @@
245  LATIN SMALL LETTER O WITH TILDE
             @
             @
             @
             @
             @
     .ji,i   @
  $  :..;    @
       i     @
     ,E#W;   @
   .f#j iWG. @
 $,WK:   .D#i@
   j#L.  j#f.@
    .GWjKE,  @
      iKj    @
             @
             @@
246  LATIN SMALL LETTER O WITH DIAERESIS
             @
             @
             @
             @
             @
     :.  ;   @
  $  Lf tG.  @
       i     @
     ,E#W;   @
   .f#j iWG. @
 $,WK:   .D#i@
   j#L.  j#f.@
    .GWjKE,  @
      iKj    @
             @
             @@
247  DIVISION SIGN
                @
                @
                @
                @
   $         $  @
        :f;     @
        j,      @
  ,ttttttttttt. @
 $jEEEEEEEEEEEEt@
          .     @
        fD,     @
        .       @
                @
   $         $  @
                @
                @@
248  LATIN SMALL LETTER O WITH STROKE
             @
             @
             @
             @
             @
           $ @
  $          @
       i .#  @
     ,E#W#.  @
   .f#j #WG. @
 $,WK: # .D#i@
   j#L#  j#f.@
    .#WjKE,  @
    #.iKj    @
             @
             @@
249  LATIN SMALL LETTER U WITH GRAVE
           @
           @
           @
  f;     i @
  L#t    ,:@
  L#L      @
  L#L      @
  L#L ,:   @
 $L#L t#i  @
  L#L t#E  @
  L#L.D#f  @
  L#EW#i   @
  L##D.    @
  L#j      @
  t:       @
           @@
250  LATIN SMALL LETTER U WITH ACUTE
           @
           @
           @
  ft     ;;@
  L#j    , @
  L#L      @
  L#L      @
  L#L ;,   @
 $L#L t#t  @
  L#L t#E  @
  L#L:E#j  @
  L#K#W,   @
  L##G.    @
  L#i      @
  i.       @
           @@
251  LATIN SMALL LETTER U WITH CIRCUMFLEX
            @
            @
  ft    :ji @
  L#j   , :.@
  L#L       @
  L#L       @
  L#L ;,    @
  L#L t#t   @
 $L#L t#E   @
  L#L:E#j   @
  L#K#W,    @
  L##G.     @
  L#i       @
  i.        @
  .         @
            @@
252  LATIN SMALL LETTER U WITH DIAERESIS
             @
             @
             @
  Lj   ;j .L @
  L#f  it ,t.@
  L#L        @
  L#L        @
  L#L i;     @
 $L#L t#j    @
  L#L t#E    @
  L#L,K#t    @
  L#W#K:     @
  L##f       @
  LW,        @
  ;.         @
             @@
253  LATIN SMALL LETTER Y WITH ACUTE
             @
             @
  $        $ @
        .    @
  ;   .f: jL:@
  LE:    G#i @
  L#L  .EW,  @
  L#L :WK.   @
 $L#L;#D     @
  L#K#f      @
  L##t     $ @
  L#L        @
  L#L        @
  L#j        @
  ft         @
             @@
254  LATIN SMALL LETTER THORN
        @
        @
        @
        @
        @
  _     @
 | |__  @
 | '_ \\ @
$| |_) |@
 | .__/ @
 |_|    @
        @
        @
        @
        @
        @@
255  LATIN SMALL LETTER Y WITH DIAERESIS
             @
  $        $ @
             @
    j; ,j    @
  ; ti it jL:@
  LE:    G#i @
  L#L  .EW,  @
  L#L :WK.   @
 $L#L;#D     @
  L#K#f      @
  L##t    $  @
  L#L        @
  L#L        @
  L#j        @
  ft         @
             @@
0x0100  LATIN CAPITAL LETTER A WITH MACRON
               @
               @
    .........  @
    GEEEEEEEEf.@
             ..@
            ;W,@
           j##,@
          G###,@
        :E####,@
       ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
0x0101  LATIN SMALL LETTER A WITH MACRON
               @
               @
    .........  @
    GEEEEEEEEf.@
             ..@
            ;W,@
           j##,@
          G###,@
        :E####,@
       ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
0x0102  LATIN CAPITAL LETTER A WITH BREVE
               @
               @
               @
               @
   :f,,,ij   ..@
    .ttt;   ;W,@
           j##,@
          G###,@
        :E####,@
       ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
0x0103  LATIN SMALL LETTER A WITH BREVE
               @
               @
               @
               @
   :f,,,ij   ..@
    .ttt;   ;W,@
           j##,@
          G###,@
        :E####,@
       ;W#DG##,@
      j###DW##,@
     G##i,,G##,@
   :K#K:   L##,@
 $;##D.    L##,@
  ,,,      .,, @
               @@
0x0104  LATIN CAPITAL LETTER A WITH OGONEK
        @
        @
        @
        @
        @
        @
        @
        @
        @
        @
    _   @
   /_\\  @
  / _ \\ @
$/_/ \\_\\@
     (_(@
        @@
0x0105  LATIN SMALL LETTER A WITH OGONEK
        @
        @
        @
        @
        @
        @
        @
        @
        @
        @
   __ _ @
  / _\` |@
$| (_| |@
  \\__,_|@
     (_(@
        @@
0x0106  LATIN CAPITAL LETTER C WITH ACUTE
          @
          @
          @
          @
   $      @
     .:  .@
    .i.:DL@
     .f#E,@
    iW#t  @
 $:E#L.   @
  .f#E,   @
    :D#L. @
  $   iW#i@
       .fL@
          @
          @@
0x0107  LATIN SMALL LETTER C WITH ACUTE
          @
          @
          @
          @
   $      @
     .:  .@
    .i.:DL@
     .f#E,@
    iW#t  @
 $:E#L.   @
  .f#E,   @
    :D#L. @
  $   iW#i@
       .fL@
          @
          @@
0x0108  LATIN CAPITAL LETTER C WITH CIRCUMFLEX
          @
          @
          @
          @
   $      @
   ;,    .@
  ;,;: :DL@
     .f#E,@
    iW#t  @
 $:E#L.   @                                         
  .f#E,   @
    :D#G. @
      iW#i@
        fL@
          @
          @@
0x0109  LATIN SMALL LETTER C WITH CIRCUMFLEX
          @
          @
          @
          @
   $      @
   ;,    .@
  ;,;: :DL@
     .f#E,@
    iW#t  @
 $:E#L.   @                                         
  .f#E,   @
    :D#G. @
      iW#i@
        fL@
          @
          @@
0x010A  LATIN CAPITAL LETTER C WITH DOT ABOVE
          @
          @
          @
          @
   jG:    @
  ,K#f   ,@
       ;KL@
     .G#D.@
    j#W;  @
 $,K#f    @
   j#Wi   @
    .L#D: @
      ,E#t@
        tf@
          @
          @@
0x010B  LATIN SMALL LETTER C WITH DOT ABOVE
          @
          @
          @
          @
   jG:    @
  ,K#f   ,@
       ;KL@
     .G#D.@
    j#W;  @
 $,K#f    @
   j#Wi   @
    .L#D: @
      ,E#t@
        tf@
          @
          @@
0x010C  LATIN CAPITAL LETTER C WITH CARON
          @
          @
          @
   $      @
  ;,;,    @
   i;    ,@
       ;KL@
     .G#D.@
    j#W;  @
 $,K#f    @
   j#Wi   @
    .L#D: @
      ,E#t@
        tf@
          @
          @@
0x010D  LATIN SMALL LETTER C WITH CARON
          @
          @
          @
   $      @
  ;,;,    @
   i;    ,@
       ;KL@
     .G#D.@
    j#W;  @
 $,K#f    @
   j#Wi   @
    .L#D: @
      ,E#t@
        tf@
          @
          @@
0x010E  LATIN CAPITAL LETTER D WITH CARON
  ;           @
  ED.   i.,:  @
  E#Wi  .ti   @
  E###G.      @
  E#fD#W;   $ @
  E#t t##L    @
  E#t  .E#K,  @
  E#t    j##f @
 $E#t    :E#K:@
  E#t   t##L  @
  E#t .D#W;   @
  E#tiW#G.  $ @
  E#K##i      @
  E##D.       @
  E#t         @
  L:          @@
0x010F  LATIN SMALL LETTER D WITH CARON
  ;           @
  ED.   i.,:  @
  E#Wi  .ti   @
  E###G.      @
  E#fD#W;   $ @
  E#t t##L    @
  E#t  .E#K,  @
  E#t    j##f @
 $E#t    :E#K:@
  E#t   t##L  @
  E#t .D#W;   @
  E#tiW#G.  $ @
  E#K##i      @
  E##D.       @
  E#t         @
  L:          @@
0x0110  LATIN CAPITAL LETTER D WITH STROKE
          @
          @
          @
          @
          @
          @
          @
          @
          @
   ____   @
  |_ __ \\ @
$/| |/ | |@
 /|_|/_| |@
  |_____/ @
          @
          @@
0x0111  LATIN SMALL LETTER D WITH STROKE
        @
        @
        @
        @
        @
        @
        @
        @
        @
    ---|@
   __| |@
  / _\` |@
$| (_| |@
  \\__,_|@
        @
        @@
0x0112  LATIN CAPITAL LETTER E WITH MACRON
  .........  @
  GEEEEEEEEf.@
             @
          ;f @
   $    .L#j @
       :E#t  @
      t#K:   @
    .L#D.    @
 $ ,K##DDDf. @
   .D##jtttt.@
     t#W,    @
      ,K#t   @
   $    L#L  @
         t#f @
          :t @
             @@
0x0113  LATIN SMALL LETTER E WITH MACRON
  .........  @
  GEEEEEEEEf.@
             @
          ;f @
   $    .L#j @
       :E#t  @
      t#K:   @
    .L#D.    @
 $ ,K##DDDf. @
   .D##jtttt.@
     t#W,    @
      ,K#t   @
   $    L#L  @
         t#f @
          :t @
             @@
0x0114  LATIN CAPITAL LETTER E WITH BREVE
            @
            @
            @
  ,:  :, ;f @
  .tLLt.L#j @
      :E#t  @
     t#K:   @
   .L#D.    @
 $,K##DDDf. @
  .D##jtttt.@
    t#W,    @
     ,K#t   @
  $    L#L  @
        t#f @
         :t @
            @@
0x0115  LATIN SMALL LETTER E WITH BREVE
            @
            @
            @
  ,:  :, ;f @
  .tLLt.L#j @
      :E#t  @
     t#K:   @
   .L#D.    @
 $,K##DDDf. @
  .D##jtttt.@
    t#W,    @
     ,K#t   @
  $    L#L  @
        t#f @
         :t @
            @@
0x0116  LATIN CAPITAL LETTER E WITH DOT ABOVE
            @
     jG:    @
    ,K#f    @
         ;f @
  $    .L#j @
      :E#t  @
     t#K:   @
   .L#D.    @
 $,K##DDDf. @
  .D##jtttt.@
    t#W,    @
     ,K#t   @
  $    L#L  @
        t#f @
         :t @
            @@
0x0117  LATIN SMALL LETTER E WITH DOT ABOVE
            @
     jG:    @
    ,K#f    @
         ;f @
  $    .L#j @
      :E#t  @
     t#K:   @
   .L#D.    @
 $,K##DDDf. @
  .D##jtttt.@
    t#W,    @
     ,K#t   @
  $    L#L  @
        t#f @
         :t @
            @@
0x0118  LATIN CAPITAL LETTER E WITH OGONEK
        @
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _____ @
 | ____|@
$|  _|_ @
 |_____|@
    (__(@
        @@
0x0119  LATIN SMALL LETTER E WITH OGONEK
       @
       @
       @
       @
       @
       @
       @
       @
       @
       @
   ___ @
  / _ \\@
$|  __/@
  \\___|@
    (_(@
       @@
0x011A  LATIN CAPITAL LETTER E WITH CARON
            @
            @
            @
   i.,:  ;f @
   .ti  L#j @
      :E#t  @
     t#K:   @
   .L#D.    @
 $,K##DDDf. @
  .D##jtttt.@
    t#W,    @
     ,K#t   @
  $    L#L  @
        t#f @
         :t @
            @@
0x011B  LATIN SMALL LETTER E WITH CARON
            @
            @
            @
   i.,:  ;f @
   .ti  L#j @
      :E#t  @
     t#K:   @
   .L#D.    @
 $,K##DDDf. @
  .D##jtttt.@
    t#W,    @
     ,K#t   @
  $    L#L  @
        t#f @
         :t @
            @@
0x011C  LATIN CAPITAL LETTER G WITH CIRCUMFLEX
             @
             @
   jLLj    j:@
   .  .  ;K#:@
       .G#G. @
      f#K;   @
    ;W#j     @
  .D#G.  ,tt.@
 $;K#f   .##,@
    j#W;  ##,@
     .G#D.##,@
  $    ;K###,@
         j##,@
          .G,@
            .@
             @@
0x011D  LATIN SMALL LETTER G WITH CIRCUMFLEX
             @
             @
   jLLj    j:@
   .  .  ;K#:@
       .G#G. @
      f#K;   @
    ;W#j     @
  .D#G.  ,tt.@
 $;K#f   .##,@
    j#W;  ##,@
     .G#D.##,@
  $    ;K###,@
         j##,@
          .G,@
            .@
             @@
0x011E  LATIN CAPITAL LETTER G WITH BREVE
             @
             @
             @
  ;,..,;  .Gt@
   iffi  j#W:@
       ;K#f  @
     .G#D.   @
    j#K;     @
 $,K#f   ,GD;@
   j#Wi   E#t@
    .G#D: E#t@
      ,K#fK#t@
  $     j###t@
         .G#t@
           ;;@
             @@
0x011F  LATIN SMALL LETTER G WITH BREVE
             @
             @
             @
  ;,..,;  .Gt@
   iffi  j#W:@
       ;K#f  @
     .G#D.   @
    j#K;     @
 $,K#f   ,GD;@
   j#Wi   E#t@
    .G#D: E#t@
      ,K#fK#t@
  $     j###t@
         .G#t@
           ;;@
             @@
0x0120  LATIN CAPITAL LETTER G WITH DOT ABOVE
             @
      jG:    @
     ,K#f    @
          .Gt@
         j#W:@
       ;K#f  @
     .G#D.   @
    j#K;     @
 $,K#f   ,GD;@
   j#Wi   E#t@
    .G#D: E#t@
      ,K#fK#t@
  $     j###t@
         .G#t@
           ;;@
             @@
0x0121  LATIN SMALL LETTER G WITH DOT ABOVE
             @
      jG:    @
     ,K#f    @
          .Gt@
         j#W:@
       ;K#f  @
     .G#D.   @
    j#K;     @
 $,K#f   ,GD;@
   j#Wi   E#t@
    .G#D: E#t@
      ,K#fK#t@
  $     j###t@
         .G#t@
           ;;@
             @@
0x0122  LATIN CAPITAL LETTER G WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
   ____ @
  / ___|@
$| |  _ @
 | |_| |@
  \\____|@
   )__) @
        @@
0x0123  LATIN SMALL LETTER G WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
        @
   __ _ @
  / _\` |@
$| (_| |@
  \\__, |@
  |_))))@
        @@
0x0124  LATIN CAPITAL LETTER H WITH CIRCUMFLEX
             @
             @
             @
    i;       @
  :,::::     @
  LL   LG.   @
  L#L  L#L   @
  L#L  L#L   @
  L#G..G#G.  @
 $L########D,@
  L#L  L#L   @
  L#L  L#L   @
  L#L  L#L   @
  ;#L  ;#L   @
   :t   :t   @
             @@
0x0125  LATIN SMALL LETTER H WITH CIRCUMFLEX
             @
             @
             @
    i;       @
  :,::::     @
  LL   LG.   @
  L#L  L#L   @
  L#L  L#L   @
  L#G..G#G.  @
 $L########D,@
  L#L  L#L   @
  L#L  L#L   @
  L#L  L#L   @
  ;#L  ;#L   @
   :t   :t   @
             @@
0x0126  LATIN CAPITAL LETTER H WITH STROKE
               @
               @
               @
               @
    .    .     @
    LL   LL    @
    L#LiiL#L   @
    G##E;L#L   @
 $tW##G..G#G.  @
  ;:L########D,@                                    
    L#L  L#L   @
    L#L  L#L   @
    L#L  L#L   @
    ;#L  ;#L   @
     :t   :t   @
               @@
0x0127  LATIN SMALL LETTER H WITH STROKE
               @
               @
               @
               @
    .    .     @
    LL   LL    @
    L#LiiL#L   @
    G##E;L#L   @
 $tW##G..G#G.  @
  ;:L########D,@                                    
    L#L  L#L   @
    L#L  L#L   @
    L#L  L#L   @
    ;#L  ;#L   @
     :t   :t   @
               @@
0x0128  LATIN CAPITAL LETTER I WITH TILDE
       @
       @
       @
       @
  :ji:t@
  , :i.@
   :   @
   LE: @
  $L#L @
   L#L @
   L#L @
   L#L @
   L#L @
   L#L @
   ... @
       @@
0x0129  LATIN SMALL LETTER I WITH TILDE
       @
       @
       @
       @
  :ji:t@
  , :i.@
   :   @
   LE: @
  $L#L @
   L#L @
   L#L @
   L#L @
   L#L @
   L#L @
   ... @
       @@
0x012A  LATIN CAPITAL LETTER I WITH MACRON
             @
  $        $ @
             @
  .........  @
  GEEEEEEEEf.@
             @
      :      @
      LE:    @
     $L#L    @
      L#L    @
  $   L#L    @
      L#L    @
      L#L    @
      L#L    @
      ...    @
             @@
0x012B  LATIN SMALL LETTER I WITH MACRON
             @
  $        $ @
             @
  .........  @
  GEEEEEEEEf.@
             @
      :      @
      LE:    @
     $L#L    @
      L#L    @
  $   L#L    @
      L#L    @
      L#L    @
      L#L    @
      ...    @
             @@
0x012C  LATIN CAPITAL LETTER I WITH BREVE
        @
        @
        @
        @
  .i..:j@
   :jft.@
    :   @
    LE: @
   $L#L @
    L#L @
    L#L @
    L#L @
    L#L @
    L#L @
    ... @
        @@
0x012D  LATIN SMALL LETTER I WITH BREVE
        @
        @
        @
        @
  .i..:j@
   :jft.@
    :   @
    LE: @
   $L#L @
    L#L @
    L#L @
    L#L @
    L#L @
    L#L @
    ... @
        @@
0x012E  LATIN CAPITAL LETTER I WITH OGONEK
      @
      @
      @
      @
      @
      @
      @
      @
      @
  ___ @
$|_ _|@
  | | @
  | | @
 |___|@
  (__(@
      @@
0x012F  LATIN SMALL LETTER I WITH OGONEK
     @
     @
     @
     @
     @
     @
     @
     @
     @
  _  @
$(_) @
 | | @
 | | @
 |_|_@
  (_(@
     @@
0x0130  LATIN CAPITAL LETTER I WITH DOT ABOVE
       @
       @
       @
   jG: @
  ,K#f @
       @
   :   @
   LE: @
  $L#L @
   L#L @
   L#L @
   L#L @
   L#L @
   L#L @
   ... @
       @@
0x0131  LATIN SMALL LETTER DOTLESS I
     @
     @
     @
     @
     @
     @
  i. @
  LW,@
 $L#L@
  L#L@
  L#L@
  L#L@
  L#L@
  L#L@
     @
     @@
0x0132  LATIN CAPITAL LIGATURE IJ
                @
                @
                @
  j    itttttttt@
  LD   fDDK##DD;@
  L#L     t#E   @
  L#L     t#E   @
  L#L     t#E   @
 $L#L     t#E   @
  L#L     t#E   @
  L#L  .jff#E   @
  L#L   ,K##E   @
  L#j    .G#E   @
  L#j      tE   @
            .   @
                @@
0x0133  LATIN SMALL LIGATURE IJ
                @
                @
                @
  j    itttttttt@
  LD   fDDK##DD;@
  L#L     t#E   @
  L#L     t#E   @
  L#L     t#E   @
 $L#L     t#E   @
  L#L     t#E   @
  L#L  .jff#E   @
  L#L   ,K##E   @
  L#j    .G#E   @
  L#j      tE   @
            .   @
                @@
0x0134  LATIN CAPITAL LETTER J WITH CIRCUMFLEX
     jLLj  @
     .  .  @
           @
  itttttttt@
 $fDDK##DDi@
     t#E   @
     t#E   @
     t#E   @
     t#E   @
     t#E   @
   jfL#E   @
   :K##E   @
     G#E   @
      tE   @
       .   @
           @@
0x0135  LATIN SMALL LETTER J WITH CIRCUMFLEX
     jLLj  @
     .  .  @
           @
  itttttttt@
 $fDDK##DDi@
     t#E   @
     t#E   @
     t#E   @
     t#E   @
     t#E   @
   jfL#E   @
   :K##E   @
     G#E   @
      tE   @
       .   @
           @@
0x0136  LATIN CAPITAL LETTER K WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _  _  @
$| |/ / @
 | ' /  @
 | . \\  @
 |_|\\_\\ @
    )__)@
        @@
0x0137  LATIN SMALL LETTER K WITH CEDILLA
       @
       @
       @
       @
       @
       @
       @
       @
       @
  _    @
$| | __@
 | |/ /@
 |   < @
 |_|\\_\\@
    )_)@
       @@
0x0138  LATIN SMALL LETTER KRA
       @
       @
       @
       @
       @
       @
       @
       @
       @
       @
  _ __ @
$| |/ \\@
 |   < @
 |_|\\_\\@
       @
       @@
0x0139  LATIN CAPITAL LETTER L WITH ACUTE
                 @
                 @
                 @
             t   @
       .i   f#   @
       :.  f##   @
          L#W:   @
         L#W:    @
  $     G#W.     @
       D#K.   $  @
      E#K.       @
    .E#E.        @
   .K#K:.......  @
 $.K###########L.@
  ...............@
                 @@
0x013A  LATIN SMALL LETTER L WITH ACUTE
                 @
                 @
                 @
             t   @
       .i   f#   @
       :.  f##   @
          L#W:   @
         L#W:    @
  $     G#W.     @
       D#K.   $  @
      E#K.       @
    .E#E.        @
   .K#K:.......  @
 $.K###########L.@
  ...............@
                 @@
0x013B  LATIN CAPITAL LETTER L WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _     @
$| |    @
 | |    @
 | |___ @
 |_____|@
    )__)@
        @@
0x013C  LATIN SMALL LETTER L WITH CEDILLA
      @
      @
      @
      @
      @
      @
      @
      @
      @
  _   @
$| |  @
 | |  @
 | |  @
 |_|  @
   )_)@
      @@
0x013D  LATIN CAPITAL LETTER L WITH CARON
                 @
                 @
                 @
             t   @
     i.,:   f#   @
     .ti   f##   @
          L#W:   @
         L#W:    @
  $     G#W.     @
       D#K.   $  @
      E#K.       @
    .E#E.        @
   .K#K:.......  @
 $.K###########L.@
  ...............@
                 @@
0x013E  LATIN SMALL LETTER L WITH CARON
                 @
                 @
                 @
             t   @
     i.,:   f#   @
     .ti   f##   @
          L#W:   @
         L#W:    @
  $     G#W.     @
       D#K.   $  @
      E#K.       @
    .E#E.        @
   .K#K:.......  @
 $.K###########L.@
  ...............@
                 @@
0x013F  LATIN CAPITAL LETTER L WITH MIDDLE DOT
                 @
                 @
                 @
             t   @
            f#   @
           f##   @
          L#W:   @
         L#W:    @
  $     G#W.     @
       D#K.  jG: @
      E#K.  ,K#f @
    .E#E.        @
   .K#K:.......  @
 $.K###########L.@
  ...............@
                 @@
0x0140  LATIN SMALL LETTER L WITH MIDDLE DOT
                 @
                 @
                 @
             t   @
            f#   @
           f##   @
          L#W:   @
         L#W:    @
  $     G#W.     @
       D#K.  jG: @
      E#K.  ,K#f @
    .E#E.        @
   .K#K:.......  @
 $.K###########L.@
  ...............@
                 @@
0x0141  LATIN CAPITAL LETTER L WITH STROKE
        @
        @
        @
        @
        @
        @
        @
        @
        @
  __    @
$| //   @
 |//|   @
 // |__ @
 |_____|@
        @
        @@
0x0142  LATIN SMALL LETTER L WITH STROKE
        @
        @
        @
        @
        @
        @
        @
        @
        @
  __    @
$| //   @
 |//|   @
 // |__ @
 |_____|@
        @
        @@
0x0143  LATIN CAPITAL LETTER N WITH ACUTE
                @
         ,:     @
  L.    .;      @
  EW:        ,ft@
  E##;       t#E@
  E###t      t#E@
  E#fE#f     t#E@
  E#t D#G    t#E@
 $E#t  f#E.  t#E@
  E#t   t#K: t#E@
  E#t    ;#W,t#E@
  E#t     :K#D#E@
  E#t      .E##E@
  E#t        G#E@
  ..          fE@
               ,@@
0x0144  LATIN SMALL LETTER N WITH ACUTE
                @
         ,:     @
  L.    .;      @
  EW:        ,ft@
  E##;       t#E@
  E###t      t#E@
  E#fE#f     t#E@
  E#t D#G    t#E@
 $E#t  f#E.  t#E@
  E#t   t#K: t#E@
  E#t    ;#W,t#E@
  E#t     :K#D#E@
  E#t      .E##E@
  E#t        G#E@
  ..          fE@
               ,@@
0x0145  LATIN CAPITAL LETTER N WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _   _ @
$| \\ | |@
 |  \\| |@
 | |\\  |@
 |_| \\_|@
 )_)    @
        @@
0x0146  LATIN SMALL LETTER N WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _ __  @
$| '_ \\ @
 | | | |@
 |_| |_|@
 )_)    @
        @@
0x0147  LATIN CAPITAL LETTER N WITH CARON
                @
       i.,:     @
  L.   .ti      @
  EW:        ,ft@
  E##;       t#E@
  E###t      t#E@
  E#fE#f     t#E@
  E#t D#G    t#E@
 $E#t  f#E.  t#E@
  E#t   t#K: t#E@
  E#t    ;#W,t#E@
  E#t     :K#D#E@
  E#t      .E##E@
  E#t        G#E@
  ..          fE@
               ,@@
0x0148  LATIN SMALL LETTER N WITH CARON
                @
       i.,:     @
  L.   .ti      @
  EW:        ,ft@
  E##;       t#E@
  E###t      t#E@
  E#fE#f     t#E@
  E#t D#G    t#E@
 $E#t  f#E.  t#E@
  E#t   t#K: t#E@
  E#t    ;#W,t#E@
  E#t     :K#D#E@
  E#t      .E##E@
  E#t        G#E@
  ..          fE@
               ,@@
0x0149  LATIN SMALL LETTER N PRECEDED BY APOSTROPHE
                    @
  ;#                @
 ;#   L.            @
      EW:        ,ft@
      E##;       t#E@
      E###t      t#E@
      E#fE#f     t#E@
      E#t D#G    t#E@
     $E#t  f#E.  t#E@
      E#t   t#K: t#E@
      E#t    ;#W,t#E@
      E#t     :K#D#E@
      E#t      .E##E@
      E#t        G#E@
      ..          fE@
                   ,@@
0x014A  LATIN CAPITAL LETTER ENG
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _   _ @
$| \\ | |@
 |  \\| |@
 | |\\  |@
 |_| \\ |@
     )_)@
        @@
0x014B  LATIN SMALL LETTER ENG
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _ __  @
$| '_ \\ @
 | | | |@
 |_| | |@
     | |@
    |__ @
        @@
0x014C  LATIN CAPITAL LETTER O WITH MACRON
             @
             @
             @
             @
             @
  .........  @
  GEEEEEEEEf.@
       .     @
     .L#D.   @
    iWG:f#j  @
 $:DWi   ,EK,@
  .G#t   ;WE:@
    ;KE;G#t  @
      f#G.   @
             @
             @@
0x014D  LATIN SMALL LETTER O WITH MACRON
             @
             @
             @
             @
             @
  .........  @
  GEEEEEEEEf.@
       .     @
     .L#D.   @
    iWG:f#j  @
 $:DWi   ,EK,@
  .G#t   ;WE:@
    ;KE;G#t  @
      f#G.   @
             @
             @@
0x014E  LATIN CAPITAL LETTER O WITH BREVE
             @
             @
             @
             @
             @
    :f,,,ij  @
     .ttt;   @
             @
     .D#E,   @
    j#L.j#f. @
 $:KK,   .DW;@
   f#j   t#G.@
    :EKiEW;  @
      tWf    @
             @
             @@
0x014F  LATIN SMALL LETTER O WITH BREVE
             @
             @
             @
             @
             @
    :f,,,ij  @
     .ttt;   @
             @
     .D#E,   @
    j#L.j#f. @
 $:KK,   .DW;@
   f#j   t#G.@
    :EKiEW;  @
      tWf    @
             @
             @@
0x0150  LATIN CAPITAL LETTER O WITH DOUBLE ACUTE
             @
             @
             @
             @
             @
     ,:  ,:  @
    .;  .;   @
             @
     .D#E,   @
    j#L.j#f. @
 $:KK,   .DW;@
   f#j   t#G.@
    :EKiEW;  @
      tWf    @
             @
             @@
0x0151  LATIN SMALL LETTER O WITH DOUBLE ACUTE
             @
             @
             @
             @
             @
     ,:  ,:  @
    .;  .;   @
             @
     .D#E,   @
    j#L.j#f. @
 $:KK,   .DW;@
   f#j   t#G.@
    :EKiEW;  @
      tWf    @
             @
             @@
0x0152  LATIN CAPITAL LIGATURE OE
                      @
                      @
       G            i @
      D#G         .DE @
     LW;#f       ,KK: @
    j#: ;#i     t#G.  @
   ;#;   t#,   L#j    @
  :#t     fW.:K#f;;:  @
 $fW.     :#;K##EEEEf.@
   DE    .Kt .G#D.    @
   .KG   EL    t#K:   @
    .Wf GD      ,K#i  @
     ,#DK.        L#f @
      ;#:          tD @
       .            . @
                      @@
0x0153  LATIN SMALL LIGATURE OE
                      @
                      @
       G            i @
      D#G         .DE @
     LW;#f       ,KK: @
    j#: ;#i     t#G.  @
   ;#;   t#,   L#j    @
  :#t     fW.:K#f;;:  @
 $fW.     :#;K##EEEEf.@
   DE    .Kt .G#D.    @
   .KG   EL    t#K:   @
    .Wf GD      ,K#i  @
     ,#DK.        L#f @
      ;#:          tD @
       .            . @
                      @@
0x0154  LATIN CAPITAL LETTER R WITH ACUTE
             @
             @
         ,:  @
  j.    .;   @
  EW,        @
  E##j       @
  E###D.   $ @
  E#jG#W;    @
 $E#t t##f   @
  E#t  :K#E: @
  E#KDDDD###i@
  E#f,t#Wi,,,@
  E#t  ;#W:  @
  DWi   ,KK: @
             @
             @@
0x0155  LATIN SMALL LETTER R WITH ACUTE
             @
             @
         ,:  @
  j.    .;   @
  EW,        @
  E##j       @
  E###D.   $ @
  E#jG#W;    @
 $E#t t##f   @
  E#t  :K#E: @
  E#KDDDD###i@
  E#f,t#Wi,,,@
  E#t  ;#W:  @
  DWi   ,KK: @
             @
             @@
0x0156  LATIN CAPITAL LETTER R WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
  ____  @
$|  _ \\ @
 | |_) |@
 |  _ < @
 |_| \\_\\@
 )_)    @
        @@
0x0157  LATIN SMALL LETTER R WITH CEDILLA
       @
       @
       @
       @
       @
       @
       @
       @
       @
       @
  _ __ @
$| '__|@
 | |   @
 |_|   @
   )_) @
       @@
0x0158  LATIN CAPITAL LETTER R WITH CARON
             @
             @
       i.,:  @
  j.   .ti   @
  EW,        @
  E##j       @
  E###D.   $ @
  E#jG#W;    @
 $E#t t##f   @
  E#t  :K#E: @
  E#KDDDD###i@
  E#f,t#Wi,,,@
  E#t  ;#W:  @
  DWi   ,KK: @
             @
             @@
0x0159  LATIN SMALL LETTER R WITH CARON
             @
             @
       i.,:  @
  j.   .ti   @
  EW,        @
  E##j       @
  E###D.   $ @
  E#jG#W;    @
 $E#t t##f   @
  E#t  :K#E: @
  E#KDDDD###i@
  E#f,t#Wi,,,@
  E#t  ;#W:  @
  DWi   ,KK: @
             @
             @@
0x015A  LATIN CAPITAL LETTER S WITH ACUTE
            @
      ,:    @
     .;    .@
          ;W@
         f#E@
  $    .E#f @
      iWW;  @
     L##Lffi@
    tLLG##L @
      ,W#i  @
     j#E.   @
   .D#j     @
  ,WK,    $ @
 $EG.       @
  ,         @
            @@
0x015B  LATIN SMALL LETTER S WITH ACUTE
            @
      ,:    @
     .;    .@
          ;W@
         f#E@
  $    .E#f @
      iWW;  @
     L##Lffi@
    tLLG##L @
      ,W#i  @
     j#E.   @
   .D#j     @
  ,WK,    $ @
 $EG.       @
  ,         @
            @@
0x015C  LATIN CAPITAL LETTER S WITH CIRCUMFLEX
            @
    jLLj    @
    .  .   .@
          ;W@
         f#E@
  $    .E#f @
      iWW;  @
     L##Lffi@
    tLLG##L @
      ,W#i  @
     j#E.   @
   .D#j     @
  ,WK,    $ @
 $EG.       @
  ,         @
            @@
0x015D  LATIN SMALL LETTER S WITH CIRCUMFLEX
            @
    jLLj    @
    .  .   .@
          ;W@
         f#E@
  $    .E#f @
      iWW;  @
     L##Lffi@
    tLLG##L @
      ,W#i  @
     j#E.   @
   .D#j     @
  ,WK,    $ @
 $EG.       @
  ,         @
            @@
0x015E  LATIN CAPITAL LETTER S WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
  ____  @
$/ ___| @
 \\___ \\ @
  ___) |@
 |____/ @
    )__)@
        @@
0x015F  LATIN SMALL LETTER S WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
  ____  @
$/ ___| @
 \\___ \\ @
  ___) |@
 |____/ @
    )__)@
        @@
0x0160  LATIN CAPITAL LETTER S WITH CARON
            @
    i.,:    @
    .ti    .@
          ;W@
         f#E@
  $    .E#f @
      iWW;  @
     L##Lffi@
    tLLG##L @
      ,W#i  @
     j#E.   @
   .D#j     @
  ,WK,    $ @
 $EG.       @
  ,         @
            @@
0x0161  LATIN SMALL LETTER S WITH CARON
            @
    i.,:    @
    .ti    .@
          ;W@
         f#E@
  $    .E#f @
      iWW;  @
     L##Lffi@
    tLLG##L @
      ,W#i  @
     j#E.   @
   .D#j     @
  ,WK,    $ @
 $EG.       @
  ,         @
            @@
0x0162  LATIN CAPITAL LETTER T WITH CEDILLA
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _____ @
$|_   _|@
   | |  @
   | |  @
   |_|  @
    )__)@
        @@
0x0163  LATIN SMALL LETTER T WITH CEDILLA
      @
      @
      @
      @
      @
      @
      @
      @
      @
  _   @
$| |_ @
 | __|@
 | |_ @
  \\__|@
   )_)@
      @@
0x0164  LATIN CAPITAL LETTER T WITH CARON
           @
    i.,:   @
    .ti    @
           @
 $GEEEEEEEL@
  ,;;L#K;;.@
     t#E   @
     t#E   @
     t#E   @
  $  t#E   @
     t#E   @
     t#E   @
     t#E   @
      fE   @
       :   @
           @@
0x0165  LATIN SMALL LETTER T WITH CARON
           @
    i.,:   @
    .ti    @
           @
 $GEEEEEEEL@
  ,;;L#K;;.@
     t#E   @
     t#E   @
     t#E   @
  $  t#E   @
     t#E   @
     t#E   @
     t#E   @
      fE   @
       :   @
           @@
0x0166  LATIN CAPITAL LETTER T WITH STROKE
           @
           @
           @
           @
 $GEEEEEEEL@
  ,;;L#K;;.@
     t#E   @
     t#E   @
     t#E   @
   ##t#### @
     t#E   @
     t#E   @
     t#E   @
      fE   @
       :   @
           @@
0x0167  LATIN SMALL LETTER T WITH STROKE
           @
           @
           @
           @
 $GEEEEEEEL@
  ,;;L#K;;.@
     t#E   @
     t#E   @
     t#E   @
   ##t#### @
     t#E   @
     t#E   @
     t#E   @
      fE   @
       :   @
           @@
0x0168  LATIN CAPITAL LETTER U WITH TILDE
    jLj;f  @
   .: :i.  @
           @
  f;       @
  L#t    $ @
  L#L      @
  L#L      @
  L#L ,:   @
 $L#L t#i  @
  L#L t#E  @
  L#L.D#f  @
  L#EW#i   @
  L##D.    @
  L#j      @
  t:       @
           @@
0x0169  LATIN SMALL LETTER U WITH TILDE
    jLj;f  @
   .: :i.  @
           @
  f;       @
  L#t    $ @
  L#L      @
  L#L      @
  L#L ,:   @
 $L#L t#i  @
  L#L t#E  @
  L#L.D#f  @
  L#EW#i   @
  L##D.    @
  L#j      @
  t:       @
           @@
0x016A  LATIN CAPITAL LETTER U WITH MACRON
  .........  @
  GEEEEEEEEf.@
             @
    f;       @
    L#t    $ @
    L#L      @
    L#L      @
    L#L ,:   @
   $L#L t#i  @
    L#L t#E  @
    L#L.D#f  @
    L#EW#i   @
    L##D.    @
    L#j      @
    t:       @
             @@
0x016B  LATIN SMALL LETTER U WITH MACRON
  .........  @
  GEEEEEEEEf.@
             @
    f;       @
    L#t    $ @
    L#L      @
    L#L      @
    L#L ,:   @
   $L#L t#i  @
    L#L t#E  @
    L#L.D#f  @
    L#EW#i   @
    L##D.    @
    L#j      @
    t:       @
             @@
0x016C  LATIN CAPITAL LETTER U WITH BREVE
  :f,,,ij  @
   .ttt;   @
           @
  f;       @
  L#t    $ @
  L#L      @
  L#L      @
  L#L ,:   @
 $L#L t#i  @
  L#L t#E  @
  L#L.D#f  @
  L#EW#i   @
  L##D.    @
  L#j      @
  t:       @
           @@
0x016D  LATIN SMALL LETTER U WITH BREVE
  :f,,,ij  @
   .ttt;   @
           @
  f;       @
  L#t    $ @
  L#L      @
  L#L      @
  L#L ,:   @
 $L#L t#i  @
  L#L t#E  @
  L#L.D#f  @
  L#EW#i   @
  L##D.    @
  L#j      @
  t:       @
           @@
0x016E  LATIN CAPITAL LETTER U WITH RING ABOVE
           @
      .ji  @
      ;jj. @
  f;       @
  L#t      @
  L#L      @
  L#L      @
  L#L ,:   @
 $L#L t#i  @
  L#L t#E  @
  L#L.D#f  @
  L#EW#i   @
  L##D.    @
  L#j      @
  t:       @
           @@
0x016F  LATIN SMALL LETTER U WITH RING ABOVE
           @
      .ji  @
      ;jj. @
  f;       @
  L#t      @
  L#L      @
  L#L      @
  L#L ,:   @
 $L#L t#i  @
  L#L t#E  @
  L#L.D#f  @
  L#EW#i   @
  L##D.    @
  L#j      @
  t:       @
           @@
0x0170  LATIN CAPITAL LETTER U WITH DOUBLE ACUTE
   ,:  ,:  @
  .;  .;   @
           @
  f;       @
  L#t    $ @
  L#L      @
  L#L      @
  L#L ,:   @
 $L#L t#i  @
  L#L t#E  @
  L#L.D#f  @
  L#EW#i   @
  L##D.    @
  L#j      @
  t:       @
           @@
0x0171  LATIN SMALL LETTER U WITH DOUBLE ACUTE
   ,:  ,:  @
  .;  .;   @
           @
  f;       @
  L#t    $ @
  L#L      @
  L#L      @
  L#L ,:   @
 $L#L t#i  @
  L#L t#E  @
  L#L.D#f  @
  L#EW#i   @
  L##D.    @
  L#j      @
  t:       @
           @@
0x0172  LATIN CAPITAL LETTER U WITH OGONEK
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _   _ @
$| | | |@
 | | | |@
 | |_| |@
  \\___/ @
    (__(@
        @@
0x0173  LATIN SMALL LETTER U WITH OGONEK
        @
        @
        @
        @
        @
        @
        @
        @
        @
        @
  _   _ @
$| | | |@
 | |_| |@
  \\__,_|@
     (_(@
        @@
0x0174  LATIN CAPITAL LETTER W WITH CIRCUMFLEX
                     @
          jLLj       @
          .  .       @
                     @
  $         ;      $ @
          .DL        @
  f.     :K#L     LWL@
  EW:   ;W##L   .E#f @
 $E#t  t#KE#L  ,W#;  @
  E#t f#D.L#L t#K:   @
  E#jG#f  L#LL#G   $ @
  E###;   L###j      @
  E#K:    L#W;       @
  EG      LE.        @
  ;       ;@         @
                     @@
0x0175  LATIN SMALL LETTER W WITH CIRCUMFLEX
                     @
          jLLj       @
          .  .       @
                     @
  $         ;      $ @
          .DL        @
  f.     :K#L     LWL@
  EW:   ;W##L   .E#f @
 $E#t  t#KE#L  ,W#;  @
  E#t f#D.L#L t#K:   @
  E#jG#f  L#LL#G   $ @
  E###;   L###j      @
  E#K:    L#W;       @
  EG      LE.        @
  ;       ;@         @
                     @@
0x0176  LATIN CAPITAL LETTER Y WITH CIRCUMFLEX
             @
  $        $ @
     jLLj    @
     .  .    @
  f.     ;WE.@
  E#,   i#G  @
  E#t  f#f   @
  E#t G#i    @
 $E#jEW,     @
  E##E.    $ @
  E#G        @
  E#t        @
  E#t        @
  EE.        @
  t          @
             @@
0x0177  LATIN SMALL LETTER Y WITH CIRCUMFLEX
             @
  $        $ @
     jLLj    @
     .  .    @
  f.     ;WE.@
  E#,   i#G  @
  E#t  f#f   @
  E#t G#i    @
 $E#jEW,     @
  E##E.    $ @
  E#G        @
  E#t        @
  E#t        @
  EE.        @
  t          @
             @@
0x0178  LATIN CAPITAL LETTER Y WITH DIAERESIS
             @
  $        $ @
             @
    j; ,j    @
  ; ti it jL:@
  LE:    G#i @
  L#L  .EW,  @
  L#L :WK.   @
 $L#L;#D     @
  L#K#f      @
  L##t    $  @
  L#L        @
  L#L        @
  L#j        @
  ft         @
             @@
0x0179  LATIN CAPITAL LETTER Z WITH ACUTE
                         @
                         @
             ,:      $   @
            .;           @
                         @
       ,##############Wf.@
        ........jW##Wt   @
              tW##Kt     @
     $      tW##E;     $ @
          tW##E;         @
       .fW##D,        $  @
     .f###D,             @
   .f####Gfffffffffff;   @
 $.fLLLLLLLLLLLLLLLLLi   @
                         @
                         @@
0x017A  LATIN SMALL LETTER Z WITH ACUTE
                         @
                         @
             ,:      $   @
            .;           @
                         @
       ,##############Wf.@
        ........jW##Wt   @
              tW##Kt     @
     $      tW##E;     $ @
          tW##E;         @
       .fW##D,        $  @
     .f###D,             @
   .f####Gfffffffffff;   @
  .fLLLLLLLLLLLLLLLLLi   @
                         @
                         @@
0x017B  LATIN CAPITAL LETTER Z WITH DOT ABOVE
                         @
                         @
            jG:      $   @
           ,K#f          @
                         @
       ,##############Wf.@
        ........jW##Wt   @
              tW##Kt     @
     $      tW##E;     $ @
          tW##E;         @
       .fW##D,        $  @
     .f###D,             @
   .f####Gfffffffffff;   @
  .fLLLLLLLLLLLLLLLLLi   @
                         @
                         @@
0x017C  LATIN SMALL LETTER Z WITH DOT ABOVE
                         @
                         @
            jG:      $   @
           ,K#f          @
                         @
       ,##############Wf.@
        ........jW##Wt   @
              tW##Kt     @
     $      tW##E;     $ @
          tW##E;         @
       .fW##D,        $  @
     .f###D,             @
   .f####Gfffffffffff;   @
 $.fLLLLLLLLLLLLLLLLLi   @
                         @
                         @@
0x017D  LATIN CAPITAL LETTER Z WITH CARON
                         @
                         @
           i.,:      $   @
           .ti           @
                         @
       ,##############Wf.@
        ........jW##Wt   @
              tW##Kt     @
     $      tW##E;     $ @
          tW##E;         @
       .fW##D,        $  @
     .f###D,             @
   .f####Gfffffffffff;   @
 $.fLLLLLLLLLLLLLLLLLi   @
                         @
                         @@
0x017E  LATIN SMALL LETTER Z WITH CARON
                         @
                         @
           i.,:      $   @
           .ti           @
                         @
       ,##############Wf.@
        ........jW##Wt   @
              tW##Kt     @
     $      tW##E;     $ @
          tW##E;         @
       .fW##D,        $  @
     .f###D,             @
   .f####Gfffffffffff;   @
 $.fLLLLLLLLLLLLLLLLLi   @
                         @
                         @@
0x017F  LATIN SMALL LETTER LONG S
        @
        @
        @
        @
        @
        @
   $    @
   $    @
   $    @
     __ @
    / _|@
$|-| |  @
 |-| |  @
   |_|  @
        @
        @@
0x02C7  CARON
    $$ @
   i.,:@
   .ti @
    $$ @
    $$ @
    $$ @
    $$ @
    $$ @
    $$ @
    $$ @
    $$ @
    $$ @
    $$ @
    $$ @
    $$ @
    $$ @@
0x02D8  BREVE
      $ @
 $:f,,,ij@
   .ttt; @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @
      $ @@
0x02D9  DOT ABOVE
    $ @
   jG:@
  ,K#f@
    $ @
    $ @
    $ @
    $ @
    $ @
    $ @
    $ @
    $ @
    $ @
    $ @
    $ @
    $ @
    $ @@
0x02DB  OGONEK
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
 )_) @
     @@
0x02DD  DOUBLE ACUTE ACCENT
  _ _ @
$/_/_/@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@
     $@@
`