export default `flf2a$ 8 6 17 -1 11

   nancyj-fancy.flf

   named after the login of a woman who  asked me to make her a
   sig. this is the font that came out of it.  this is my first
   attempt at a figlet font, so leave me alone.

   vampyr@acs.bu.edu

Modified to make tabs blanks by Paul Burton <solution@earthlink.net>

$$ @
$$ @
$$ @
$$ @
$$ @
$$ @
$$ @
$$ @@
dP @
88 @
88 @
dP @
   @
oo @
   @
   @@
dP dP @
dP dP @
      @
      @
      @
      @
      @
      @@
        @
 dP dP  @
8888888 @
 88 88  @
8888888 @
 dP dP  @
        @
        @@
  #  #   @
.d8888P' @
Y8#oo#o. @
  #  #88 @
\`88888P' @
  #  #   @
         @
         @@
d8P   dP   @
8 8  d8'   @
Y8P d8'    @
   d8' d8P @
  d8'  8 8 @
 88    Y8P @
           @
           @@
   d88b    @
   8\`'8    @
   d8b     @
 d8P\`8b    @
 d8' \`8bP  @
 \`888P'\`YP @
           @
           @@
d8 @
88 @
.P @
   @
   @
   @
   @
   @@
 a88P @
d8'   @
88    @
88    @
Y8.   @
 Y88b @
      @
      @@
Y88o  @
  \`8b @
   88 @
   88 @
  .8P @
d88Y  @
      @
      @@
    dP     @
8b. 88 .d8 @
 \`8b88d8'  @
 .8P88Y8.  @
8P' 88 \`Y8 @
    dP     @
           @
           @@
         @
   dP    @
   88    @
88888888 @
   88    @
   dP    @
         @
         @@
   @
   @
   @
   @
dP @
88 @
.P @
   @@
         @
         @
         @
88888888 @
         @
         @
         @
         @@
   @
   @
   @
   @
dP @
88 @
   @
   @@
     d8' @
    d8'  @
   d8'   @
  d8'    @
 d8'     @
88       @
         @
         @@
 a8888a  @
d8' ..8b @
88 .P 88 @
88 d' 88 @
Y8'' .8P @
 Y8888P  @
         @
         @@
d88  @
 88  @
 88  @
 88  @
 88  @
d88P @
     @
     @@
d8888b. @
    \`88 @
.aaadP' @
88'     @
88.     @
Y88888P @
        @
        @@
d8888b. @
    \`88 @
 aaad8' @
    \`88 @
    .88 @
d88888P @
        @
        @@
dP   dP @
88   88 @
88aaa88 @
     88 @
     88 @
     dP @
        @
        @@
888888P @
88'     @
88baaa. @
    \`88 @
     88 @
d88888P @
        @
        @@
.d8888P @
88'     @
88baaa. @
88\` \`88 @
8b. .d8 @
\`Y888P' @
        @
        @@
d88888P @
    d8' @
   d8'  @
  d8'   @
 d8'    @
d8'     @
        @
        @@
.d888b. @
Y8' \`8P @
d8bad8b @
88\` \`88 @
8b. .88 @
Y88888P @
        @
        @@
.d888b. @
Y8' \`88 @
\`8bad88 @
    \`88 @
d.  .88 @
\`8888P  @
        @
        @@
dP @
88 @
   @
   @
dP @
88 @
   @
   @@
dP @
88 @
   @
   @
dP @
88 @
.P @
   @@
   d8 @
  d8' @
 d8'  @
 Y8.  @
  Y8. @
   Y8 @
      @
      @@
         @
         @
aaaaaaaa @
         @
88888888 @
         @
         @
         @@
8b   @
\`8b  @
 \`8b @
 .8P @
.8P  @
8P   @
     @
     @@
.d8888ba  @
\`8'   \`8b @
     .d8' @
   d8P'   @
   ""     @
   oo     @
          @
          @@
 a88888b. @
d8'   \`88 @
88 d8P 88 @
88 Yo8b88 @
Y8.       @
 Y88888P' @
          @
          @@
MMP"""""""MM @
M' .mmmm  MM @
M         \`M @
M  MMMMM  MM @
M  MMMMM  MM @
M  MMMMM  MM @
MMMMMMMMMMMM @
             @@
M#"""""""'M$ @
##  mmmm. \`M @
#'        .M @
M#  MMMb.'YM @
M#  MMMM'  M @
M#       .;M @
M#########M$ @
             @@
MM'""""'YMM @
M' .mmm. \`M @
M  MMMMMooM @
M  MMMMMMMM @
M. \`MMM' .M @
MM.     .dM @
MMMMMMMMMMM @
            @@
M""""""'YMM @
M  mmmm. \`M @
M  MMMMM  M @
M  MMMMM  M @
M  MMMM' .M @
M       .MM @
MMMMMMMMMMM @
            @@
MM""""""""\`M @
MM  mmmmmmmM @
M\`      MMMM @
MM  MMMMMMMM @
MM  MMMMMMMM @
MM        .M @
MMMMMMMMMMMM @
             @@
MM""""""""\`M @
MM  mmmmmmmM @
M'      MMMM @
MM  MMMMMMMM @
MM  MMMMMMMM @
MM  MMMMMMMM @
MMMMMMMMMMMM @
             @@
MM'"""""\`MM @
M' .mmm. \`M @
M  MMMMMMMM @
M  MMM   \`M @
M. \`MMM' .M @
MM.     .MM @
MMMMMMMMMMM @
            @@
M""MMMMM""MM @
M  MMMMM  MM @
M         \`M @
M  MMMMM  MM @
M  MMMMM  MM @
M  MMMMM  MM @
MMMMMMMMMMMM @
             @@
M""M @
M  M @
M  M @
M  M @
M  M @
M  M @
MMMM @
     @@
MMMMMMMM""M @
MMMMMMMM  M @
MMMMMMMM  M @
MMMMMMMM  M @
M. \`MMM' .M @
MM.     .MM @
MMMMMMMMMMM @
            @@
M""MMMMM""M @
M  MMMM' .M @
M       .MM @
M  MMMb. YM @
M  MMMMb  M @
M  MMMMM  M @
MMMMMMMMMMM @
            @@
M""MMMMMMMM @
M  MMMMMMMM @
M  MMMMMMMM @
M  MMMMMMMM @
M  MMMMMMMM @
M         M @
MMMMMMMMMMM @
            @@
M"""""\`'"""\`YM @
M  mm.  mm.  M @
M  MMM  MMM  M @
M  MMM  MMM  M @
M  MMM  MMM  M @
M  MMM  MMM  M @
MMMMMMMMMMMMMM @
               @@
M"""""""\`YM @
M  mmmm.  M @
M  MMMMM  M @
M  MMMMM  M @
M  MMMMM  M @
M  MMMMM  M @
MMMMMMMMMMM @
            @@
MMP"""""YMM @
M' .mmm. \`M @
M  MMMMM  M @
M  MMMMM  M @
M. \`MMM' .M @
MMb     dMM @
MMMMMMMMMMM @
            @@
MM"""""""\`YM @
MM  mmmmm  M @
M'        .M @
MM  MMMMMMMM @
MM  MMMMMMMM @
MM  MMMMMMMM @
MMMMMMMMMMMM @
             @@
MM'"""""\`MMM @
M  .mmm,  MM @
M  MMMMM  MM @
M  MM  M  MM @
M  \`MM    MM @
MM.    .. \`M @
MMMMMMMMMMMM @
             @@
MM"""""""\`MM @
MM  mmmm,  M @
M'        .M @
MM  MMMb. "M @
MM  MMMMM  M @
MM  MMMMM  M @
MMMMMMMMMMMM @
             @@
MP""""""\`MM @
M  mmmmm..M @
M.      \`YM @
MMMMMMM.  M @
M. .MMM'  M @
Mb.     .dM @
MMMMMMMMMMM @
            @@
M""""""""M @
Mmmm  mmmM @
MMMM  MMMM @
MMMM  MMMM @
MMMM  MMMM @
MMMM  MMMM @
MMMMMMMMMM @
           @@
M""MMMMM""M @
M  MMMMM  M @
M  MMMMM  M @
M  MMMMM  M @
M  \`MMM'  M @
Mb       dM @
MMMMMMMMMMM @
            @@
M""MMMMM""M @
M  MMMMM  M @
M  MMMMP  M @
M  MMMM' .M @
M  MMP' .MM @
M     .dMMM @
MMMMMMMMMMM @
            @@
M""MMM""MMM""M @
M  MMM  MMM  M @
M  MMP  MMP  M @
M  MM'  MM' .M @
M  \`' . '' .MM @
M    .d  .dMMM @
MMMMMMMMMMMMMM @
               @@
M""MMMM""M @
M  \`MM'  M @
MM.    .MM @
M  .mm.  M @
M  MMMM  M @
M  MMMM  M @
MMMMMMMMMM @
           @@
M""MMMM""M @
M. \`MM' .M @
MM.    .MM @
MMMb  dMMM @
MMMM  MMMM @
MMMM  MMMM @
MMMMMMMMMM @
           @@
M""""""""\`M @
Mmmmmm   .M @
MMMMP  .MMM @
MMP  .MMMMM @
M' .MMMMMMM @
M         M @
MMMMMMMMMMM @
            @@
8888P @
88    @
88    @
88    @
88    @
88888 @
      @
      @@
Yb      @
\`Yb     @
 \`Yb    @
  \`Yb   @
   \`Yb  @
     88 @
        @
        @@
d8888 @
   88 @
   88 @
   88 @
   88 @
88888 @
      @
      @@
   db    @
 d8'\`8b  @
\`"    "' @
         @
         @
         @
         @
         @@
             @
             @
             @
             @
             @
             @
oooooooooooo @
             @@
dP @
88 @
Y. @
   @
   @
   @
   @
   @@
         @
         @
.d8888b. @
88'  \`88 @
88.  .88 @
\`88888P8 @
         @
         @@
dP       @
88       @
88d888b. @
88'  \`88 @
88.  .88 @
88Y8888' @
         @
         @@
         @
         @
.d8888b. @
88'  \`"" @
88.  ... @
\`88888P' @
         @
         @@
      dP @
      88 @
.d888b88 @
88'  \`88 @
88.  .88 @
\`88888P8 @
         @
         @@
         @
         @
.d8888b. @
88ooood8 @
88.  ... @
\`88888P' @
         @
         @@
.8888b @
88   " @
88aaa  @
88     @
88     @
dP     @
       @
       @@
         @
         @
.d8888b. @
88'  \`88 @
88.  .88 @
\`8888P88 @
     .88 @
 d8888P  @@
dP       @
88       @
88d888b. @
88'  \`88 @
88    88 @
dP    dP @
         @
         @@
oo @
   @
dP @
88 @
88 @
dP @
   @
   @@
oo @
   @
dP @
88 @
88 @
88 @
88 @
dP @@
dP       @
88       @
88  .dP  @
88888"   @
88  \`8b. @
dP   \`YP @
         @
         @@
dP @
88 @
88 @
88 @
88 @
dP @
   @
   @@
           @
           @
88d8b.d8b. @
88'\`88'\`88 @
88  88  88 @
dP  dP  dP @
           @
           @@
         @
         @
88d888b. @
88'  \`88 @
88    88 @
dP    dP @
         @
         @@
         @
         @
.d8888b. @
88'  \`88 @
88.  .88 @
\`88888P' @
         @
         @@
         @
         @
88d888b. @
88'  \`88 @
88.  .88 @
88Y888P' @
88       @
dP       @@
         @
         @
.d8888b. @
88'  \`88 @
88.  .88 @
\`8888P88 @
      88 @
      dP @@
         @
         @
88d888b. @
88'  \`88 @
88       @
dP       @
         @
         @@
         @
         @
.d8888b. @
Y8ooooo. @
      88 @
\`88888P' @
         @
         @@
  dP   @
  88   @
d8888P @
  88   @
  88   @
  dP   @
       @
       @@
         @
         @
dP    dP @
88    88 @
88.  .88 @
\`88888P' @
         @
         @@
         @
         @
dP   .dP @
88   d8' @
88 .88'  @
8888P'   @
         @
         @@
           @
           @
dP  dP  dP @
88  88  88 @
88.88b.88' @
8888P Y8P  @
           @
           @@
         @
         @
dP.  .dP @
 \`8bd8'  @
 .d88b.  @
dP'  \`dP @
         @
         @@
         @
         @
dP    dP @
88    88 @
88.  .88 @
\`8888P88 @
     .88 @
 d8888P  @@
         @
         @
d888888b @
   .d8P' @
 .Y8P    @
d888888P @
         @
         @@
  .d88P @
  8:    @
.oY8.   @
  d8    @
  8:    @
  \`Y88b @
        @
        @@
dP @
88 @
"' @
dP @
88 @
"' @
   @
   @@
d88b.   @
   :8   @
  .8Yo. @
   8b   @
   :8   @
Y88P'   @
        @
        @@
 .oo.  .d @
dP" "d8P  @
          @
          @
          @
          @
          @
          @@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@@
`